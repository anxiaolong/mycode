package login.dao.impl;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import login.dao.*;
import login.pojo.User;

public class LoginDaoImpl implements LoginDao  {
	
	@Override
	public User checkLoginDao(String uname, String pwd) {
		//1.���壺���ӣ���䣬�����
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		User user=null;
		
		//2.��������������db_url
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String db_url = "jdbc:mysql://localhost:3306/testjdbc?useSSL=false&serverTimezone=Asia/Shanghai";
			
		//3.�������ӣ�������䣬��ý����
			conn = DriverManager.getConnection(db_url, "root", "111111");
			//System.out.println(conn);
			String sql = "select * from user where uname=? and pwd=?;";
			stmt = conn.prepareStatement(sql);
			stmt.setObject(1, uname);
			stmt.setObject(2, pwd);
			rs = stmt.executeQuery();
			
		//4.�鿴����������rsΪ�գ�userΪnull
			while (rs.next()) {
				user=new User();
				user.setId(rs.getInt("uid"));
				user.setUname(rs.getString("uname"));
				user.setPwd(rs.getString("pwd"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//5.��Դ����
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public User checkUidDao(String uid) {
		//1.���壺���ӣ���䣬�����
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		User user=null;
		
		//2.��������������db_url
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String db_url = "jdbc:mysql://localhost:3306/testjdbc?useSSL=false&serverTimezone=Asia/Shanghai";
			
		//3.�������ӣ�������䣬��ý����
			conn = DriverManager.getConnection(db_url, "root", "111111");
			//System.out.println(conn);
			String sql = "select * from user where uid=?;";
			stmt = conn.prepareStatement(sql);
			stmt.setObject(1, uid);
			rs = stmt.executeQuery();
			
		//4.�鿴����������rsΪ�գ�userΪnull
			while (rs.next()) {
				user=new User();
				user.setId(rs.getInt("uid"));
				user.setUname(rs.getString("uname"));
				user.setPwd(rs.getString("pwd"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//5.��Դ����
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
}
