package test.cookie;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * �����Ƿ��õ�cookie
 */
@WebServlet("/cookie02")
public class TestCookie02 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
		protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			//���ñ���
			req.setCharacterEncoding("utf-8");
			res.setContentType("text/html;charset:utf-8");
			res.setCharacterEncoding("GBK");
			//��ȡcookie
			Cookie[] cks=req.getCookies();
			for (Cookie cookie : cks) {
				res.getWriter().write(cookie.getName()+":"+cookie.getValue());
			}
		}
}
