package test.servletConfig;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ����ServletConfig
 */
@WebServlet("/servletConfig")
public class TestServletConfig extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//��Ϊ3.0�汾ʹ��ע��ʵ�֣��õ���web.xmlȫ�ǿ�����
		ServletConfig sc=this.getServletConfig();
		
		Enumeration<String> es=sc.getInitParameterNames();
		for(Enumeration<String> e=es;e.hasMoreElements();){
		    String thisName=e.nextElement().toString();
		    String thisValue=req.getParameter(thisName);
		    System.out.println(thisName+"--------------"+thisValue);
		} 
	}
}
