package test.session;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.pojo.User;

/**
 * ���Ե�¼�����show���ܲ���ͨ��session�õ��û�����
 */
@WebServlet("/session02")
public class TestSession02 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//1.����req��res����
		req.setCharacterEncoding("utf-8");
		res.setCharacterEncoding("GBK");
		res.setContentType("text/html;charset:utf-8");
		//2.��ȡsession�е�user
		User user=(User) req.getSession().getAttribute("user");
		//3.��Ӧ����		
		res.getWriter().write("<html>");
		res.getWriter().write("<head>");
		res.getWriter().write("<meta charset='UTF-8'>");
		res.getWriter().write("<title>");
		res.getWriter().write("��¼");
		res.getWriter().write("</title>");
		res.getWriter().write("</head>");
		res.getWriter().write("<body>");
		res.getWriter().write("<font size:2px>"+user.getUname()+"��Ϣ��"+"</font>");
		res.getWriter().write("<table>");
		res.getWriter().write("<tr>");
		res.getWriter().write("<td>�û�id��</td>");
		res.getWriter().write("<td>"+user.getId()+"</td");
		res.getWriter().write("</tr>");
		res.getWriter().write("<tr>");
		res.getWriter().write("<td>�û�����</td>");
		res.getWriter().write("<td>"+user.getUname()+"</td");
		res.getWriter().write("</tr>");
		res.getWriter().write("<tr>");
		res.getWriter().write("<td>���룺</td>");
		res.getWriter().write("<td>"+user.getPwd()+"</td");
		res.getWriter().write("</tr>");
		res.getWriter().write("</table>");
		res.getWriter().write("</body>");
		res.getWriter().write("</html>");
		//4.չʾ��Ϣ����sessionǿ��ʧЧ
		req.getSession().invalidate();
	}
}
