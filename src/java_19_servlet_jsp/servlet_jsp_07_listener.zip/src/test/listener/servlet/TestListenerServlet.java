package test.listener.servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * ����Listener��servlet
 */
@WebServlet("/listener.do")
public class TestListenerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("servletִ��");
		//����request��ؼ���
		req.setAttribute("newAttribute1", "value1");
		req.setAttribute("newAttribute2", "value2");
		req.removeAttribute("newAttribute1");
		req.setAttribute("newAttribute2", "new-value2");
		
		//����session��ؼ���
		HttpSession hs=req.getSession();
		hs.setAttribute("time1", new Date());
		hs.setAttribute("time2", new Date());
		hs.removeAttribute("time1");
		hs.setAttribute("time2", "value2");
		hs.invalidate();
		
		//����application��ؼ���
		ServletContext sc=this.getServletContext();
		sc.setAttribute("data1", "value1");
		sc.setAttribute("data2", "value2");
		sc.removeAttribute("data1");
		sc.setAttribute("data2", "new-value");
	}
}
