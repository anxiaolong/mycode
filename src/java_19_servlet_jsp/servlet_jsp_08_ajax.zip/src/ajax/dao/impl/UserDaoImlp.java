package ajax.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import test.ajax.dao.UserDao;
import test.ajax.pojo.User;

public class UserDaoImlp implements UserDao {

	@Override
	public List<User> getUserListDao(String uname) {
		//1.���壺���ӣ���䣬�����
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<User> userlist=new ArrayList<User>();
		//2.��������������db_url
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String db_url = "jdbc:mysql://localhost:3306/testjdbc?useSSL=false&serverTimezone=Asia/Shanghai";
			
		//3.�������ӣ�������䣬��ý����
			conn = DriverManager.getConnection(db_url, "root", "111111");
			//System.out.println(conn);
			String sql = "select * from t_user where uname like '%"+uname+"%';";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			
		//4.�鿴����������rsΪ�գ�userΪnull
			while (rs.next()) {
				User user=new User();
				user.setUname(rs.getString("uname"));
				user.setUid(rs.getInt("uid"));
				userlist.add(user);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//5.��Դ����
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userlist;
	}
}
