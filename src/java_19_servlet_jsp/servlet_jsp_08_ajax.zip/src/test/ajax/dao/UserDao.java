package test.ajax.dao;

import java.util.List;

import test.ajax.pojo.User;

public interface UserDao {
	public List<User> getUserListDao(String uname);
}
