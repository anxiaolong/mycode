package test;

import jdk.nashorn.internal.ir.annotations.Ignore;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import test.mapper.UserMapper;
import test.pojo.User;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * mybatis批量处理
 * 1.效率 foreach（10000/544ms）>BatchSession(10000/37276ms)>for insert(10000/56314ms)
 * 2.数据库对sql大小有限制，大量数据使用Batch模式处理更合适
 */
@SpringBootTest(classes = App.class)
public class TestMybatisBatch {
    @Resource
    UserMapper userMapper;
    @Resource
    SqlSessionFactory sessionFactory;

    @Test
    @Ignore
    public void test01(){
        List<User> users = userMapper.selAllUser();
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     * 1.测试mapper中使用#和$的取值的区别
     * #取值会将参数作为字符串处理，sql使用预编译sql
     * $直接取值放在sql中，直接执行sql，sql没有预编译有注入的风险
     */
    @Test
    @Ignore
    public void test02(){
        int index = userMapper.testInsert("anxiaolong","111111");
        System.out.println(index);
    }

    /**
     * 2.测试mybatis在mapper文件中使用foreach批量处理
     */
    @Test
    public void test03(){
        // mapper文件中使用foreach批量处理
        List<User> userList = new ArrayList<>();
        for (int i = 0; i < 10000; i++) {
            String randomString = UUID.randomUUID().toString().substring(0, 10);
            User user = new User();
            user.setName(randomString);
            user.setPwd(randomString);
            userList.add(user);
        }
        long start = System.currentTimeMillis();
        int i = userMapper.insertBatch(userList);
        long end = System.currentTimeMillis();
        System.out.println("foreach耗时:"+(end-start));
    }

    /**
     * 3.开一个批量处理的sqlsession
     */
    @Test
    public void test04(){
        // 开批量处理sessiion
        SqlSession sqlSession = sessionFactory.openSession(ExecutorType.BATCH);
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        long start1 = System.currentTimeMillis();
        for (int j = 0; j < 10000; j++) {
            String randomString = UUID.randomUUID().toString().substring(0, 10);
            User user = new User();
            user.setName(randomString);
            user.setPwd(randomString);
            mapper.saveUser(user);
        }
        sqlSession.commit();
        long end1 = System.currentTimeMillis();
        System.out.println("sqlsession耗时:"+(end1-start1));
    }

    @Test
    public void test05(){
        long start1 = System.currentTimeMillis();
        for (int j = 0; j < 10000; j++) {
            String randomString = UUID.randomUUID().toString().substring(0, 10);
            User user = new User();
            user.setName(randomString);
            user.setPwd(randomString);
            userMapper.saveUser(user);
        }
        long end1 = System.currentTimeMillis();
        System.out.println("逐条插入耗时:"+(end1-start1));
    }


}
