package test.mapper;

import org.apache.ibatis.annotations.Param;
import test.pojo.User;

import java.util.List;

public interface UserMapper {

    List<User> selAllUser();

    int saveUser(User user);

    int testInsert(@Param("name") String name,@Param("pwd") String pwd);

    int insertBatch(List<User> userList);

}
