package test.service;

import java.io.IOException;
import java.util.List;

import test.pojo.Student;

public interface ShowStudentService {

	List<Student> show(int curPage, int pageSize) throws IOException;
}
