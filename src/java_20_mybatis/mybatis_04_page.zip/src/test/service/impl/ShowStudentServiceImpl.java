package test.service.impl;
/**
 * ��ҳ��ѯ��service��
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import test.pojo.Student;
import test.service.ShowStudentService;

public class ShowStudentServiceImpl implements ShowStudentService {
	
	@Override
	public List<Student> show(int curPage,int pageSize) throws IOException {
		//��ȡSqlSession
		InputStream is=Resources.getResourceAsStream("mybatis.xml");
		SqlSessionFactory factory=new SqlSessionFactoryBuilder().build(is);
		SqlSession session=factory.openSession();
		
		HashMap<String, Object> map=new HashMap<String, Object>();
		//��ҳ��ѯ��ʽ����map���� select * from student limit(curPage-1)*pageSize,pageSize;
		map.put("p1", (curPage-1)*pageSize);
		map.put("p2", pageSize);
		List<Student> list=session.selectList("a.b.page", map);
//		for (Student student : list) {
//			System.out.println(student.getId()+"-"+student.getName()+"-"+student.getPwd());
//		}
		return list;
	}
	
}
