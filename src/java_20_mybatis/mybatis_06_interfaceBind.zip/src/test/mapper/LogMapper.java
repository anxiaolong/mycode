package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import test.pojo.Log;

public interface LogMapper {
	List<Log> selAll();
	List<Log> selByOutAndIn(String accOut,String accIn);
	List<Log> selByOutAndIn2(@Param("out") String accOut,@Param("in") String accIn);
}
