package test.test;
/**
 * ����mybatis�ӿڰ�Ч��
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import test.mapper.LogMapper;
import test.pojo.Log;

public class Test {
	public static void main(String[] args) throws IOException {
		//���sql�Ự����
		InputStream is=Resources.getResourceAsStream("mybatis.xml");
		SqlSessionFactory factory=new SqlSessionFactoryBuilder().build(is);
		SqlSession session=factory.openSession();
		
		//���Խӿڰ�
		LogMapper logMapper=session.getMapper(LogMapper.class);
		
		//�в����Ľӿ�
		List<Log> list=logMapper.selByOutAndIn("d", "a");
		for (Log log : list) {
			System.out.println(log);
		}
		
		//�޲����Ľӿ�
		List<Log> list2=logMapper.selAll();
		for (Log log : list2) {
			System.out.println(log);
		}
		
		//ʹ��ע��ʵ���в����Ľӿ�
		List<Log> list3=logMapper.selByOutAndIn2("d", "a");
		for (Log log : list3) {
			System.out.println(log);
		}
		session.close();
	}
}
