package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import test.pojo.Log;

public interface LogMapper {
	List<Log> selAll();
	List<Log> selByOutAndIn(String accOut,String accIn);
	List<Log> selByOutAndIn2(@Param("out") String accOut,@Param("instr") String accIn);
	List<Log> selByOutAndIn3(@Param("out") String accOut,@Param("instr") String accIn);
	List<Log> selByOutAndIn4(@Param("out") String accOut,@Param("instr") String accIn);
	List<Log> selByOutAndIn5(@Param("out") String accOut,@Param("instr") String accIn);
	int upd(Log log);
	List<Log> selBylog(Log log);
	List<Log> selIn(List<Integer> list);
	int insLog(List<Double> list);
	List<Log> selUseSql();
}
