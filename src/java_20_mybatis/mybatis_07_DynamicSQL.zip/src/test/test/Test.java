package test.test;
/**
 * ����mybatis�ӿڰ�Ч��
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import test.mapper.LogMapper;
import test.pojo.Log;

public class Test {
	public static void main(String[] args) throws IOException {
		//���sql�Ự����
		InputStream is=Resources.getResourceAsStream("mybatis.xml");
		SqlSessionFactory factory=new SqlSessionFactoryBuilder().build(is);
		SqlSession session=factory.openSession();
		
		//�ӿڰ�
		LogMapper logMapper=session.getMapper(LogMapper.class);
		
		//1.����if����
//		List<Log> list=logMapper.selByOutAndIn2("d", "");
//		for (Log log : list) {
//			System.out.println(log);
//		}
		
		//2.����where if����
//		List<Log> list=logMapper.selByOutAndIn3("", "b");
//		for (Log log : list) {
//			System.out.println(log);
//		}
		
		//3.����choose when otherwise
//		List<Log> list=logMapper.selByOutAndIn4("", "");
//		for (Log log : list) {
//			System.out.println(log);
//		}
		
		//4.����set��ǩ
//		Log log=new Log();
//		log.setAccIn("b");
//		log.setAccOut("c");
//		log.setMoney(888);
//		log.setId(8);
//		int index=logMapper.upd(log);
//		System.out.println(index);
//		session.commit();
		
		//5.����Trim��ǩ
//		List<Log> list=logMapper.selByOutAndIn5("", "a");
//		for (Log log : list) {
//			System.out.println(log);
//		}
		
		//6.����Bind��ǩ
//		Log log=new Log();
//		log.setAccOut("d");
//		List<Log> list=logMapper.selBylog(log);
//		for (Log log1 : list) {
//			System.out.println(log1);
//		}
		
		//7.����foreach��ǩ�ڲ�ѯ��ʹ��
//		List<Integer> list=new ArrayList<Integer>();
//		list.add(1);
//		list.add(3);
//		list.add(5);
//		List<Log> logliList=logMapper.selIn(list);
//		for (Log log : logliList) {
//			System.out.println(log);
//		}
		
		//8.����foreach��ǩ��insert��ʹ��
//		List<Double> list=new ArrayList<Double>();
//		list.add(22.2);
//		list.add(33.0);
//		list.add(55.8);
//		int index=logMapper.insLog(list);
//		System.out.println(index);
//		if (index==3) {
//			session.commit();
//		}else {
//			session.rollback();
//		}
		
		//9.����sql��ǩ��include��ǩ
		List<Log> list=logMapper.selUseSql();
		for (Log log : list) {
			System.out.println(log);
		}
	}
}
