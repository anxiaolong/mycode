package test.mapper;

import test.pojo.Log;

public interface LogMapper {
	int insLog(Log log);
}
