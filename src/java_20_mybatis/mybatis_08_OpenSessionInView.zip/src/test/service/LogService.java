package test.service;

import test.pojo.Log;

public interface LogService {
	int insLogService(Log log);
}
