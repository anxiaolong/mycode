package test.service.impl;

import org.apache.ibatis.session.SqlSession;

import test.Util.MybatisUtil;
import test.mapper.LogMapper;
import test.pojo.Log;
import test.service.LogService;

public class LogServiceImpl implements LogService {

	@Override
	public int insLogService(Log log) {
		//1.��ȡSqlSession
		SqlSession session=MybatisUtil.getSession();
		//2.�󶨽ӿڻ�ȡmapper����
		LogMapper logMapper=session.getMapper(LogMapper.class);
		//3.ʹ��mapper����ִ��sql�����ؽ��
		return logMapper.insLog(log);
	}

}
