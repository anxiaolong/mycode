package test.mapper;

import java.util.List;

import test.pojo.PageInfo;
import test.pojo.Student;

public interface StudentMapper {
	List<Student> selPage(PageInfo pi);
}
