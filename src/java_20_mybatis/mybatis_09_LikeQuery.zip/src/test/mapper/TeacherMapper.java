package test.mapper;

import org.apache.ibatis.annotations.Param;

import test.pojo.Teacher;

public interface TeacherMapper {
	Teacher selById(@Param("tid")int id);
}
