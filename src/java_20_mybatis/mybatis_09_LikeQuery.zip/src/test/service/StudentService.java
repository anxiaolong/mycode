package test.service;

import java.util.List;

import test.pojo.Student;

public interface StudentService {
	List<Student> showPage(int pageSize,int pageNum,String t_name,String s_name);
}
