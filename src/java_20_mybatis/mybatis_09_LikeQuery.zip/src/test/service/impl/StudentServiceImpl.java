package test.service.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import test.Util.MybatisUtil;
import test.mapper.StudentMapper;
import test.mapper.TeacherMapper;
import test.pojo.PageInfo;
import test.pojo.Student;
import test.service.StudentService;

public class StudentServiceImpl implements StudentService {

	@Override
	public List<Student> showPage(int pageSize, int pageNum,String t_name,String s_name) {
		//1.��ȡSqlSession
		SqlSession session=MybatisUtil.getSession();
		//2.����studentmapper
		StudentMapper studentMapper=session.getMapper(StudentMapper.class);
		//3.����pageinfo����
		PageInfo pi=new PageInfo();
		pi.setPageNum(pageNum);
		pi.setPageSize(pageSize);
		pi.setS_name(s_name);
		pi.setT_name(t_name);
		//4.ִ�з�ҳ��ѯ
		List<Student> studentliList=studentMapper.selPage(pi);
		//5.��ȡ��ʦ����
		TeacherMapper teacherMapper=session.getMapper(TeacherMapper.class);
		for (Student student : studentliList) {
			student.setTeacher(teacherMapper.selById(student.getT_id()));
		}
		return studentliList;
	}
}
