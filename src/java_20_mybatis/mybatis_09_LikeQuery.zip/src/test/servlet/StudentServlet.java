package test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import test.pojo.Student;
import test.service.impl.StudentServiceImpl;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/student")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StudentServiceImpl serviceImpl=new StudentServiceImpl();
	
	@Override
		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			//�����������
			String t_name="";
			String s_name="";
			if (req.getParameter("t_name")!=null&&req.getParameter("s_name")!=null) {
				t_name=new String(req.getParameter("t_name").getBytes("iso8859-1"),"utf-8");
				s_name=new String(req.getParameter("s_name").getBytes("iso8859-1"),"utf-8");
			}
			if (req.getParameter("pageSize")==null&&req.getParameter("pageNum")==null) {
				req.getRequestDispatcher("student?pageSize=3&pageNum=1"+
						"&t_name="+t_name+"&s_name="+s_name).forward(req, resp);
			}else {
				//1.����service�㴦��
				List<Student> slist=serviceImpl.showPage(Integer.parseInt(req.getParameter("pageSize")), 
						Integer.parseInt(req.getParameter("pageNum")),
						t_name,s_name);
				//2.��Ӧ��ҳ��
				req.setAttribute("slist", slist);
				req.getRequestDispatcher("query.jsp").forward(req, resp);
			}
			
		}
}
