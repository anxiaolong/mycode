package test.pojo;

import java.util.List;

public class Teacher {
	private int id;
	private String t_name;
	private List<Student> list;
	public List<Student> getList() {
		return list;
	}
	public void setList(List<Student> list) {
		this.list = list;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getT_name() {
		return t_name;
	}
	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", t_name=" + t_name + ", list=" + list + "]";
	}
	
	
	
	
}
