package test.resultMap;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import test.Util.MybatisUtil;
import test.pojo.Student;
import test.pojo.Teacher;

public class TestResultMap {
	public static void main(String[] args) {
		SqlSession session=MybatisUtil.getSession();
		
		//����resultMap N+1��ʽ��ѯ��������
		List<Student> list=session.selectList("test.mapper.StudentMapper.selAll");
		for (Student student : list) {
			System.out.println(student);
		}
		
		System.out.println("----------------------------------------");
		
		//����resultMap ���ϲ�ѯ��������
		List<Student> list1=session.selectList("test.mapper.StudentMapper.selAll1");
		for (Student student : list1) {
			System.out.println(student);
		}
		
		System.out.println("----------------------------------------");
		
		//����resultMap n+1��ʽ��ѯ���϶���
		List<Teacher> list2=session.selectList("test.mapper.TeacherMapper.selAll1");
		for (Teacher teacher : list2) {
			System.out.println(teacher);
		}
		
		System.out.println("----------------------------------------");
		
		//����resultMap ���ϲ�ѯ��ʽ��ѯ���϶���
		List<Teacher> list3=session.selectList("test.mapper.TeacherMapper.selAll2");
		for (Teacher teacher : list3) {
			System.out.println(teacher);
		}
		
		System.out.println("----------------------------------------");
		
		//����Auto Mapping��ѯ
		List<Student> list4=session.selectList("test.mapper.StudentMapper.selAll2");
		for (Student student : list4) {
			System.out.println(student);
		}
	}
}
