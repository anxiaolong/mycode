package test.annotation;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import test.Util.MybatisUtil;
import test.mapper.StudentMapper;
import test.mapper.TeacherMapper;
import test.pojo.Student;
import test.pojo.Teacher;

public class TestAnnotation {
	public static void main(String[] args) {
		SqlSession session=MybatisUtil.getSession();
		StudentMapper studentMapper=session.getMapper(StudentMapper.class);
		TeacherMapper teacherMapper=session.getMapper(TeacherMapper.class);
		
		//����ע��ʵ�ֲ�ѯ��������
		List<Student> selAll = studentMapper.selAll();
		for (Student student : selAll) {
			System.out.println(student);
		}
		
		//����ע���ѯ���϶���
		List<Teacher> selAll2 = teacherMapper.selAll();
		for (Teacher teacher : selAll2) {
			System.out.println(teacher);
		}
		
		//����ע��ʵ��update
//		Student student=new Student();
//		student.setId(2);
//		student.setName("�ν�ȫupd");
//		student.setPwd("123456");
//		student.setTid(2);
//		int upd = studentMapper.upd(student);
//		System.out.println(upd);
		
		//����ע��ʵ��ɾ��
		//int del = studentMapper.del(11);
		//System.out.println(del);
		
		//����ע��ʵ��insert
		//int ins = studentMapper.ins(student);
		//System.out.println(ins);
		
		
		//session.commit();
	}
}
