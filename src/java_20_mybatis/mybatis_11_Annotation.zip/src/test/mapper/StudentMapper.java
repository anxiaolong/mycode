package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import test.pojo.Student;

public interface StudentMapper {
	//ʹ��ע���ѯ��������
	@Results(value = {
			@Result(property = "tid",column = "t_id"),
			@Result(property = "teacher",column = "t_id",
			one = @One(select = "test.mapper.TeacherMapper.selById"))
	})
	@Select("select * from student")
	List<Student> selAll();
	
	@Select("select * from student where t_id=#{tid}")
	List<Student> selByTid(int tid);
	
	@Update("update student set name=#{name} where id=#{id}")
	int upd(Student student);
	
	@Delete("delete from student where id=#{id}")
	int del(int id);
	
	@Insert("insert into student (id,name,pwd,t_id) value (default,#{name},#{pwd},#{tid})")
	int ins(Student student);
}
