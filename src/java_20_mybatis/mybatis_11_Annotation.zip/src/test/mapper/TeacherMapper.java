package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import test.pojo.Teacher;

public interface TeacherMapper {
	@Select("select * from teacher where id=#{tid}")
	Teacher selById();
	
	@Results(value = {
			@Result(id = true,property = "id",column = "id"),
			@Result(property = "t_name",column = "t_name"),
			@Result(property = "list",column = "id",
			many = @Many(select = "test.mapper.StudentMapper.selByTid"))
	})
	@Select("select * from teacher")
	List<Teacher> selAll();
}
