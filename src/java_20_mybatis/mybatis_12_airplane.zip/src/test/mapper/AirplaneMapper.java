package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import test.pojo.Airplane;

public interface AirplaneMapper {
	//��ѯ�����зɻ�����
	List<Airplane> selAllAirplanes(@Param("tid") int takeid,@Param("lid") int landid);

}
