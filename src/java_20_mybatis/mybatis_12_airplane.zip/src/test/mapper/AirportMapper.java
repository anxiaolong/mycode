package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import test.pojo.Airport;

public interface AirportMapper {
	@Select("SELECT * FROM airport WHERE id in (SELECT DISTINCT takePortId FROM airplane)")
	List<Airport> selTakePorts();
	
	@Select("SELECT * FROM airport WHERE id in (SELECT DISTINCT landPortId FROM airplane)")
	List<Airport> selLandPorts();
	
	@Select("SELECT * from airport WHERE id=#{id}")
	Airport selByid(int id);
}
