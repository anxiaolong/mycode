package test.pojo;

public class Airplane {
	private int id;
	private String airNo;
	private int time;
	private double price;
	private int takePortId;
	private int landPortId;
	private Airport takeAirport;
	private Airport landAirport;
	
	
	public Airport getTakeAirport() {
		return takeAirport;
	}
	public void setTakeAirport(Airport takeAirport) {
		this.takeAirport = takeAirport;
	}
	public Airport getLandAirport() {
		return landAirport;
	}
	public void setLandAirport(Airport landAirport) {
		this.landAirport = landAirport;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAirNo() {
		return airNo;
	}
	public void setAirNo(String airNo) {
		this.airNo = airNo;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getTakePortId() {
		return takePortId;
	}
	public void setTakePortId(int takePortId) {
		this.takePortId = takePortId;
	}
	public int getLandPortId() {
		return landPortId;
	}
	public void setLandPortId(int landPortId) {
		this.landPortId = landPortId;
	}
	@Override
	public String toString() {
		return "Airplane [id=" + id + ", airNo=" + airNo + ", time=" + time + ", price=" + price + ", takePortId="
				+ takePortId + ", landPortId=" + landPortId + ", takeAirport=" + takeAirport + ", landAirport="
				+ landAirport + "]";
	}
}
