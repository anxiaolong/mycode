package test.service;

import java.util.List;

import test.pojo.Airplane;

public interface AirplaneService {
	List<Airplane> showAirplanesService(int takeid,int landid);
}
