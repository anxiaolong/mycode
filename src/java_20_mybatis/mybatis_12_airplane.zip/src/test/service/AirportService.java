package test.service;

import java.util.List;

import test.pojo.Airport;

public interface AirportService {
	
	List<Airport> showTakeAirportsService();
	
	List<Airport> showLandAirportsService();
	
}
