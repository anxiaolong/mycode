package test.service.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import test.Util.MybatisUtil;
import test.mapper.AirplaneMapper;
import test.pojo.Airplane;
import test.service.AirplaneService;

public class AirplaneServiceImpl implements AirplaneService {

	@Override
	public List<Airplane> showAirplanesService(int takeid, int landid) {
		SqlSession session = MybatisUtil.getSession();
		AirplaneMapper airplaneMapper=session.getMapper(AirplaneMapper.class);
		List<Airplane> listAirplanes = airplaneMapper.selAllAirplanes(takeid, landid);
		return listAirplanes;
	}
}
