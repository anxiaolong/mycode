package test.service.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import test.Util.MybatisUtil;
import test.mapper.AirportMapper;
import test.pojo.Airport;
import test.service.AirportService;

public class AirportServiceImpl implements AirportService {

	@Override
	public List<Airport> showTakeAirportsService() {
		AirportMapper airportMapper=getAirportMapper();
		List<Airport> listTakePorts = airportMapper.selTakePorts();
		return listTakePorts;
	}

	@Override
	public List<Airport> showLandAirportsService() {
		AirportMapper airportMapper=getAirportMapper();
		List<Airport> listLandPorts = airportMapper.selLandPorts();
		return listLandPorts;
	}
	
	public AirportMapper getAirportMapper() {
		SqlSession session = MybatisUtil.getSession();
		AirportMapper airportMapper=session.getMapper(AirportMapper.class);
		return airportMapper;
	}
	
}
