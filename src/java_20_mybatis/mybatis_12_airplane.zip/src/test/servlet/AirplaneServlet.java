package test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.pojo.Airplane;
import test.service.impl.AirplaneServiceImpl;
import test.service.impl.AirportServiceImpl;

/**
 * Servlet implementation class AirplaneServlet
 */
@WebServlet("/air")
public class AirplaneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private AirportServiceImpl asi=new AirportServiceImpl();
	private AirplaneServiceImpl apsi=new AirplaneServiceImpl();
	
	@Override
		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			//����service��ȡ���������Ϣ
			req.setAttribute("takeList", asi.showTakeAirportsService());
			req.setAttribute("landList", asi.showLandAirportsService());
		
			//��ȡ��ѯ����
			String takeid = req.getParameter("tid");
			String landid = req.getParameter("lid");
			int tid=0;
			int lid=0;
			if (takeid!=null&&!takeid.equals("")) {
				tid=Integer.parseInt(takeid);
			}
			if (landid!=null&&!landid.equals("")) {
				lid=Integer.parseInt(landid);
			}
			//����service�㴦��
			List<Airplane> listAirplanes = apsi.showAirplanesService(tid, lid);
			req.setAttribute("listAirplanes", listAirplanes);
			//�������ת����jsp��ʾ
			req.getRequestDispatcher("airplane.jsp").forward(req, resp);
		}
}
