package test.pojo;

public class PeopleFactory {
	public People newInstance() {
		return new People(1, "testFactory");
	}
}
