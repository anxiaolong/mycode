package test.pojo;

public class PeopleStaticFactory {
	public static People newInstance() {
		return new People(2, "staticFactory");
	}
}
