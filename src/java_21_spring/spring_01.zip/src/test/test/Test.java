package test.test;
/**
 * ����spring��������
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test.pojo.People;

public class Test {
	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("applicationContext.xml");
		People people=ac.getBean("peo", People.class);
		People people2 = ac.getBean("peo1", People.class);
		People people3 = ac.getBean("peo2", People.class);
		People people4 = ac.getBean("peo3", People.class);
		System.out.println(people+"--"+people2);
		System.out.println(people3);
		System.out.println(people4);
		
		//���Զ���Ĵ�������
		String[] names=ac.getBeanDefinitionNames();
		for (String string : names) {
			System.out.println(string);
		}
	}
}
