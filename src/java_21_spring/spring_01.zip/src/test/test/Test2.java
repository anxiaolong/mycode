package test.test;
/**
 * ����spring��������ע����Ϣ
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import test.pojo.Desk;
import test.pojo.Student;

public class Test2 {
	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("applicationContext.xml");
		Desk desk=ac.getBean("desk", Desk.class);
		System.out.println(desk);
		Student student=ac.getBean("stu", Student.class);
		System.out.println(student);
		//���Զ���Ĵ�������
		System.out.println("-----------------------------------");
		String[] names=ac.getBeanDefinitionNames();
		for (String string : names) {
			System.out.println(string);
		}
	}
}
