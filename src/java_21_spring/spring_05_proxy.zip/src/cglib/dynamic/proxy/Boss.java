package cglib.dynamic.proxy;

public class Boss {
	public void ChiFan() {
		System.out.println("boss�Է�");
	}
	
	public void Jueding() {
		System.out.println("boss����");
	}
}
