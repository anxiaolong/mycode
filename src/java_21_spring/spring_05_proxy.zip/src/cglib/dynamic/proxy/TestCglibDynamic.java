package cglib.dynamic.proxy;
/**
 * ����cglib��̬����
 */
import net.sf.cglib.proxy.Enhancer;

public class TestCglibDynamic {
	public static void main(String[] args) {
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(Boss.class);
		enhancer.setCallback(new Mishu());
		
		Boss boss=(Boss)enhancer.create();
		boss.ChiFan();
		boss.Jueding();
	}
}
