package jdk.dynamic.proxy;
/**
 * boss��
 * @author Administrator
 *
 */
public class Boss implements GongNeng {

	@Override
	public void ChiFan() {
		System.out.println("boss�Է�");
		
	}

	@Override
	public void ZuoJueDing() {
		System.out.println("boss����");
		
	}

	
}
