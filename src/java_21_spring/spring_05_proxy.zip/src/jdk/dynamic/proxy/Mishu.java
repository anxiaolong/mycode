package jdk.dynamic.proxy;
/**
 * jdk��̬����ʵ�ֺ��Ĵ���
 */
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class Mishu implements InvocationHandler {
	private Boss boss=new Boss();
		
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		System.out.println("ԤԼ");
		Object result=method.invoke(boss, args);
		System.out.println("��¼�ÿ���Ϣ");
		return result;
	}
	
}
