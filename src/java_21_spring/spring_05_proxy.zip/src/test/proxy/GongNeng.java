package test.proxy;
/**
 * ���ܽӿ�
 * @author Administrator
 *
 */
public interface GongNeng {
	
	public void ChiFan();
	
	public void ZuoJueDing();
	
}
