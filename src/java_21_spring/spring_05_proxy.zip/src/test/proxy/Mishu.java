package test.proxy;

public class Mishu implements GongNeng {
	private Boss boss=new Boss();

	@Override
	public void ChiFan() {
		System.out.println("ԤԼ");
		boss.ChiFan();
		System.out.println("��¼�ÿ���Ϣ");
		
	}

	@Override
	public void ZuoJueDing() {
		System.out.println("ԤԼ");
		boss.ZuoJueDing();
		System.out.println("��¼�ÿ���Ϣ");
		
	}
	
	
}
