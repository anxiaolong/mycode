package test.mapper;

import java.util.List;

import test.pojo.T_user;

public interface T_userMapper {
	public List<T_user> selAll();
}
