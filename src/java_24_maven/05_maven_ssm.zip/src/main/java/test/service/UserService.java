package test.service;

import java.util.List;

import test.pojo.T_user;

public interface UserService {
	public List<T_user> selAll();
}
