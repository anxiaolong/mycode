package test.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import test.mapper.T_userMapper;
import test.pojo.T_user;
import test.service.UserService;
@Service
public class UserServiceImpl implements UserService {
	@Resource
	private T_userMapper t_userMapper;
	
	@Override
	public List<T_user> selAll() {
		List<T_user> list = t_userMapper.selAll();
		return list;
	}

}
