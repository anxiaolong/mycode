package test.controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import test.pojo.User;
import test.service.UserService;

@Controller
public class UserController {
	@Resource
	private UserService userServiceImpl;
	
	@RequestMapping("/")
	public String goManage() {
		return "redirect:/manage.jsp";
	}
	
	@RequestMapping("addUser")
	@ResponseBody
	public void addUser(User user,HttpServletResponse res) throws IOException {
		try {
			int addUser = userServiceImpl.addUser(user);
			if (addUser==1) {
				res.getWriter().write("success");
			}else {
				res.getWriter().write("fail");
			}
		} catch (Exception e) {
			e.printStackTrace();
			res.getWriter().write("fail");
		}
	}
}
