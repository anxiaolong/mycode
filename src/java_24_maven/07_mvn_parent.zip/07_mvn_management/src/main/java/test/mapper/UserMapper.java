package test.mapper;

import test.pojo.User;

public interface UserMapper {
	int insUser(User user);
}
