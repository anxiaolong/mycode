package test.service;

import test.pojo.User;

public interface UserService {
	int addUser(User user);
}
