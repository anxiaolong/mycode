package test.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import test.mapper.UserMapper;
import test.pojo.User;
import test.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Resource
	private UserMapper userMapper;
	
	@Override
	public int addUser(User user) {
		return userMapper.insUser(user);
	}

}
