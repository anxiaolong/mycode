package test.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import test.pojo.User;
import test.service.UserService;

@Controller
public class UserController {
	@Resource
	private UserService userServiceImpl;
	
	@RequestMapping("show")
	public String getAllUser(HttpServletRequest req,HttpServletResponse res) {
		List<User> list = userServiceImpl.selAll();
		req.setAttribute("users", list);
		return "show.jsp";
	}
}
