package test.controller;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import test.pojo.User;
import test.service.UserService;

@Controller
public class UserController {
	@Resource
	private UserService userServiceImpl;
	
	//����produces����Ч
	@RequestMapping(value = "show",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String getAllUsers() {
		List<User> list = userServiceImpl.showall();
		return JSON.toJSONString(list);
	}
}
