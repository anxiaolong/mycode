package test.service;

import java.util.List;

import test.pojo.User;

public interface UserService {
	List<User> showall();
}
