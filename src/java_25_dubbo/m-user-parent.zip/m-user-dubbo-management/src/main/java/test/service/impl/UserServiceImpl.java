package test.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.alibaba.dubbo.config.annotation.Reference;

import m_user.dubbo.service.UserDubboService;
import test.pojo.User;
import test.service.UserService;
@Service
public class UserServiceImpl implements UserService {
	@Reference //ʹ��dubbo��ע��ע�����
	private UserDubboService userDubboService;
	
	@Override
	public List<User> showall() {
		return userDubboService.selAllUser();
	}

}
