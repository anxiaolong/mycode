package test.dubbo.service.impl;

import java.util.List;

import javax.annotation.Resource;

import m_user.dubbo.service.UserDubboService;
import test.mapper.UserMapper;
import test.pojo.User;

public class UserDubboServiceImpl implements UserDubboService {
	@Resource
	private UserMapper userMapper;
	
	@Override
	public List<User> selAllUser() {
		return userMapper.selAllUser();
	}

}
