package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import test.pojo.User;

public interface UserMapper {
	@Select("select * from m_user")
	List<User> selAllUser();
}
