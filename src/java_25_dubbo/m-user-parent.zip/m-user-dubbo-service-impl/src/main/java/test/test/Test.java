package test.test;

import com.alibaba.dubbo.container.Main;

public class Test {
	public static void main(String[] args) {
		Main.main(args);
	}
}
