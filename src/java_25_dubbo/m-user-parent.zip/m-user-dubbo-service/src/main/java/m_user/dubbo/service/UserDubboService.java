package m_user.dubbo.service;

import java.util.List;

import test.pojo.User;

public interface UserDubboService {
	List<User> selAllUser();
}
