package test;

import java.util.HashSet;
import java.util.Set;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

public class TestJedis {
	public static void main(String[] args) {
		HostAndPort node1=new HostAndPort("127.0.0.1", 9001);
		HostAndPort node2=new HostAndPort("127.0.0.1", 9002);
		HostAndPort node3=new HostAndPort("127.0.0.1", 9003);
		HostAndPort node4=new HostAndPort("127.0.0.1", 9004);
		HostAndPort node5=new HostAndPort("127.0.0.1", 9005);
		HostAndPort node6=new HostAndPort("127.0.0.1", 9005);
		Set<HostAndPort> nodes=new HashSet<HostAndPort>();
		nodes.add(node1);
		nodes.add(node2);
		nodes.add(node3);
		nodes.add(node4);
		nodes.add(node5);
		nodes.add(node6);
		JedisCluster clients=new JedisCluster(nodes);
		System.out.println(clients.get("name"));
		clients.close();
	}
}
