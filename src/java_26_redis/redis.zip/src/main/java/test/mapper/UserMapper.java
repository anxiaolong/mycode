package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import test.pojo.User;

public interface UserMapper {
	@Select("SELECT * FROM user")
	List<User> selAllUsers();
}
