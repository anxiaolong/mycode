package test.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;

import redis.dao.JedisClusterDao;
import test.mapper.UserMapper;
import test.pojo.User;
import test.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Resource
	private UserMapper userMapper;
	@Resource
	private JedisClusterDao jedisClusterDaoImpl;
	
	@Override
	public List<User> selAllUsers() {
		//����redis
		//System.out.println("jedisClusterDaoImpl.exists(\"users\"):"+jedisClusterDaoImpl.exists("users"));
		//System.out.println("jedisClusterDaoImpl.get(\"users\"):"+jedisClusterDaoImpl.get("users"));
		
		
		if (jedisClusterDaoImpl.exists("users")) {
			String value = jedisClusterDaoImpl.get("users");
			if (value!=null&&!value.equals("")) {
				List<User> list = JSON.parseArray(value, User.class);
				return list;
			}else {
				List<User> list = userMapper.selAllUsers();
				jedisClusterDaoImpl.set("users", JSON.toJSONString(list));
				return list;
			}
		}else {
			List<User> list = userMapper.selAllUsers();
			jedisClusterDaoImpl.set("users", JSON.toJSONString(list));
			return list;
		}
	}

}
