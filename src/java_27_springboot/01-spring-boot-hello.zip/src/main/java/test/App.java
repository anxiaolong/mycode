package test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App {
	//1.启动器位置需要放在controller同一目录或者上级目录，否则不生效
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}

}
