package test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@SpringBootApplication
@ServletComponentScan //扫描servlet注解，并实例化servlet
public class App {
	//1.启动器位置需要放在controller同一目录或者上级目录，否则不生效
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}

}
