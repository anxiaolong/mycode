package test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;

import test.servlet.TestServlet;

@SpringBootApplication
public class App {
	//1.启动器位置需要放在controller同一目录或者上级目录，否则不生效
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
	
	@Bean //2.通过方法完成servlet组件注册
	public ServletRegistrationBean<TestServlet> getRegistrationBean() {
		ServletRegistrationBean<TestServlet> bean=
				new ServletRegistrationBean<TestServlet>(new TestServlet());
		bean.addUrlMappings("/servlet");
		return bean;
	}

}
