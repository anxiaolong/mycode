package test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import test.servlet.TestFilter;


@SpringBootApplication
public class App {
	//1.启动器位置需要放在controller同一目录或者上级目录，否则不生效
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
	
	//2.通过方法注册filter
	@Bean
	public FilterRegistrationBean<TestFilter> getFilterRegistrationBean() {
		FilterRegistrationBean<TestFilter> bean = 
				new FilterRegistrationBean<TestFilter>(new TestFilter());
		return bean;
	}
	
}
