package test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;

import test.servlet.TestListener;


@SpringBootApplication
public class App {
	//1.启动器位置需要放在controller同一目录或者上级目录，否则不生效
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
	
	//2.通过方法注册listener
	@Bean
	public ServletListenerRegistrationBean<TestListener> getListenerRegistrationBean() {
		ServletListenerRegistrationBean<TestListener> bean = 
				new ServletListenerRegistrationBean<TestListener>(new TestListener());
		return bean;
	}
}
