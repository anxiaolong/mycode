package test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {
	
	@RequestMapping("test1")
	public String test1() {
		return "1.txt";//浏览器里直接显示文本
	}
	
	@RequestMapping("test2")
	public String test2() {
		return "2.html";//浏览器下载jsp文件
	}
	
	@RequestMapping("test3")
	public String test3() {
		return "image/1.jpg";//浏览器下载jsp文件
	}
}
