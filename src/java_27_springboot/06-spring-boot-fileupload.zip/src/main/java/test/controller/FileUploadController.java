package test.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController //所有方法响应需要转json
public class FileUploadController {

	@RequestMapping("/fileUpload")
	public Map<String, Object> fileUpload(String fname,MultipartFile file) throws IllegalStateException, IOException {
		System.out.println(fname);
		file.transferTo(new File("E:/"+fname+"-"+file.getOriginalFilename()));
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("success", "上传成功");
		return map;
	}
}
