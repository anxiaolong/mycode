package test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import test.pojo.User;

@Controller
public class TestController {
	
	@RequestMapping(value = "show")
	public String show(Model model) {
		List<User> list = new ArrayList<User>();
		list.add(new User(1, "test1", "11123"));
		list.add(new User(2, "test2", "454ggg"));
		list.add(new User(3, "test3", "gghghgh"));
		model.addAttribute("list", list);
		return "show";
	}
}
