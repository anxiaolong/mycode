package test.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import test.pojo.User;

@Controller
public class TestController {
	
	@RequestMapping(value = "show1")
	public String show(Model model) {
		List<User> list = new ArrayList<User>();
		list.add(new User(1, "test1", "11123"));
		list.add(new User(2, "test2", "454ggg"));
		list.add(new User(3, "test3", "gghghgh"));
		model.addAttribute("list", list);
		model.addAttribute("date1", new Date());
		return "show1";
	}
	
	@RequestMapping(value = "show2")
	public String show2(Model model) {
		model.addAttribute("sex", "男");
		model.addAttribute("id", "2");
		List<User> list = new ArrayList<User>();
		list.add(new User(1, "test1", "11123"));
		list.add(new User(2, "test2", "454ggg"));
		list.add(new User(3, "test3", "gghghgh"));
		model.addAttribute("list", list);
		Map<String, User> map = new TreeMap<String, User>();
		map.put("u1", new User(1, "test1", "11123"));
		map.put("u2", new User(2, "test2", "454ggg"));
		map.put("u3", new User(3, "test3", "gghghgh"));
		model.addAttribute("map1", map);
		return "show2";
	}
	
	@RequestMapping(value = "show3")
	public String show3(HttpServletRequest req) {
		req.setAttribute("req", "req-msg");
		req.getSession().setAttribute("session", "session-msg");
		req.getSession().getServletContext().setAttribute("app", "servletContext-msg");
		return "show3";
	}
}
