package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import test.pojo.User;

public interface UserMapper {
	
	List<User> selAllUsers();
	
	int insUser(User user);
	
	int delUserById(@Param("id") String id);
	
	int updUserById(User user);
	
	User selUserById(@Param("id") String id);
}
