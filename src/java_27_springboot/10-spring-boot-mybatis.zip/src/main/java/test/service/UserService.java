package test.service;

import java.util.List;

import test.pojo.User;

public interface UserService {
	
	List<User> selAllUsers();
	
	int delUserById(String id);
	
	int insUser(User user);
	
	User selUserById(String id);
	
	int updUserById(User user);
}
