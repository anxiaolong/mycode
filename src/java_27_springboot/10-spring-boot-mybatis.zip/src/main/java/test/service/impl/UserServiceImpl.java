package test.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import test.mapper.UserMapper;
import test.pojo.User;
import test.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	@Resource
	private UserMapper userMapper;

	@Override
	public List<User> selAllUsers() {
		return userMapper.selAllUsers();
	}

	@Override
	public int delUserById(String id) {
		int index = userMapper.delUserById(id);
		return index;
	}

	@Override
	public int insUser(User user) {
		int index = userMapper.insUser(user);
		return index;
	}

	@Override
	public User selUserById(String id) {
		User user = userMapper.selUserById(id);
		return user;
	}

	@Override
	public int updUserById(User user) {
		int index = userMapper.updUserById(user);
		return index;
	}
}
