package test.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import test.pojo.User;
import test.service.UserService;

@Controller
public class UserController {
	@Resource
	private UserService userServiceImpl;
	
	@RequestMapping(value = "show")
	public String show(Model model) {
		List<User> list = userServiceImpl.selAllUsers();
		model.addAttribute("users", list);
		return "show";
	}
	
	@RequestMapping("delUser")
	public String delUser(String id,Model model) {
		int index = userServiceImpl.delUserById(id);
		if (index==1) {
			model.addAttribute("result", "删除成功");
		}else {
			model.addAttribute("result", "删除失败");
		}
		
		return "result";
	}
	
	//1.新增用户页面增加user对象，名字要和对象名一致，或使用注解
	@RequestMapping("add")
	public String toAdd(@ModelAttribute("validate") User user) {
		return "add";
	}
	
	//2.添加校验注解，和注入新名词注解
	@RequestMapping("addUser")
	public String addUser(@ModelAttribute("validate") @Valid User user,BindingResult result,Model model) {
		System.out.println(result.hasErrors());
		if (result.hasErrors()) {
			return "add";
		}else {
			int index = userServiceImpl.insUser(user);
			if (index==1) {
				model.addAttribute("result", "新增user成功");
			}else {
				model.addAttribute("result", "新增user失败");
			}
		}
		return "result";
	}
	
	@RequestMapping("getUser")
	public String updUser(String id,Model model) {
		User user = userServiceImpl.selUserById(id);
		model.addAttribute("user", user);
		return "update";
	}
	
	@RequestMapping(value = "updUser")
	public String updUser(User user,Model model) {
		int index = userServiceImpl.updUserById(user);
		if (index==1) {
			model.addAttribute("result", "修改用户信息成功");
		}else {
			model.addAttribute("result", "修改用户信息失败");
		}
		return "result";
	}
}
