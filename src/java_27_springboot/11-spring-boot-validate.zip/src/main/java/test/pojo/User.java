package test.pojo;

import java.io.Serializable;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.Length;


public class User implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "用户编号不能为空，前后去空格")
	@Length(max = 10,min = 6,message = "用户编号为6~10个字符")
	private String id;
	
	@NotBlank(message = "姓名不能为空")
	private String name;
	
	@Max(value = 150)
	@Min(value = 1)
	private int age;
	
	@NotEmpty(message = "性别不能为空，可设置为空格")
	private String sex;
	
	@Email(message = "请输入合法的邮箱地址")
	private String email;
	
	

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", age=" + age + ", sex=" + sex + ", email=" + email + "]";
	}
	
	

}
