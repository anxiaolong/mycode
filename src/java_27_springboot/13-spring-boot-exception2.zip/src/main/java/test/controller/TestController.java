package test.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {
	//1.测试空指针异常
	@SuppressWarnings("null")
	@RequestMapping("test1")
	@ResponseBody
	public Map<String, Object> test1() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", 1);
		map.put("name", "刘德华");
		map.put("sex", "男");
		
		//1.重写error页面，处理异常
		//a./src/main/resources/templates/error.html 名字必须是error
		String tstr=null;
		System.out.println(tstr.length());
		
		return map;
	}
	
	//2.测试数学计算异常
	@RequestMapping("test2")
	@ResponseBody
	public Map<String, Object> test2() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", 1);
		map.put("name", "刘德华");
		map.put("sex", "男");
		
		//1.重写error页面，处理异常
		//a./src/main/resources/templates/error.html 名字必须是error
		System.out.println(5/0);
		
		return map;
	}
	
	//单独处理一个特定的异常
	@ExceptionHandler(value = {java.lang.ArithmeticException.class})
	public ModelAndView arithmeticException(Exception e) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("error", e.toString());
		mv.setViewName("error1");
		return mv;
	}
	
	@ExceptionHandler(value = {java.lang.NullPointerException.class})
	public ModelAndView nullPointerException(Exception e) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("error", e.toString());
		mv.setViewName("error2");
		return mv;
	}
}
