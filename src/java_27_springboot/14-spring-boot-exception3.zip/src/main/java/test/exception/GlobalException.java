package test.exception;
/**
 * @ControllerAdvice @ExceptionHandler
 * 建一个类处理全局异常
 */
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalException {
	/**
	 * ArithmeticException异常处理方法
	 * @param e 产生的异常对象注入方法中
	 * @return
	 */
	@ExceptionHandler(value = {java.lang.ArithmeticException.class})
	public ModelAndView arithmeticException(Exception e) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("error", e.toString());
		mv.setViewName("error1");
		return mv;
	}
	
	@ExceptionHandler(value = {java.lang.NullPointerException.class})
	public ModelAndView nullPointerException(Exception e) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("error", e.toString());
		mv.setViewName("error2");
		return mv;
	}
}
