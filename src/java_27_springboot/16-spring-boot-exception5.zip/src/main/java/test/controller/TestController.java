package test.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TestController {
	//1.测试空指针异常
	@SuppressWarnings("null")
	@RequestMapping("test1")
	@ResponseBody
	public Map<String, Object> test1() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", 1);
		map.put("name", "刘德华");
		map.put("sex", "男");
		
		//1.重写error页面，处理异常
		//a./src/main/resources/templates/error.html 名字必须是error
		String tstr=null;
		System.out.println(tstr.length());
		
		return map;
	}
	
	//2.测试数学计算异常
	@RequestMapping("test2")
	@ResponseBody
	public Map<String, Object> test2() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", 1);
		map.put("name", "刘德华");
		map.put("sex", "男");
		
		//1.重写error页面，处理异常
		//a./src/main/resources/templates/error.html 名字必须是error
		System.out.println(5/0);
		
		return map;
	}
}
