package test.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

@Configuration
public class GlobalException implements HandlerExceptionResolver {
	/**
	 * 通过实现HandlerExceptionResolver接口来处理异常
	 */
	@Override
	public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {
		ModelAndView mv = new ModelAndView();
		//不同异常类型做不同试图跳转
		if (ex instanceof ArithmeticException) {
			mv.setViewName("error1");
		}
		if (ex instanceof NullPointerException) {
			mv.setViewName("error2");
		}
		mv.addObject("error", ex.toString());
		return mv;
	}
}
