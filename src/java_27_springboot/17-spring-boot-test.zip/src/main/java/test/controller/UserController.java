package test.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import test.pojo.User;
import test.service.UserService;

@Controller
public class UserController {
	@Resource
	private UserService userServiceImpl;
	
	@RequestMapping("/get/users")
	@ResponseBody
	public List<User> getUsers() {
		return userServiceImpl.selAll();
	}
}
