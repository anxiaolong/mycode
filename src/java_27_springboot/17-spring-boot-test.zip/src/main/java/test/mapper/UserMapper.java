package test.mapper;

import java.util.List;

import test.pojo.User;

public interface UserMapper {
	
	List<User> selAll();
}
