package test.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import test.mapper.UserMapper;
import test.pojo.User;
import test.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Resource
	private UserMapper userMapper;

	@Override
	public List<User> selAll() {
		return userMapper.selAll();
	}

}
