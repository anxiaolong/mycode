package test;

import java.util.List;

import javax.annotation.Resource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import test.pojo.User;
import test.service.UserService;

@SpringBootTest(classes = {App.class})
@RunWith(SpringJUnit4ClassRunner.class)
@AutoConfigureMockMvc
public class TestUserService {
	@Resource
	private UserService userServiceImpl;
	@Resource
	private WebApplicationContext webApplicationContext;
	
	private MockMvc mockMvc;
	
	/**
	 * 初始化MockMvc
	 */
	@BeforeEach //实际是使用junit5运行，初始化注解用beforeEach
	public void init() {
		System.out.println("执行了初始化");
		this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		System.out.println(this.mockMvc);
	}
	
	/**
	 * 测试service
	 */
	@Test
	public void testUserService() {
		
		List<User> list = userServiceImpl.selAll();
		System.out.println(list);
	}
	
	/**
	 * 测试controller
	 * @throws Exception
	 */
	@Test
	public void testUserController() throws Exception {
		 MvcResult mvcResult=mockMvc.perform(MockMvcRequestBuilders.get("/get/users"))
				 .andDo(MockMvcResultHandlers.print())
	                .andReturn();
		        int status=mvcResult.getResponse().getStatus();
		        String content =mvcResult.getResponse().getContentAsString();
		        System.out.println("status:"+status);
		        System.out.println("content:"+content);
	}
}
