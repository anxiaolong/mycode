package test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * 1.将springloaded.jar新建一个lib文件夹放入
 * 2.在app run配置里面加：-javaagent:.\libs\springloaded.jar -noverify
 * 3.springloader缺点是对页面文件不生效
 * @author Administrator
 *
 */
@Controller
public class TestController {
	@RequestMapping("test")
	public String test() {
		System.out.println("执行了test0000000000000");
		return "index";
	}
}
