package test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * 1.devtools是通过重新部署的方式，springloader是通过热部署方式
 * @author Administrator
 *
 */
@Controller
public class TestController {
	@RequestMapping("test")
	public String test() {
		System.out.println("执行了test,devtools的效果");
		return "index";
	}
}
