package test.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import test.pojo.User;
import test.service.UserService;
@Controller
public class UserController {
	@Resource
	private UserService userService;
	
	//1.测试Ehcache默认缓存
	@RequestMapping("test1")
	@ResponseBody 
	public List<User> test1() {
		return userService.selAllUsers();
	}
	
	//2.测试Ehcache自定义缓存
	@RequestMapping("test2")
	@ResponseBody
	public List<User> test2() {
		return userService.selUserBySex("男");
	}
	
	//3.测试@Cacheable注解，相同key情况下直接取缓存
	@RequestMapping("test3")
	@ResponseBody
	public List<User> test3() {
		return userService.selUserBySex("男");
	}
	
	//4.测试@CacheEvict,清除缓存再查询
	@RequestMapping("test4")
	@ResponseBody
	public List<User> test4() {
		return userService.selUserBySex2("男");
	}
	
}
