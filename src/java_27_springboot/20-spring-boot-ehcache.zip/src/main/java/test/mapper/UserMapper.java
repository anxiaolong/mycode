package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import test.pojo.User;

public interface UserMapper {
	
	List<User> selAllUsers();
	
	List<User> selUserBySex(@Param("sex") String sex);
}
