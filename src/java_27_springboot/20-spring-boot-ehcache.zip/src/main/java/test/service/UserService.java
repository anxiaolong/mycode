package test.service;

import java.util.List;

import test.pojo.User;

public interface UserService {
	List<User> selAllUsers();
	
	List<User> selUserBySex(String sex);
	
	List<User> selUserBySex2(String sex);
}
