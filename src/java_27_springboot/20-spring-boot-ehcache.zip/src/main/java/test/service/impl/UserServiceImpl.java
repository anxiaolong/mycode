package test.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import test.mapper.UserMapper;
import test.pojo.User;
import test.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Resource
	private UserMapper userMapper;
	
	@Override
	@Cacheable(value = "mycache") //对查询结果做缓存处理,使用默认缓存
	public List<User> selAllUsers() {
		return userMapper.selAllUsers();
	}

	@Override
	@Cacheable(value = "mycache",key = "#sex")
	//指定自定义的缓存,指定一个key值，若有key相同查询直接取缓存数据，默认也会生成一个key
	public List<User> selUserBySex(String sex) {
		return userMapper.selUserBySex(sex);
	}
	
	@Override
	@CacheEvict(value = "mycache",allEntries = true)
	//清楚缓存再查询
	public List<User> selUserBySex2(String sex) {
		return userMapper.selUserBySex(sex);
	}

}
