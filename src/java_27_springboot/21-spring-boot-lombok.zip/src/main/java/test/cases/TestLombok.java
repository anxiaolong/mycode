package test.cases;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.pojo.User;
/**
 * lombok自动生成pojo类的get和set方法
 * 1.maven依赖添加lombok坐标
 * 2.解决eclips中get和set报错
 * 	官网下载lombok.jar
 * 	eclipse安装目录eclipse.ini文件后添加
 * 	-javaagent:D:\apps\eclipse-java-2019-06-R-win32-x86_64\eclipse\lombok.jar
 * 3.pojo类上添加@Data注解
 * 
 */
@SpringBootTest(classes = App.class)
public class TestLombok {
	@Test
	@DisplayName("测试使用lombok自动生成get、set方法和toString方法")
	public void testLombok() {
		User user = new User();
		user.setId("u001");
		user.setAge(22);
		user.setName("刘德华");
		user.setSex("男");
		System.out.println(user);
	}
}
