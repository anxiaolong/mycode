package test;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import redis.clients.jedis.JedisPoolConfig;

@Configuration
public class RedisConfig {
	/**
	 * 1.配置redis连接池信息
	 */
	@Bean 
	public JedisPoolConfig getJedisPoolConfig() {
		JedisPoolConfig config = new JedisPoolConfig();
		//1.设置最大空闲数
		config.setMaxIdle(10);
		//2.设置最小空闲数
		config.setMinIdle(5);
		//3.设置最大连接数
		config.setMaxTotal(20);
		return config;
	}
	
	/**
	 * 2.配置redis集群
	 */
	@Bean
	public RedisClusterConfiguration getClusterConfiguration() {
		Set<String> set = new HashSet<String>();
		set.add("127.0.0.1:9001");
		set.add("127.0.0.1:9002");
		set.add("127.0.0.1:9003");
		set.add("127.0.0.1:9004");
		set.add("127.0.0.1:9005");
		set.add("127.0.0.1:9006");
		RedisClusterConfiguration rcc = new RedisClusterConfiguration(set);
		return rcc;
	}
	
	
	/**
	 * 3.redis连接工厂配置
	 */
	@Bean
	public JedisConnectionFactory getConnectionFactory(RedisClusterConfiguration rcc,JedisPoolConfig config) {
		JedisConnectionFactory factory = new JedisConnectionFactory(rcc,config);
		return factory;
	}
	
	/**
	 * 4.设置RedisTemplate执行redis操作
	 */
	@Bean
	public RedisTemplate<String, Object> getTemplate(JedisConnectionFactory factory) {
		RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
		//关联redis连接工厂
		template.setConnectionFactory(factory);
		//key设置序列化器
		template.setKeySerializer(new StringRedisSerializer());
		//value设置序列化器
		template.setValueSerializer(new StringRedisSerializer());
		return template;
	}
	
}
