package test.cases;

import java.util.List;
import javax.annotation.Resource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import test.App;
import test.mapper.UserMapper;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestSpringDataRedis {
	@Resource
	private UserMapper userMapper;
	
	//1.此处只能使用Autowre注入配置的序列化器才生效，@Resource注入默认使用jdk序列化器
	//2.默认序列化器key值存入redis后无法正常显示，不能正常通过key值获取value
	@Autowired 
	private RedisTemplate<String, Object> redisTemplate;
	
	@Test
	@Disabled
	@DisplayName("测试将对象按照json格式传入")
	public void test01() {
		List<User> list = userMapper.selAllUsers();
		redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(User.class));
		redisTemplate.opsForValue().set("users", list);
	}
	
	@Test
	@Disabled
	@DisplayName("测试默认配置的序列化器存数据")
	public void test02() {
		//默认key和value都设置为string
		redisTemplate.opsForValue().set("string", "testString");
		System.out.println(redisTemplate.opsForValue().get("string"));
	}
	
	
}
