package test.scheduled;

import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TestScheduled {
	/**
	 * @Scheduled 注解设置corn表达式控制定时任务
	 * 
	 * corn表达式有6或7个参数
	 * 1.秒 分 时 天 月 周 
	 * 2.秒 分 时 天 月 周 年
	 */
	@Scheduled(cron = "0/2 * * * * ?")
	public void scheduledMethod() {
		System.out.println("定时任务被触发"+new Date());
	}
}
