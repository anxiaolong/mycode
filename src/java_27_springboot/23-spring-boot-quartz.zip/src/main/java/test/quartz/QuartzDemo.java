package test.quartz;

import java.util.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class QuartzDemo implements Job {
	/**
	 * 任务被触发时所执行的方法
	 */
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		System.out.println("任务被执行--"+new Date());
	}
	
}
