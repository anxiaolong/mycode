package test;
/**
 * spring-boot整合quartz框架
 * 1.直接使用spring-boot-starter-quartz引入所有jar包依赖
 * 2.配置注入Job Trigger Scheduler
 */
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import test.quartz.QuartzDemo;

@Configuration
public class QuzrtzConfig {
	/**
	 * 1.创建job对象
	 * @return
	 */
	@Bean
	public JobDetailFactoryBean getJobDetailFactoryBean() {
		JobDetailFactoryBean factoryBean = new JobDetailFactoryBean();
		//1.关联上自己设置的job类
		factoryBean.setJobClass(QuartzDemo.class);
		
		return factoryBean;
	}
	
	/**
	 * 2.创建Trigger对象
	 */
	@Bean
	public CronTriggerFactoryBean geTriggerFactoryBean(JobDetailFactoryBean jobDetailFactoryBean) {
		CronTriggerFactoryBean factoryBean = new CronTriggerFactoryBean();
		factoryBean.setJobDetail(jobDetailFactoryBean.getObject());
		factoryBean.setCronExpression("0/2 * * * * ?");
		
		return factoryBean;
	}
	
	
	/**
	 * 3.创建Scheduler对象
	 */
	@Bean
	public SchedulerFactoryBean getSchedulerFactoryBean(CronTriggerFactoryBean cronTriggerFactoryBean) {
		SchedulerFactoryBean factoryBean = new SchedulerFactoryBean();
		factoryBean.setTriggers(cronTriggerFactoryBean.getObject());
		
		return factoryBean;
	}
}
