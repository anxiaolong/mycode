package test.cases;
import org.junit.jupiter.api.Disabled;
/**
 * spring data jpa环境搭建
 * 1.maven依赖引入
 * 2.application-properties文件配置
	spring.jpa.hibernate.ddl-auto=update
	spring.jpa.show-sql=true
   3.pojo类加映射表注解
   4.UserRepository继承JpaRepository接口
   5.注入UserRepository接口操作数据
 */
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.dao.UserRepository;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	
	@Test
	@Disabled
	@DisplayName("测试jpa插入数据")
	public void testSave() {
		User user = new User();
		user.setAge(22);
		user.setName("刘德华");
		user.setSex("男");
		this.userRepository.saveAndFlush(user);
	}
}
