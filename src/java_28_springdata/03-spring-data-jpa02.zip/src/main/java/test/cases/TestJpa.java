package test.cases;
/**
 * 测试Repository接口
 * 1.方法必须遵循驼峰命名
 * 2.findBy+属性名+查询条件
 */
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.dao.UserRepository;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	
	@Test
	@DisplayName("测试findByName方法")
	public void testFindByName() {
		List<User> findByName = userRepository.findByName("刘德华");
		for (User user : findByName) {
			System.out.println(user);
		}
	}
	
	@Test
	@DisplayName("测试findByNameLike方法")
	public void testFindByNameLike() {
		List<User> findByName = userRepository.findByNameLike("张%");
		for (User user : findByName) {
			System.out.println(user);
		}
	}
	
	@Test
	@DisplayName("测试findByNameAndAge方法")
	public void testFindByNameAndAge() {
		List<User> findByName = userRepository.findByNameAndAge("张德江", 35);
		for (User user : findByName) {
			System.out.println(user);
		}
	}
}
