package test.dao;

import java.util.List;

import org.springframework.data.repository.Repository;

import test.pojo.User;

public interface UserRepository extends Repository<User, Integer> {
	/**
	 * 1.方法必须遵循驼峰命名
	 * 2.findBy+属性名+查询条件
	 */
	
	List<User> findByName(String name);
	
	List<User> findByNameLike(String name);
	
	List<User> findByNameAndAge(String name,int age);
}
