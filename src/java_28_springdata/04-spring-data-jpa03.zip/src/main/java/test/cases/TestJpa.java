package test.cases;
/**
 * 测试@Query注解
 * 1.使用Hql查询数据
 * 2.使用sql查询数据
 * 3.@Query@Modifying实现更新数据
 */
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import test.App;
import test.dao.UserRepository;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	
	@Test
	@DisplayName("测试使用HQL查询数据")
	public void testSelUserByNameByHql() {
		List<User> selUserByName = userRepository.selUserByNameByHql("刘德华");
		for (User user : selUserByName) {
			System.out.println(user);
		}
	}
	
	@Test
	@DisplayName("测试使用sql查询数据")
	public void testSelUserByNameBySql() {
		List<User> selUserByName = userRepository.selUserByNameBySql("王金玉");
		for (User user : selUserByName) {
			System.out.println(user);
		}
	}
	
	@Test
	@Transactional
	@Rollback(false) //@Test @Transactional同时使用事务自动回滚，需要设置为不自动回滚
	@DisplayName("测试修改数据")
	public void testUpdNameById() {
		userRepository.updNameById("刘尔朱", 1);
	}
	
	

}
