package test.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import test.pojo.User;

public interface UserRepository extends Repository<User, Integer> {
	/**
	 * query注解
	 */
	
	@Query("from User where name = ?1")
	List<User> selUserByNameByHql(String name);
	
	@Query(value = "select * from jpa01_user where name = ?1",nativeQuery = true)
	List<User> selUserByNameBySql(String name);
	
	@Query("update User set name = ?1 where id = ?2")
	@Modifying
	void updNameById(String name,int id);
}
