package test.cases;
/**
 * 测试CrudRepository接口常用方法
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.dao.UserRepository;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	
	
	@Test
	@DisplayName("测试CrudRepository save方法")
	public void testCrudRepositorySave() {
		User user = new User();
		user.setAge(21);
		user.setName("玉娇");
		user.setSex("女");
		userRepository.save(user);
	}
	
	@Test
	@DisplayName("测试CrudRepository findById方法")
	public void testFindById() {
		Optional<User> findById = userRepository.findById(7);
		User user = findById.get();
		System.out.println(user);
	}
	
	@Test
	@DisplayName("测试CrudRepository 通过save更新数据")
	public void testUpdate() {
		Optional<User> findById = userRepository.findById(7);
		User user = findById.get();
		System.out.println(user);
		user.setName("江与骄");
		userRepository.save(user);
	}
	
	@Test
	@DisplayName("测试CrudRepository 通过findAll")
	public void testFindAll() {
		Iterable<User> findAll = userRepository.findAll();
		for (User user : findAll) {
			System.out.println(user);
		}
	}
	
	@Test
	@DisplayName("测试CrudRepository 通过findAllById")
	public void testFindAllById() {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(3);
		list.add(7);
		Iterable<User> findAllById = userRepository.findAllById(list);
		for (User user : findAllById) {
			System.out.println(user);
		}
	}
	
	@Test
	@DisplayName("测试CrudRepository 通过deleteById")
	public void testDeleteById() {
		userRepository.deleteById(2);
	}
}
