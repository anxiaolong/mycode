package test.dao;

import org.springframework.data.repository.CrudRepository;
import test.pojo.User;

public interface UserRepository extends CrudRepository<User, Integer> {
	
}
