package test.cases;

/**
 * 测试PagingAndSortingRepository接口常用方法
 */
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import test.App;
import test.dao.UserRepository;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	
	
	@Test
	@DisplayName("测试PagingAndSortingRepository findAll方法排序")
	public void testPagingAndSortingRepository01() {
		Iterable<User> findAll = userRepository.findAll(Sort.by("id").descending());
		for (User user : findAll) {
			System.out.println(user);
		}
	}
	
	@Test
	@DisplayName("测试PagingAndSortingRepository findAll方法分页")
	public void testPagingAndSortingRepository02() {
		Pageable pageable = PageRequest.of(0, 2);//of加排序参数，排序之后再分页
		Page<User> findAll = userRepository.findAll(pageable);
		for (User user : findAll) {
			System.out.println(user);
		}
		
		System.out.println("---------------------------------");
		
		Pageable pageable1 = PageRequest.of(0, 2,Sort.by("id").descending());//of加排序参数，排序之后再分页
		Page<User> findAll1 = userRepository.findAll(pageable1);
		for (User user : findAll1) {
			System.out.println(user);
		}
	}
	
}
