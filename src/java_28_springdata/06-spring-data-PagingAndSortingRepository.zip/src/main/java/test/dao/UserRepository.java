package test.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import test.pojo.User;

public interface UserRepository extends PagingAndSortingRepository<User, Integer> {
	
}
