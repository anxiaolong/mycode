package test.cases;

/**
 * 测试JpaRepository
 * 继承了PagingAndSortingRepository接口
 * 在次基础上实现了jpa相关方法
 */
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.dao.UserRepository;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	
	
	@Test
	@DisplayName("测试JpaRepository saveAndFlush方法")
	public void testJpaRepository() {
		User user = new User();
		user.setAge(23);
		user.setName("开一枪");
		user.setSex("男");
		userRepository.saveAndFlush(user);
	}
}
