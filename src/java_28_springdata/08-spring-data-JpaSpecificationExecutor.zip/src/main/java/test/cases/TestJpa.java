package test.cases;
/**
 * 测试JpaSpecificationExecutor条件查询相关方法
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import test.App;
import test.dao.UserRepository;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	
	
	@Test
	@DisplayName("测试JpaSpecificationExecutor 单条件查询")
	public void testJpaSpecificationExecutor() { 
		Specification<User> spec = new Specification<User>() {
			
			private static final long serialVersionUID = 1L;

			@Override
			public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Predicate pre = criteriaBuilder.equal(root.get("name"), "刘德华");
				return pre;
			}
		};
		Optional<User> findOne = userRepository.findOne(spec);
		System.out.println(findOne.get());
	}
	
	@Test
	@DisplayName("测试JpaSpecificationExecutor 多条件查询")
	public void testJpaSpecificationExecutor2() { 
		Specification<User> spec = new Specification<User>() {
			
			private static final long serialVersionUID = 1L;
			
			@Override
			public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				Predicate pre = criteriaBuilder.equal(root.get("sex"), "男");
				Predicate pre2 = criteriaBuilder.like(root.get("name"), "刘%");
				List<Predicate> list = new ArrayList<Predicate>();
				list.add(pre);
				list.add(pre2);
				Predicate[] arr = new Predicate[list.size()];
				return criteriaBuilder.and(list.toArray(arr));
			}
		};
		List<User> findAll = userRepository.findAll(spec);
		for (User user : findAll) {
			System.out.println(user);
		}
	}
	
	@Test
	@DisplayName("测试JpaSpecificationExecutor 多条件查询2")
	public void testJpaSpecificationExecutor3() { 
		Specification<User> spec = new Specification<User>() {
			
			private static final long serialVersionUID = 1L;
			
			@Override
			public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				return criteriaBuilder.and(
						criteriaBuilder.equal(root.get("sex"), "男"),
						criteriaBuilder.like(root.get("name"), "%刘%"));
			}
		};
		List<User> findAll = userRepository.findAll(spec, Sort.by(Sort.Direction.DESC,"id"));
		for (User user : findAll) {
			System.out.println(user);
		}
	}
}
