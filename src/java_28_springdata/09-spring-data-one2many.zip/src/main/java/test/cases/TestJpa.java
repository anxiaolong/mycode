package test.cases;
/**
 * 测试双向一对多
 */
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.dao.RoleRepository;
import test.dao.UserRepository;
import test.pojo.Role;
import test.pojo.User;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	
	
	@Test
	@Disabled
	@DisplayName("初始化数据")
	public void test01() { 
		Role role1 = new Role();
		Role role2 = new Role();
		role1.setRoleName("系统管理员");
		role2.setRoleName("一般用户");
		roleRepository.save(role1);
		roleRepository.save(role2);
		
		User user1 = new User();
		User user2 = new User();
		User user3 = new User();
		user1.setName("刘德华");
		user1.setRole(role1);
		user1.setSex("男");
		user1.setAge(23);
		
		user2.setName("李建华");
		user2.setRole(role2);
		user2.setSex("女");
		user2.setAge(33);
		
		user3.setName("黎汉记");
		user3.setRole(role2);
		user3.setSex("男");
		user3.setAge(32);
		
		List<User> list = new ArrayList<User>();
		list.add(user1);
		list.add(user2);
		list.add(user3);
		userRepository.saveAll(list);
	}
	
	@Test
	public void test02() {
		List<User> findAll = userRepository.findAll();
		//1.默认懒加载，触发toString方法会死循环
		//2.no session是因为懒加载时候session已经关闭
		for (User user : findAll) {
			System.out.println(user.getName()+
					"-"+user.getAge()+
					"-"+user.getSex()+
					"-"+user.getRole().getRoleName());
		}
	}
}
