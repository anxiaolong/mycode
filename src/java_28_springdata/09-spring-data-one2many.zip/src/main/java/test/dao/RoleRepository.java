package test.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import test.pojo.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {
	
}
