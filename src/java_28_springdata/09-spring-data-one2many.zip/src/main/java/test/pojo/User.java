package test.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "jpa01_user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //如果是自定义主键不要这行
	@Column
	private int id;
	
	@Column
	private String name;
	
	@Column
	private int age;
	
	@Column
	private String sex;
	
	@ManyToOne
	@JoinColumn(name = "role_id") //role_id这一列会被设置为外键
	private Role role;

}
