package test.cases;
/**
 * 测试多对多
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.dao.MenuRepository;
import test.dao.RoleRepository;
import test.pojo.Menu;
import test.pojo.Role;

@SpringBootTest(classes = App.class)
public class TestJpa {
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private MenuRepository menuRepository;
	
	@Test
	@Disabled
	@DisplayName("初始化数据")
	public void test() { 
		Role role1 = new Role();
		Role role2 = new Role();
		role1.setRoleName("系统管理员");
		role2.setRoleName("一般用户");
		
		Menu menu1 = new Menu();
		Menu menu2 = new Menu();
		Menu menu3 = new Menu();
		Menu menu4 = new Menu();
		menu1.setMenuName("系统管理");
		menu2.setMenuName("一般业务");
		menu3.setMenuName("用户管理");
		menu4.setMenuName("权限控制");
		Set<Menu> set1 = new HashSet<Menu>();
		set1.add(menu1);
		set1.add(menu2);
		set1.add(menu3);
		set1.add(menu4);
		Set<Menu> set2 = new HashSet<Menu>();
		set2.add(menu3);
		set2.add(menu2);
		
		role1.setMenus(set1);
		role2.setMenus(set2);
		List<Role> list = new ArrayList<Role>();
		list.add(role1);
		list.add(role2);
		roleRepository.saveAll(list);
	}
	
	@Test
	public void test1() {
		List<Menu> findAll = menuRepository.findAll();
		for (Menu menu : findAll) {
			System.out.println(menu.getMenuName());
		}
	}
}
