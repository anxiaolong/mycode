package test04.dependsOnMethods;

import org.testng.annotations.Test;

public class Test05_dependsOnMethods {
	@Test
	public void test01() {
		System.out.println("ִ��test01");
		throw new RuntimeException("test01�쳣��");
	}
	
	@Test(dependsOnMethods = {"test01"})
	public void test02() {
		System.out.println("ִ��test02");
	}
	
	@Test
	public void test03() {
		System.out.println("ִ��test03");
	}
}
