package test05.dependsOnGroups;

import org.testng.annotations.Test;

public class TestApp {
	@Test(dependsOnGroups = {"server","db"})
	public void testLogin() {
		System.out.println("�û���¼");
		//throw new RuntimeException("�û���¼ʧ��");
	}
	
	@Test(dependsOnGroups = {"server","db"},dependsOnMethods = {"testLogin"})
	public void testOrder() {
		System.out.println("�û��µ�");
	}
}
