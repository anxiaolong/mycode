package test07.parameter.dataProvider;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestDataProvider02Map {
	/**
	 * ʹ��map��ʽע��
	 */
	@Test(dataProvider = "data")
	public void test01(Map<Integer, Integer> map) {
		Set<Integer> keySet = map.keySet();
		for (Integer integer : keySet) {
			System.out.println(integer+"--"+map.get(integer));
		}
	}
	
	/**
	 * @DataProvider ��Ӧmap���ݲ���
	 */
	@DataProvider(name = "data")
	public Object[][] getData() {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.put(10,20);
		map.put(100,110);
		map.put(200,210);
		return new Object[][] {{map}};
	}
}
