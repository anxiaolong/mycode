package test07.parameter.dataProvider;
/**
 * ���ݷ������Ʋ�ͬע�벻ͬ����
 */
import java.lang.reflect.Method;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestDataProvider03Method {
	@Test(dataProvider = "data")
	public void test01(int num) {
		System.out.println(num);
	}
	
	@Test(dataProvider = "data")
	public void test02(int num) {
		System.out.println(num);
	}
	
	/**
	 * ���ݷ������Ʋ�ͬע�벻ͬ����
	 */
	@DataProvider(name = "data")
	public Object[] getData(Method method) {
		Object[] data = new Object[3];
		if (method.getName().equals("test01")) {
			data[0] = 1;
			data[1] = 2;
			data[2] = 3;
		}else if (method.getName().equals("test02")) {
			data[0] = 7;
			data[1] = 8;
			data[2] = 9;
		}
		return data;
	}
}
