package test07.parameter.dataProvider;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestDataProvider04ITestContext {
	@Test(dataProvider = "data",groups = {"group1"})
	public void test01(int num) {
		System.out.println(num);
	}
	
	@Test(dataProvider = "data",groups = {"group2"})
	public void test02(int num) {
		System.out.println(num);
	}
	
	/**
	 * ���ݷ������Ʋ�ͬע�벻ͬ����
	 */
	@DataProvider(name = "data")
	public Object[] getData(ITestContext context) {
		Object[] data = new Object[3];
		System.out.println("��ǰTestContext���ƣ�"+context.getName());
		
		String[] includedGroups = context.getIncludedGroups();
		
		for (String string : includedGroups) {
			System.out.println("��ǰ����case��Ϊ��"+string);
			if (string.equals("group1")) {
				data[0] = 1;
				data[1] = 2;
				data[2] = 3;
			}else if (string.equals("group2")) {
				data[0] = 7;
				data[1] = 8;
				data[2] = 9;
			}
		}
		return data;
	}
}
