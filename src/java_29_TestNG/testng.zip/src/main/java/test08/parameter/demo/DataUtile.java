package test08.parameter.demo;
/**
 * ���⹤����
 * @author Administrator
 *
 */
public class DataUtile {
	
	public static int add(int a,int b) {
		return a+b;
	}
	
	public static int sub(int a,int b) {
		return a-b;
	}
	
}
