package test08.parameter.demo;
/**
 * �׺в��԰���
 */
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestDataUtile {
	
	@DataProvider(name = "data")
	public Object[][] getData() {
		return new Object[][] {{1,3},{5,7},{9,2}};
	}
	
	@Test(dataProvider = "data")
	public void test01(int a,int b) {
		Assert.assertEquals(DataUtile.add(a, b), a+b);
	}
	@Test(dataProvider = "data")
	public void test02(int a,int b) {
		Assert.assertEquals(DataUtile.sub(a, b), a-b);
	}
}
