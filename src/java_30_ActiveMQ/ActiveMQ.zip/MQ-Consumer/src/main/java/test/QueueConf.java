package test;

import javax.jms.Queue;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QueueConf {
	@Bean
	public Queue getQueue() {
		return new ActiveMQQueue("MQ-Consumer");
	}
}
