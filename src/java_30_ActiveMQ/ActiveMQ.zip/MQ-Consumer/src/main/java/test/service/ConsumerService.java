package test.service;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;

@Component
public class ConsumerService {
	
	//1.设置监听的消息队列
	@JmsListener(destination = "MQ-Provider")
	//2.方法处理消息后返回值，写入MQ-Consumer队列
	@SendTo("MQ-Consumer")
	public String handleMessage(String name) {
		System.out.println("接受到消息："+name);
		return "接受到消息："+name;
	}
}
