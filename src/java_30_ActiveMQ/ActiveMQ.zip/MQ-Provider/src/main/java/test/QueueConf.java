package test;

import javax.jms.Queue;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QueueConf {
	@Bean
	public Queue getQueue() {
		//1.设置消息队列的名字
		return new ActiveMQQueue("MQ-Provider");
	}
}
