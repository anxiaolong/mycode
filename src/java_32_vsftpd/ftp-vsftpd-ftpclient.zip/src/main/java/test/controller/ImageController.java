package test.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import test.pojo.Image;
import test.service.ImageService;

@Controller
public class ImageController {
	@Resource
	private ImageService imageService;
	
	/**
	 * 上传图片到ftp服务器接口
	 * @param imageFile
	 * @param imageName
	 * @return
	 */
	@RequestMapping("/upload")
	public String uploadImage(MultipartFile imageFile,String imageName) {
		//System.out.println(imageFile+"-->"+imageName);
		if (imageFile!=null&&imageName!=null&&!imageName.equals("")) {
			int storeImage = imageService.storeImage(imageFile, imageName);
			if (storeImage==1) {
				return "success.jsp";
			}else {
				return "error.jsp";
			}
		}
		return "success.jsp";
	}
	
	/**
	 * 查看nginx反向代理ftp资源的接口
	 * @param model
	 * @return
	 */
	@RequestMapping("/show")
	public String show(Model model) {
		List<Image> allImages = imageService.showImage();
		
		model.addAttribute("imageList", allImages);
		
		return "show.jsp";
	}
}
