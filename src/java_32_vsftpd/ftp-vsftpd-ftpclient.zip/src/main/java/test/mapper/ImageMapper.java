package test.mapper;

import java.util.List;

import test.pojo.Image;

public interface ImageMapper {
	
	List<Image> selAllImage();
	
	int insertImage(Image image);
}
