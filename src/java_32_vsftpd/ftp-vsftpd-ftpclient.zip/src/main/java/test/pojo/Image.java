package test.pojo;

import lombok.Data;

@Data
public class Image {
	private int id;
	private String imageName;
	private String path;
}
