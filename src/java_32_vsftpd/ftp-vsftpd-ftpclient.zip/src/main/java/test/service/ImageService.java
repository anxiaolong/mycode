package test.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import test.pojo.Image;

public interface ImageService {
	
	int storeImage(MultipartFile imageFile,String imageName);
	
	List<Image> showImage();
}
