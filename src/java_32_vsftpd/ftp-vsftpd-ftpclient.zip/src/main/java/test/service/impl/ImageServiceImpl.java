package test.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import test.mapper.ImageMapper;
import test.pojo.Image;
import test.service.ImageService;
import test.utils.FtpUtils;

@Service
public class ImageServiceImpl implements ImageService {
	@Resource
	private ImageMapper imageMapper;
	
	@Value("${ftp.server.ip}")
	private String ip;
	
	@Value("${ftp.server.port}")
	private int port;
	
	@Value("${ftp.server.uname}")
	private String uname;
	
	@Value("${ftp.server.pwd}")
	private String pwd;
	
	@Value("${ftp.server.ftpBaseDir}")
	private String ftpBaseDir;
	
	@Value("${ftp.server.fileDirName}")
	private String fileDirName;
	
	@Override
	public int storeImage(MultipartFile imageFile, String imageName) {
		String originalFilename = imageFile.getOriginalFilename();
		int indexOf = originalFilename.indexOf(".");
		String fileType = originalFilename.substring(indexOf);
		// TODO Auto-generated method stub
		String fileName = UUID.randomUUID()+"-"+imageName+fileType;
		InputStream input;
		try {
			input = imageFile.getInputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		boolean uploadFile = FtpUtils.uploadFile(ip, port, uname, pwd, ftpBaseDir, fileDirName, fileName, input);
		if (uploadFile) {
			Image image = new Image();
			image.setImageName(fileName);
			image.setPath(fileDirName+"/"+fileName);
			int insertImage = imageMapper.insertImage(image);
			if (insertImage==1) {
				return 1;
			}else {
				return 0;
			}
		}
		return 0;
	}

	@Override
	public List<Image> showImage() {
		List<Image> allImage = imageMapper.selAllImage();
		
		return allImage;
	}

}
