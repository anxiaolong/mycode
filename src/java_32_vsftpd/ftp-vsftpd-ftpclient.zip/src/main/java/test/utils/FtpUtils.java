package test.utils;
/**
 * ftp文件上传和下载工具类
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

public class FtpUtils {
	/**
	 * 
	 * @param ip
	 * @param port
	 * @param uname
	 * @param pwd
	 * @param ftpBaseDir  ftp基础目录（写绝对路径）
	 * @param fileDirName 上传文件的目标文件夹名
	 * @param fileName 上传的文件重新命名
	 * @param input 需要上传的文件流
	 * @return
	 */
	public static boolean uploadFile(String ip,int port,String uname,
			String pwd,String ftpBaseDir,String fileDirName,String fileName,InputStream input) {
		try {
			//1.新建ftpclient对象
			FTPClient ftpClient = new FTPClient();
			//2.连接服务器
			ftpClient.connect(ip,port);
			//3.登录服务器
			ftpClient.login(uname, pwd);
			//4.设置文件类型
			ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
			//5.切换上传文件的目录
			boolean changeWorkingDirectory = ftpClient.changeWorkingDirectory(ftpBaseDir);
			System.out.println("切换到ftpBaseDir："+changeWorkingDirectory);
			FTPFile[] listFiles = ftpClient.listFiles();
			if (listFiles.length==0) {//i.ftp服务根目录下没有任何文件情况直接创建目标文件夹
				ftpClient.makeDirectory(fileDirName);
				boolean changeWorkingDirectory2 = ftpClient.changeWorkingDirectory(fileDirName);
				System.out.println("当前文件夹为空，新建文件夹并切换："+changeWorkingDirectory2);
			}else {//j.ftp服务根目录下有有文件，查看是否存在文件夹，存在切换过去，不存在新建再切换过去
				for (FTPFile ftpFile : listFiles) {
					if (ftpFile.isDirectory()&&ftpFile.getName().equals(fileDirName)) {
						ftpClient.changeWorkingDirectory(fileDirName);
						break;
					}
				}
			}
			//6.上传文件
			boolean storeFile = ftpClient.storeFile(fileName, input);
			//7.退出ftp
			ftpClient.logout();
			return storeFile;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * 
	 * @param ip
	 * @param port
	 * @param uname
	 * @param pwd
	 * @param fileDirName 文件相对路径文件夹名
	 * @param fileName 文件名
	 * @param localPath 本地路径
	 */
	public static boolean downloadFile(String ip,int port,String uname,
			String pwd,String fileDirName,String fileName,String localPath) {
		try {
			//1.新建ftpclient对象
			FTPClient ftpClient = new FTPClient();
			//2.连接服务器
			ftpClient.connect(ip,port);
			//3.登录服务器
			ftpClient.login(uname, pwd);
			//5.切换文件目录
			ftpClient.changeWorkingDirectory(fileDirName);
			FTPFile[] listFiles = ftpClient.listFiles();
			for (FTPFile ftpFile : listFiles) {
				if (ftpFile.isFile()&&ftpFile.getName().equals(fileName)) {//i.找到文件
					File localFile = new File(localPath+"/"+fileName);
					OutputStream os = new FileOutputStream(localFile);
					boolean retrieveFile = ftpClient.retrieveFile(ftpFile.getName(), os); //j.存储文件到本地
					return retrieveFile;
				}
			}
			ftpClient.logout();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}
	
	public static void main(String[] args) throws SocketException, IOException {
		//1.测试ftp文件上传
//		InputStream is = new FileInputStream("E:/test.jpg");
//		boolean uploadFile = uploadFile("127.0.0.1", 21, "uftp", "111111"
//				, "/home/uftp/","image3", "t2.jpg", is);
//		System.out.println(uploadFile);
		
		//2.测试ftp文件下载
//		boolean downloadFile = downloadFile("127.0.0.1", 21, "uftp", "111111", "image2", "t2.jpg", "E:");
//		System.out.println(downloadFile);
	}
}
