package concurrent_01;
/**
 * 注意：junit不支持多线程，case方法运行完，无论子线程有没有运行完都会结束
 * 
 * 1.多线程启动完成后，因为给对象o加了锁，所以线程会逐个进行对o的操作
 * 2.synchronized (this)和synchronized方法都是锁当前对象
 * 3.synchronized方法在执行前就把对象加了锁
 * 
 * @author Administrator
 *
 */

public class Test01_synchronized {
	private Object o = new Object();
	
	public void sync01() throws InterruptedException {
		System.out.println(Thread.currentThread().getName()+"启动");
		synchronized (o) {
			System.out.println(Thread.currentThread().getName()+"进入等待");
			Thread.sleep(2000);
			System.out.println(Thread.currentThread().getName()+"-->"+o.toString());
			System.out.println(Thread.currentThread().getName()+"运行完成");
		}
	}
	
	/**
	 * 1.多线程启动完成后，因为给对象o加了锁，所以线程会逐个进行对o的操作
	 */
	public static void testSync01() {
		Test01_synchronized t1 = new Test01_synchronized();
		
		for (int i = 0; i < 5; i++) {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					try {
						t1.sync01();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}).start();
		}
	}
	
	
	public void sync02() throws InterruptedException {
		System.out.println(Thread.currentThread().getName()+"启动");
		synchronized (this) {
			System.out.println(Thread.currentThread().getName()+"进入等待");
			Thread.sleep(2000);
			System.out.println(Thread.currentThread().getName()+"-->"+this.toString());
			System.out.println(Thread.currentThread().getName()+"运行完成");
		}
	}
	
	/**
	 * 2.synchronized (this)和synchronized方法都是锁当前对象
	 */
	public static void testSync02() {
		Test01_synchronized t1 = new Test01_synchronized();
		
		for (int i = 0; i < 5; i++) {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					try {
						t1.sync02();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}).start();
		}
	}
	
	public synchronized void sync03() throws InterruptedException {
		System.out.println(Thread.currentThread().getName()+"启动");
		System.out.println(Thread.currentThread().getName()+"进入等待");
		Thread.sleep(2000);
		System.out.println(Thread.currentThread().getName()+"-->"+this.toString());
		System.out.println(Thread.currentThread().getName()+"运行完成");
	}
	
	/**
	 * 3.synchronized方法在执行前就把对象加了锁
	 */
	public static void testSync03() {
		Test01_synchronized t1 = new Test01_synchronized();
		for (int i = 0; i < 5; i++) {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					try {
						t1.sync03();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}).start();
		}
	}
	
	
	public static void main(String[] args) {
		//testSync01();
		//testSync02();
		testSync03();
	}
	
}
