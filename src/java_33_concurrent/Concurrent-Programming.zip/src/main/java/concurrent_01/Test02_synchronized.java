package concurrent_01;
/**
 * 1.synchronized (Test02_synchronized.class)锁的是class对象
 * 2.静态方法上加synchronized也是锁class对象
 *
 */
public class Test02_synchronized {
	
	public static void test1() {
		System.out.println("类对象执行了静态方法");
	}
	
	public static void sync01() throws InterruptedException{
		System.out.println(Thread.currentThread().getName());
		//a.不加同步，多个线程会一起执行test1，加了同步会逐个执行
		synchronized (Test02_synchronized.class) {
			Thread.sleep(2000);
			Test02_synchronized.test1();
		}
	}
	
	//1.synchronized (Test02_synchronized.class)锁的是class对象
	public static void testSync01() {
		for (int i = 0; i < 5; i++) {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					try {
						Test02_synchronized.sync01();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}).start();
		}
	}
	
	public static synchronized void sync02() throws InterruptedException{
		System.out.println(Thread.currentThread().getName());
		Thread.sleep(2000);
		Test02_synchronized.test1();
	}
	
	//2.静态方法上加synchronized也是锁class对象
	public static void testSync02() {
		for (int i = 0; i < 5; i++) {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					try {
						Test02_synchronized.sync02();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}).start();
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		testSync01();
		testSync02();
	}
	
}
