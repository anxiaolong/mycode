package concurrent_01;
/**
 * synchronized加在方法上是为了保证操作的原子性
 * 
 */

public class Test03_synchronized implements Runnable {

	private int count = 0;
	
	/**
	 * 方法不加synchronized，count++操作在多线程下，count的值异常
	 */
	@Override
	public synchronized void run() {
		System.out.println(Thread.currentThread().getName()
				+"-->count="+count++);
	}
	
	public static void main(String[] args) {
		
		Test03_synchronized t = new Test03_synchronized();
		
		for (int i = 0; i < 5; i++) {
			new Thread(t).start();
		}
	}
	
}
