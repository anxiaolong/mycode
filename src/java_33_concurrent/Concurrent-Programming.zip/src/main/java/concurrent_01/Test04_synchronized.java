package concurrent_01;
/**
 * 同步方法和非同步方法的调用是不干扰的
 * 同步方法只影响锁定同一个锁对象的同步方法。不影响其他线程调用非同步方法，或调用其他锁资源的同步方法
 * @author Administrator
 *
 */
public class Test04_synchronized {
	private Object o = new Object();
	
	//1.线程同步的方法
	public synchronized void m1() throws InterruptedException {
		System.out.println("m1--start");
		Thread.sleep(2000);
		System.out.println("m1--end");
	}
	
	//2.方法中有同步块，锁的对象和m1锁的对象无关
	public void m2() throws InterruptedException {
		System.out.println("m2-start");
		synchronized (o) {
			Thread.sleep(2000);
		}
		System.out.println("m2-end");
	}
	
	//3.普通方法
	public void m3() throws InterruptedException {
		System.out.println("m3-start");
		Thread.sleep(2000);
		System.out.println("m3-end");
	}
	
	public static class MyThread implements Runnable {
		private Test04_synchronized t;
		private int i;
		
		public MyThread(Test04_synchronized t,int i) {
			this.t = t;
			this.i = i;
		}
		
		@Override
		public void run() {
			try {
				if (i==1) {
					t.m1();
				}else if (i==2) {
					t.m2();
				}else if (i==3) {
					t.m3();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		Test04_synchronized t = new Test04_synchronized();
		new Thread(new MyThread(t, 1)).start();
		new Thread(new MyThread(t, 2)).start();
		new Thread(new MyThread(t, 3)).start();
	}
	
}
