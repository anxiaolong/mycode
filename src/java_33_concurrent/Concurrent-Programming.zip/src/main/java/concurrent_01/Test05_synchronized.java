package concurrent_01;
/**
 *  同步方法只能保证当前方法的原子性，不能保证多个业务方法之间的互相访问的原子性。
 * 注意在商业开发中，多方法要求结果访问原子操作，需要多个方法都加锁，且锁定统一个资源。
 */
import java.util.concurrent.TimeUnit;

public class Test05_synchronized {
	private double d = 0;
	
	
	public synchronized void m1(double d) {
		this.d = d;
	}
	
	public void getD() {
		System.out.println(this.d);
	}
	
	public static void main(String[] args) {
		Test05_synchronized t = new Test05_synchronized();
		//1.启动线程
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					TimeUnit.SECONDS.sleep(2);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				t.m1(3.14);
			}
		}).start();
		
		//2.打印d的值
		t.getD();
		
		//3.间隔3秒再打印d的值
		try {
			TimeUnit.SECONDS.sleep(3);
			t.getD();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
