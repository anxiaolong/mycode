package concurrent_01;
/**
 * 锁可重入。 同一个线程，多次调用同步代码，锁定同一个锁对象，可重入。
 *
 */
public class Test06_synchronized {
	
	public synchronized void m1() {
		System.out.println("m1 start");
		m2();
		System.out.println("m1 end");
	}
	
	public synchronized void m2() {
		System.out.println("m2 start");
		System.out.println("m2 end");
	}
	
	public static void main(String[] args) {
		Test06_synchronized t = new Test06_synchronized();
		t.m1();
	}
}
