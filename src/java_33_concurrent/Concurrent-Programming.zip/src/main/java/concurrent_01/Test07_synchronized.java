package concurrent_01;
/**
 * 子类调用父类的同步方法，相当于锁重入
 * 锁重入：外层函数获得锁之后 ，内层递归函数仍然有获取该锁的代码，但不受影响
 */
public class Test07_synchronized {
	public synchronized void m1() {
		System.out.println("Test07_synchronized-m1 start");
		System.out.println("Test07_synchronized-m1 end");
	}
	
	public static void main(String[] args) {
		new Test07_synchronized_01().test();
	}
}

class Test07_synchronized_01 extends Test07_synchronized{
	public void test() {
		System.out.println("Test07_synchronized_01-test start");
		super.m1();
		System.out.println("Test07_synchronized_01-test end");
	}
}
