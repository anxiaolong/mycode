package concurrent_01;
/**
 *  当同步方法中发生异常的时候，自动释放锁资源。不会影响其他线程的执行。
 * 注意，同步业务逻辑中，如果发生异常如何处理。
 */
import java.util.concurrent.TimeUnit;

public class Test08_synchronized {
	private int i = 0;
	
	@SuppressWarnings(value = { "unused" })
	public synchronized void m1() throws InterruptedException {
		System.out.println("m1-start");
		while (true) {
			i++;
			TimeUnit.SECONDS.sleep(1);
			System.out.println(Thread.currentThread().getName()+"-->"+i);
			if (i==5) {
				int m = i/0;
			}
		}
	}
	
	public static void main(String[] args) {
		Test08_synchronized t = new Test08_synchronized();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					t.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					t.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
	}
}
