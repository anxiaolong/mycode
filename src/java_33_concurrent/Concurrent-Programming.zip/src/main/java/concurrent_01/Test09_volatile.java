package concurrent_01;
/**
 * volatile修饰的变量，每次使用都会获取最新的值，保证最新的内存数据被使用
 */
import java.util.concurrent.TimeUnit;

public class Test09_volatile {
	volatile boolean flag = true;
	
	public void m1() {
		System.out.println("m1-start");
		while (flag) {}
		System.out.println("m1-end");
	}
	
	public static void main(String[] args) throws InterruptedException {
		Test09_volatile t = new Test09_volatile();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				t.m1();
			}
		}).start();
		
		TimeUnit.SECONDS.sleep(2);
		
		t.flag = false;
	}
}
