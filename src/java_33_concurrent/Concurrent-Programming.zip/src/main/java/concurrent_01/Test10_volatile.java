package concurrent_01;
/**
 * volatile修饰的变量只能保证可见性，不能保证原子性
 */
import java.util.ArrayList;
import java.util.List;

public class Test10_volatile {
	volatile int count = 0;
	
	public void test01() {
		for (int i = 0; i < 10000; i++) {
			count++;
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		Test10_volatile t = new Test10_volatile();
		//1.创建一个线程池
		List<Thread> list = new ArrayList<Thread>();
		for (int i = 0; i < 10; i++) {
			list.add(new Thread(new Runnable() {
				
				@Override
				public void run() {
					t.test01();
				}
			}));
		}
		//2.启动线程
		for (Thread thread : list) {
			thread.start();
		}
		//3.等待所有线程执行完毕
		for (Thread thread : list) {
			thread.join();
		}
		System.out.println(t.count);
	}
}
