package concurrent_01;
/**
 * AtomicXXXX对象是原子操作，多线程下安全
 */
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Test11_atomic {
	AtomicInteger count = new AtomicInteger(0);
	
	public void m1() {
		for (int i = 0; i < 10000; i++) {
			count.incrementAndGet();
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		Test11_atomic t = new Test11_atomic();
		//1.创建线程池
		List<Thread> list = new ArrayList<Thread>();
		for (int i = 0; i < 10; i++) {
			list.add(new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					t.m1();
				}
			}));
		}
		//2.启动线程
		for (Thread thread : list) {
			thread.start();
		}
		//3.等待线程执行结束
		for (Thread thread : list) {
			thread.join();
		}
		
		System.out.println(t.count);
	}
}
