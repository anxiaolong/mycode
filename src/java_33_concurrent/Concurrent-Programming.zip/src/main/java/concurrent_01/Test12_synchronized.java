package concurrent_01;
/**
 * 尽量在商业开发中避免同步方法。使用同步代码块。 细粒度解决同步问题。
 *提高代码效率
 */
public class Test12_synchronized {
	
	Object o = new Object();
	
	public synchronized void m1() {
		//1.前置逻辑
		System.out.println("执行前置逻辑代码。。。");
		System.out.println(o);
		//2.后置逻辑
		System.out.println("执行后置逻辑代码。。。");
	}
	
	public void m2() {
		//1.前置逻辑
		System.out.println("执行前置逻辑代码。。。");
		synchronized (o) {
			System.out.println(o);
		}
		//2.后置逻辑
		System.out.println("执行后置逻辑代码。。。");
	}
}
