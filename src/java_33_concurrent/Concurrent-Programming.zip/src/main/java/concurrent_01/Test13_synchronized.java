package concurrent_01;
/**
 *  锁对象变更问题
 * 同步代码一旦加锁后，那么会有一个临时的锁引用执行锁对象，和真实的引用无直接关联。
 * 在锁未释放之前，修改锁对象引用，不会影响同步代码的执行。
 */
import java.util.concurrent.TimeUnit;

public class Test13_synchronized {
	Object o = new Object();
	
	public void m1() throws InterruptedException {
		synchronized (o) {
			while (true) {
				TimeUnit.SECONDS.sleep(1);
				System.out.println(Thread.currentThread().getName()+"--"+o);
			}
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		Test13_synchronized t = new Test13_synchronized();
		//1.启动一个多线程使用o对象
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					t.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
		
		//2.暂时一会看第一个线程的打印
		TimeUnit.SECONDS.sleep(5);
		
		//3.创建第二个线程
		Thread thread1 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					t.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		//4.修改o对象，不对o做修改操作，线程2一直处于等待
		t.o = new Object();
		
		//5.启动第二个线程
		thread1.start();
	}
}
