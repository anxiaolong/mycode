package concurrent_01;
/**
 * 不要给常量对象加锁，两个相同的常量默认指向一个对象，会死锁
 *
 */
public class Test14_synchronized {
	Integer a1 = 11;
	Integer a2 = 11;
	
	public void m1() {
		synchronized (a1) {
			System.out.println("m1-start");
			while (true) {}
		}
	}
	
	public void m2() {
		synchronized (a2) {
			System.out.println("m2-start");
			while (true) {}
		}
	}
	
	public static void main(String[] args) {
		Test14_synchronized t = new Test14_synchronized();
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				t.m1();
			}
		}).start();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				t.m2();
			}
		}).start();
	}
}
