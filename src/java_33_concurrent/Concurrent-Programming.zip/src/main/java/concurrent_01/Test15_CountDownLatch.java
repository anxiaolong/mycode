package concurrent_01;
/**
 *  门闩 - CountDownLatch
 * 可以和锁混合使用，或替代锁的功能。
 * 在门闩未完全开放之前等待。当门闩完全开放后执行。
 * 避免锁的效率低下问题
 */
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class Test15_CountDownLatch {
	
	CountDownLatch latch = new CountDownLatch(5);
	
	public void m1() throws InterruptedException {
		latch.await();//等待门闩开放
		System.out.println("m1()");//门闩count=0时候，才会执行该行
	}
	
	public void m2() throws InterruptedException {
		for (int i = 0; i < 10; i++) {
			if (latch.getCount()!=0) {
				System.out.println("latch count:"+latch.getCount());
				latch.countDown();//减少一个门闩上的锁
			}
			TimeUnit.SECONDS.sleep(1);
			System.out.println("m2()--"+i);
		}
	}
	
	public static void main(String[] args) {
		Test15_CountDownLatch t = new Test15_CountDownLatch();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					t.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					t.m2();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
	}
}
