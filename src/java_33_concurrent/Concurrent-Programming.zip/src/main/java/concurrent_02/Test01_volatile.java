package concurrent_02;
/**
 * 自定义容器，并监控容器的size，volatile实现
 * volatile修饰的变量具有可见性，每次使用都获取最新的值
 */
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Test01_volatile {
	
	public static void main(String[] args) {
		Container c1 = new Container();
		//1.启动一个线程监控容器的size
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (true) {
					if (c1.size()==5) {
						System.out.println("c1 size="+c1.size());
						break;
					}
				}
			}
		}).start();
		
		//2.启动第二个线程，每2秒往容器中添加一个对象
		new Thread(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < 10; i++) {
					try {
						TimeUnit.SECONDS.sleep(2);
						c1.add(new Object());
						System.out.println("c1容量"+c1.size());
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}).start();
	}
}

class Container{
	private volatile List<Object> container = new ArrayList<Object>();
	
	/**
	 * 添加对象o到容器中
	 * @param o
	 */
	public void add(Object o) {
		this.container.add(o);
	}
	
	/**
	 * 获取容器长度
	 * @return
	 */
	public int size() {
		return container.size();
	}
}
