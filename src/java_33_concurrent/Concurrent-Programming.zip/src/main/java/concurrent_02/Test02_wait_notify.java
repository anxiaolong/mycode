package concurrent_02;
/**
 * 自定义容器，并监控容器的size，wait和notify实现
 * volatile修饰的变量具有可见性，每次使用都获取最新的值
 */
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Test02_wait_notify {
	public static void main(String[] args) {
		Container02 c1 = new Container02();
		Object o = new Object();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				synchronized (o) {
					if (c1.size()!=5) {
						try {
							o.wait();//进入等待
							
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					System.out.println("c1.size()="+c1.size());
					o.notifyAll();//唤起其他线程
				}
			}
		}).start();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				synchronized (o) {
					for (int i = 0; i < 10; i++) {
						c1.add(new Object());
						try {
							TimeUnit.SECONDS.sleep(1);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println("c1-add--"+i);
						if (c1.size()==5) {
							try {
								o.notifyAll();//唤醒其他线程
								o.wait();
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				}
			}
		}).start();
	}
}

class Container02{
	private volatile List<Object> container = new ArrayList<Object>();
	
	/**
	 * 添加对象o到容器中
	 * @param o
	 */
	public void add(Object o) {
		this.container.add(o);
	}
	
	/**
	 * 获取容器长度
	 * @return
	 */
	public int size() {
		return container.size();
	}
}
