package concurrent_02;
/**
 * 自定义容器，并监控容器的size，CountDownLatch实现
 */
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class Test03_CountDownLatch {
	
	public static void main(String[] args) {
		Container03 c1 = new Container03();
		CountDownLatch latch = new CountDownLatch(1);
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				if (c1.size()!=5) {
					try {
						latch.await();//等待门闩开启
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println("c1.size()="+c1.size());//答应不能放到else中，顺序执行过来
			}
		}).start();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < 10; i++) {
					c1.add(new Object());
					if (c1.size()==5) {
						latch.countDown();//减少一个门闩
					}
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("c1="+c1.size());
				}
			}
		}).start();
	}
}

class Container03{
	private volatile List<Object> container = new ArrayList<Object>();
	
	/**
	 * 添加对象o到容器中
	 * @param o
	 */
	public void add(Object o) {
		this.container.add(o);
	}
	
	/**
	 * 获取容器长度
	 * @return
	 */
	public int size() {
		return container.size();
	}
}
