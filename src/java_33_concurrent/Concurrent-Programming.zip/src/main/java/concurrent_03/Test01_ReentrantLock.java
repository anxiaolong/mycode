package concurrent_03;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 重入锁ReentrantLock
 */
public class Test01_ReentrantLock {
	Lock lock = new ReentrantLock();
	
	public void m1() throws InterruptedException {
		lock.lock();//加锁
		for (int i = 0; i < 10; i++) {
			TimeUnit.SECONDS.sleep(1);
			System.out.println("m1--"+i);
		}
		lock.unlock();//释放锁
	}
	
	public void m2() {
		lock.lock();
		System.out.println("m2()");
		lock.unlock();
	}
	
	public static void main(String[] args) {
		Test01_ReentrantLock t1 = new Test01_ReentrantLock();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					t1.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				t1.m2();
			}
		}).start();
	}
}
