package concurrent_03;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
/**
 * 尝试锁
 */
public class Test02_TryLock {
	Lock lock = new ReentrantLock();
	
	public void m1()  {
		lock.lock();//1.锁定当前对象
		try {
			for (int i = 0; i < 10; i++) {
				TimeUnit.SECONDS.sleep(1);//2.每隔一秒m1迭代一次
				System.out.println("m1()--"+i);
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			lock.unlock();//3.迭代完释放锁
		}
	}
	
	public void m2() {
		Boolean flag = false;
		
		try {
			flag = lock.tryLock(5, TimeUnit.SECONDS);//1.等待五秒尝试获取锁
			if (flag) {
				System.out.println("m2 get this success");
			}else {
				System.out.println("m2 get this fail");
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		Test02_TryLock t1 = new Test02_TryLock();
		new Thread(new Runnable() {
			@Override
			public void run() {
				t1.m1();
			}
		}).start();
		
		TimeUnit.SECONDS.sleep(1);
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				t1.m2();
			}
		}).start();
	}
}
