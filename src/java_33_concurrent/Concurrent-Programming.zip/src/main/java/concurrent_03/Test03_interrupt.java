package concurrent_03;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
/**
 * 可打断
 * 
 * 阻塞状态： 包括普通阻塞，等待队列，锁池队列。
 * 普通阻塞： sleep(10000)， 可以被打断。调用thread.interrupt()方法，可以打断阻塞状态，抛出异常。
 * 等待队列： wait()方法被调用，也是一种阻塞状态，只能由notify唤醒。无法打断
 * 锁池队列： 无法获取锁标记。不是所有的锁池队列都可被打断。
 *  使用ReentrantLock的lock方法，获取锁标记的时候，如果需要阻塞等待锁标记，无法被打断。
 *  使用ReentrantLock的lockInterruptibly方法，获取锁标记的时候，如果需要阻塞等待，可以被打断。
 * 
 */
public class Test03_interrupt {
	
	Lock lock = new ReentrantLock();
	
	public void m1() throws InterruptedException {
		//1.锁当前对象
		lock.lock();
		//2.每秒迭代一次
		for (int i = 0; i < 10; i++) {
			TimeUnit.SECONDS.sleep(1);
			System.out.println("m1()--"+i);
		}
		//3.释放锁
		lock.unlock();
	}
	
	public void m2() {
		//1.尝试打断线程
		try {
			System.out.println("m2尝试打断线程");
			lock.lockInterruptibly();
		} catch (InterruptedException e) {
			//2.打断成功会抛异常
			e.printStackTrace();
			System.out.println("m2 打断成功");
		}finally {
			lock.unlock();
		}
		System.out.println("m2() end");
	}
	
	public static void main(String[] args) throws InterruptedException {
		Test03_interrupt t1 = new Test03_interrupt();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					t1.m1();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
		
		TimeUnit.SECONDS.sleep(1);
		
		Thread t2 = new Thread(new Runnable() {
			@Override
			public void run() {
				t1.m2();
			}
		});
		t2.start();
		
		TimeUnit.SECONDS.sleep(3);
		
		System.out.println("m2的线程强行打断");
		t2.interrupt();
	}
}
