package concurrent_03;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
/**
 * 公平锁
 *使用到锁的线程顺序排队
 */
public class Test04 {
	public static void main(String[] args) {
		Thread t = new Test04_01();
		Thread t1 = new Thread(t);
		Thread t2 = new Thread(t);
		Thread t3 = new Thread(t);
		t1.start();
		t2.start();
		t3.start();
	}
}

class Test04_01 extends Thread {
	//1.定义一个公平锁
	Lock lock = new ReentrantLock(true);
	
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			lock.lock();
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"--run");
			lock.unlock();
		}
	}
}