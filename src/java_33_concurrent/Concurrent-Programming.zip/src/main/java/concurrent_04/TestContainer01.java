package concurrent_04;

import java.util.LinkedList;
import java.util.concurrent.TimeUnit;
/**
 * 生产者消费者模式：自定义容器保证线程安全，容量为10
 * 使用wait notify LinkedList实现
 * @author Administrator
 *
 * @param <T>
 */
public class TestContainer01<T> {
	//1.创建容器
	private final LinkedList<T> list = new LinkedList<T>();
	//2.定义容器最大容量
	private final int MAX = 10;
	//3.容量计数
	private int count = 0;
	
	/**
	 * 获取当前容器容量，方法加同步
	 * @return
	 */
	public synchronized int getCount() {
		return count;
	}
	
	/**
	 * 向容器中添加内容，
	 * 如果已经到了最大容量，则进入阻塞式等待
	 * 如果未到最大容量，则添加元素进容器，再抛出锁
	 * @param t
	 */
	public synchronized void put(T t) {
		while (list.size()==MAX) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		list.add(t);
		count++;
		this.notifyAll();
	}
	
	/**
	 * 抽取容器中数据，
	 * 如果容器为空，则进入阻塞式等待
	 * 如果不为空，removeFirst取出list第一个
	 * @return
	 */
	public synchronized T get() {
		T t = null;
		
		while (list.size()==0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		t = list.removeFirst();
		count--;
		this.notifyAll();
		return t;
	}
	
	
	public static void main(String[] args) {
		TestContainer01<String> t = new TestContainer01<String>();
		//1.开三个线程同时往容器中添加数据
		for (int i = 0; i < 3; i++) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					for (int j = 0; j < 50; j++) {
						t.put(Thread.currentThread().getName()+"--"+j);
					}
				}
			}).start();
		}
		
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//2.查看容器中存了多少数据
		new Thread(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < t.count; i++) {
					System.out.println(t.get());
				}
			}
		}).start();
	}
	
	
}
