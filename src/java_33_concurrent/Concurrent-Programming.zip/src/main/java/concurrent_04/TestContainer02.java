package concurrent_04;

import java.util.LinkedList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
/**
 *  生产者消费者模式：自定义容器保证线程安全，容量为10
 *  使用Lock Condition实现
 * @author Administrator
 *
 * @param <T>
 */
public class TestContainer02<T> {
	//1.创建list
	private final LinkedList<T> list = new LinkedList<T>();
	//2.设置容器容量
	private final int MAX = 10;
	//3.设置计数器
	private int count;
	//4.创建可重入锁对象
	private Lock lock = new ReentrantLock();
	//5.通过锁对象创建两个条件
	private Condition producer = lock.newCondition();
	private Condition consumer = lock.newCondition();
	
	/**
	 * 获取容器当前数量
	 * @return
	 */
	public synchronized int getCount() {
		return count;
	}
	
	/**
	 * 向容器中添加元素
	 * @param t
	 */
	public void put(T t) {
		lock.lock();
		
		//1.如果容量到最大，通过条件进入等待队列
		while (list.size() == MAX) {
			try {
				producer.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		list.add(t);
		count++;
		//2.添加内容到容器后，通过条件唤醒所有消费者
		consumer.signalAll();
		lock.unlock();
	}
	
	/**
	 * 从容器中抽取元素
	 * @return
	 */
	public T get() {
		T t = null;
		
		lock.lock();
		//1.容器容量为0，借助条件进入等待队列
		while (list.size()==0) {
			try {
				consumer.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		t = list.removeFirst();
		count--;
		//2.抽取元素后，唤醒所有生产者线程
		producer.signalAll();
		lock.unlock();
		return t;
	}
	
	public static void main(String[] args) {
		TestContainer02<String> t = new TestContainer02<String>();
		
		for (int i = 0; i < 3; i++) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					for (int j = 0; j < 30; j++) {
						t.put(Thread.currentThread().getName()+"--"+t);
					}
				}
			}).start();
		}
		
		try {
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < t.count; i++) {
					System.out.println(t.get());
				}
			}
		}).start();
	}
	
}





