package concurrent_05;

import java.util.concurrent.TimeUnit;

/**
 * ThreadLocal
 * 就是一个Map。key - 》 Thread.getCurrentThread().  value - 》 线程需要保存的变量。
 * ThreadLocal.set(value) -> map.put(Thread.getCurrentThread(), value);
 * ThreadLocal.get() -> map.get(Thread.getCurrentThread());
 * 内存问题 ： 在并发量高的时候，可能有内存溢出。
 * 使用ThreadLocal的时候，一定注意回收资源问题，每个线程结束之前，将当前线程保存的线程变量一定要删除 。
 * ThreadLocal.remove();
 */
public class Test01_ThreadLocal {
	//1.普通变量在多线程下使用会有问题
	static volatile String name = "liudehua";
	//2.定义线程专用的变量
	static ThreadLocal<String> threadLocal = new ThreadLocal<String>();
	
	public static void main(String[] args) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					TimeUnit.SECONDS.sleep(3);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//1.此处获取到的name已经被修改过了
				System.out.println(name);
				//2.此处获取不到另外一个线程设置的threadLocal变量
				System.out.println(threadLocal.get());
			}
		}).start();
		
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					TimeUnit.SECONDS.sleep(1);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				name="tttttt";
				threadLocal.set("ggggsdfdffd");
			}
		}).start();
	}
}
