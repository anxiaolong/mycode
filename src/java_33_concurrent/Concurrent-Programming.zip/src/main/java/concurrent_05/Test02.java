package concurrent_05;

/**
 * 内部类实现单例
 */
public class Test02 {
	
	private static class Test02_01{
		private static Test02 t = new Test02();
	}
	
	public static Test02 getInstance() {
		return Test02_01.t;
	}
	
	public static void main(String[] args) {
		
		System.out.println(getInstance().equals(getInstance()));
		
	}
}
