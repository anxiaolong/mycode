package concurrent_06;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.CountDownLatch;
/**
 * 并发容器ConcurrentHashMap ConcurrentSkipListMap
 */
public class Test01_ConcurrentMap {
	public static void main(String[] args) throws InterruptedException {
		//1.定义并发容器对象
		//final Map<String, String> map = new ConcurrentHashMap<String, String>();//执行时间为：325毫秒
		final Map<String, String> map = new ConcurrentSkipListMap<String, String>();//执行时间为：341毫秒
		
		//2.创建随机对象
		final Random random = new Random();
		//3.创建线程数组
		Thread[] array = new Thread[100];
		//4.创建门闩
		final CountDownLatch latch = new CountDownLatch(array.length);
		
		//5.多线程程序执行开始
		long begin = System.currentTimeMillis();
		
		//6.创建100个线程对象放入数组
		for (int i = 0; i < array.length; i++) {
			array[i] = new Thread(new Runnable() {
				@Override
				public void run() {
					//7.每个线程向容器钟添加10000个数据
					for (int j = 0; j < 10000; j++) {
						map.put("key"+random.nextInt(100000),
								"value"+random.nextInt(100000));
					}
					//8.每个线程执行完减少一个门闩
					latch.countDown();
				}
			});
		}
		
		//9.启动线程
		for (Thread thread : array) {
			thread.start();
		}
		
		//10.等待多线程都执行完
		latch.await();
		
		//11.记录结束时间
		long end = System.currentTimeMillis();
		
		System.out.println("执行时间为："+(end-begin)+"毫秒");
	}
}
