package concurrent_06;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * 并发容器ConcurrentLinkedDeque
 */
public class Test03_ConcurrentLinkedQueue {
	public static void main(String[] args) throws InterruptedException {
		//1.定义并发容器对象
		Queue<String> queue = new ConcurrentLinkedDeque<String>();
		
		//2.向容器中添加数据
		for (int i = 0; i < 10; i++) {
			queue.offer("value"+i);//offer和add区别，添加失败add会抛异常，offer会返回false
		}
		
		System.out.println(queue);
		
		//3.获取queue首数据
		System.out.println(queue.peek());
		System.out.println(queue.size());
		
		//4.取出queue中的首数据
		System.out.println(queue.poll());
		System.out.println(queue.size());
		System.out.println(queue);
	}
}
