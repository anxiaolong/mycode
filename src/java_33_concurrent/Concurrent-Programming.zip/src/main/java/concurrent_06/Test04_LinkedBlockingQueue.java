package concurrent_06;

import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
/**
 * 并发容器 - LinkedBlockingQueue
 *  阻塞容器。
 *  put & take - 自动阻塞。
 *  put自动阻塞， 队列容量满后，自动阻塞
 *  take自动阻塞方法， 队列容量为0后，自动阻塞。
 */
public class Test04_LinkedBlockingQueue {
	final LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<String>(3);
	final Random random = new Random();
	
	public static void main(String[] args) {
		Test04_LinkedBlockingQueue t = new Test04_LinkedBlockingQueue();
		
		//1.生产者线程
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (true) {
					try {
						TimeUnit.SECONDS.sleep(1);
						t.queue.put("value"+t.random.nextInt(10000));
						System.out.println(Thread.currentThread().getName()+"--put");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		},"producer").start();
		
		try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//2.消费者线程
		for (int i = 0; i < 3; i++) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					while (true) {
						try {
							System.out.println(Thread.currentThread().getName()
									+"--"+t.queue.take());
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			},"consumer"+i).start();
		}
	}
}
