package concurrent_06;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
/**
 * 并发容器 - ArrayBlockingQueue
 *  有界容器。
 */
public class Test05_ArrayBlockingQueue {
	final BlockingQueue<String> queue = new ArrayBlockingQueue<String>(3);
	
	public static void main(String[] args) {
		Test05_ArrayBlockingQueue t = new Test05_ArrayBlockingQueue();
		for (int i = 0; i < 5; i++) {
			try {
				System.out.println(t.queue.offer("value"+i));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println(t.queue.size());
		System.out.println(t.queue);
	}
}
