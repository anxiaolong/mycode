package concurrent_06;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
/**
 * 并发容器 - DelayQueue
 * 只有在延迟期满时才能从中提取元素
 * 无界容器。
 */
public class Test06_DelayQueue {
	static BlockingQueue<MyTask06> queue = new DelayQueue<MyTask06>();
	
	public static void main(String[] args) throws InterruptedException {
		long value = System.currentTimeMillis();
		MyTask06 task1 = new MyTask06(value+10000);
		MyTask06 task2 = new MyTask06(value+20000);
		MyTask06 task3 = new MyTask06(value+30000);
		MyTask06 task4 = new MyTask06(value+40000);
		queue.put(task1);
		queue.put(task2);
		queue.put(task3);
		queue.put(task4);
		
		System.out.println(queue);
		System.out.println(value);
		for (int i = 0; i < 4; i++) {
			long start = System.currentTimeMillis();
			System.out.println(queue.take());
			long end = System.currentTimeMillis();
			System.out.println("take耗时："+(end-start));
		}
	}
}

class MyTask06 implements Delayed{
	private long compareValue;
	
	public MyTask06(long compareValue) {
		this.compareValue = compareValue;
	}

	@Override
	public int compareTo(Delayed o) {
		return (int) (this.getDelay(TimeUnit.MILLISECONDS)-o.getDelay(TimeUnit.MILLISECONDS));
	}

	/**
	 * 获取计划时常
	 */
	@Override
	public long getDelay(TimeUnit unit) {
		return unit.convert(compareValue-System.currentTimeMillis(), TimeUnit.MILLISECONDS);
	}

	@Override
	public String toString() {
		return "Task compareValue is:"+this.compareValue;
	}
}
