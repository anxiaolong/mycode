package concurrent_06;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
/**
 * 并发容器 - SynchronousQueue
 * 没有take()方法执行，put会处于阻塞状态
 */
public class Test08_SynchronusQueue {
	static BlockingQueue<String> queue = new SynchronousQueue<String>();
	
	public static void main(String[] args) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Thread start");
				try {
					TimeUnit.SECONDS.sleep(3);
					System.out.println(queue.take());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Thread end");
			}
		}).start();
		
		try {
			//1.没有take()方法执行，put会处于阻塞状态
			queue.put("test SynchronousQueue");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(Thread.currentThread().getName()+" queue size "+queue.size());
	}
}
