package concurrent_07;

import java.util.ArrayList;
import java.util.List;
/**
 * 普通容器在多线程下数据是不安全的
 * 启动若干线程，并行访问同一个容器中的数据。保证获取容器中数据时没有数据错误，且线程安全。
 */
public class Test01 {
	static List<String> list = new ArrayList<String>();
	
	static {
		for (int i = 0; i < 10000; i++) {
			list.add("String"+i);
		}
	}
	
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					while (true) {
						if (list.size()>0) {
							System.out.println(list.remove(0));
							continue;
						}
						break;
					}
				}
			}).start();
		}
	}
}
