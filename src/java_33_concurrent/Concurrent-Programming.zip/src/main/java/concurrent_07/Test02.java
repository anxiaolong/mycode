package concurrent_07;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
/**
 * 并发容器在多线程下，数据安全
 * 启动若干线程，并行访问同一个容器中的数据。保证获取容器中数据时没有数据错误，且线程安全。
 */
public class Test02 {
	static Queue<String> list = new ConcurrentLinkedQueue<String>();
	static {
		for (int i = 0; i < 10000; i++) {
			list.add("String"+i);
		}
	}
	
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					while (true) {
						if (list.size()>0) {
							System.out.println(list.poll());
							continue;
						}
						break;
					}
				}
			}).start();
		}
	}
}
