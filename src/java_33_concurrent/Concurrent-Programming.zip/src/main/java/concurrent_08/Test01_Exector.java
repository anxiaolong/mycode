package concurrent_08;

import java.util.concurrent.Executor;
/**
 * Executor线程池顶级接口 
 * 核心方法execute(Runnable command)
 */
public class Test01_Exector implements Executor {

	@Override
	public void execute(Runnable command) {
		//1.Runnable类型的数据放到线程中启动
		new Thread(command).start();
	}
	
	public static void main(String[] args) {
		new Test01_Exector().execute(new Runnable() {
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName()+"--start");
			}
		});
	}
}
