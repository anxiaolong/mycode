package concurrent_08;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
/**
 * 固定容量线程池FixedThreadPool
 */
public class Test02_FixedThreadPool {
	public static void main(String[] args) throws InterruptedException {
		//1.创建线程池
		ExecutorService fixedThreadPool = Executors.newFixedThreadPool(3);
		
		//2.使用线程池执行runable中代码，只有设定的3个线程
		for (int i = 0; i < 10; i++) {
			fixedThreadPool.execute(new Runnable() {
				@Override
				public void run() {
					System.out.println(Thread.currentThread().getName());
				}
			});
		}
		
		//3.打印线程池对象信息
		System.out.println(fixedThreadPool);
		
		//4.线程池资源回收，必须手动回收
		
		TimeUnit.SECONDS.sleep(2);
		
		fixedThreadPool.shutdown();
		System.out.println("线程池是否回收："+fixedThreadPool.isShutdown());
	}
}
