package concurrent_08;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
/**
 * Future获取线程的返回值
 */
public class Test03_Future {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService fixedThreadPool = Executors.newFixedThreadPool(1);
		Future<String> future = fixedThreadPool.submit(new Callable<String>() {
			@Override
			public String call() throws Exception {
				return Thread.currentThread().getName()+"我是返回值";
			}
		});
		
		System.out.println(future);
		System.out.println(future.get());//获取call方法返回值
		System.out.println(future.isDone());//查看线程是否结束
	}
}
