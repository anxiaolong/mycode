package concurrent_08;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
/**
 * 固定容量线程池的简单使用
 */
public class Test04_FixedThreadPool_demo {
	//1.单线程做些比较复杂的运算
	public static List<Long> m1(long start,long end) {
		List<Long> list = new ArrayList<Long>();
		for (long i = start; i < end; i++) {
			for (long j = 1; j < Math.sqrt(i); j++) {
				if (i%j!=0&&Math.sqrt(i)%Math.sqrt(j)!=1) {
					list.add((long) (Math.sqrt(i)+Math.sqrt(j)));
				}
			}
		}
		return list;
	}
	
	//2.创建匿名内部类，实现callable接口
	static class MyTask implements Callable<List<Long>>{
		long start,end;
		
		public MyTask(long start,long end) {
			this.start = start;
			this.end = end;
		}
		
		//3.实现Callable核心方法
		@Override
		public List<Long> call() throws Exception {
			List<Long> list = new ArrayList<Long>();
			for (long i = start; i < end; i++) {
				for (long j = 1; j < Math.sqrt(i); j++) {
					if (i%j!=0&&Math.sqrt(i)%Math.sqrt(j)!=1) {
						list.add((long) (Math.sqrt(i)+Math.sqrt(j)));
					}
				}
			}
			return list;
		}
		
	}
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		//1.测试单线程完成运算
		long start = System.currentTimeMillis();
		m1(1,100000);
		long end = System.currentTimeMillis();
		System.out.println("单线程耗时："+(end-start));
		
		//2.测试多线程完成运算
		ExecutorService fixedThreadPool = Executors.newFixedThreadPool(5);
		MyTask myTask1 = new MyTask(1, 20000);
		MyTask myTask2 = new MyTask(20001, 40000);
		MyTask myTask3 = new MyTask(40001, 60000);
		MyTask myTask4 = new MyTask(60001, 80000);
		MyTask myTask5 = new MyTask(80001, 100000);
		Future<List<Long>> submit1 = fixedThreadPool.submit(myTask1);
		Future<List<Long>> submit2 = fixedThreadPool.submit(myTask2);
		Future<List<Long>> submit3 = fixedThreadPool.submit(myTask3);
		Future<List<Long>> submit4 = fixedThreadPool.submit(myTask4);
		Future<List<Long>> submit5 = fixedThreadPool.submit(myTask5);
		long start2 = System.currentTimeMillis();
		submit1.get();
		submit2.get();
		submit3.get();
		submit4.get();
		submit5.get();
		long end2 = System.currentTimeMillis();
		System.out.println("多线程耗时："+(end2-start2));
		fixedThreadPool.shutdown();
	}
}
