package concurrent_08;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
/**
 * 无容量限制的线程池（最大容量默认为Integer.MAX_VALUE）
 */
public class Test05_CachedThreadPool {
	public static void main(String[] args) throws InterruptedException {
		ExecutorService cachedThreadPool = Executors.newCachedThreadPool();
		
		for (int i = 0; i < 100; i++) {
			cachedThreadPool.execute(new Runnable() {
				@Override
				public void run() {
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(Thread.currentThread().getName());
				}
			});
		}
		
		TimeUnit.SECONDS.sleep(10);
		cachedThreadPool.shutdown();
	}
}
