package concurrent_08;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
/**
 * 计划任务线程池
 */
public class Test07_ScheduledThreadPool {
	public static void main(String[] args) {
		ScheduledExecutorService newScheduledThreadPool = Executors.newScheduledThreadPool(3);
		/**
		 * @param command the task to execute
	     * @param initialDelay the time to delay first execution
	     * @param period the period between successive executions
	     * @param unit the time unit of the initialDelay and period parameters
		 */
		for (int i = 0; i < 100; i++) {
			newScheduledThreadPool.scheduleAtFixedRate(new Runnable() {
				@Override
				public void run() {
					System.out.println(Thread.currentThread().getName());
				}
			}, 1, 2, TimeUnit.SECONDS);
		}
	}
}
