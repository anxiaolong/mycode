package concurrent_08;

import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;
/**
 * 分支合并线程池
 */
public class Test08_ForkJoinPool {
	final static int[] numbers = new int[1000000];
	final static int MAX_SIZE = 50000;
	final static Random r = new Random();
	
	//1.初始化数组
	static {
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = r.nextInt(1000);
		}
	}
	
	@SuppressWarnings("serial")
	static class AddTask extends RecursiveTask<Long>{
		int begin,end;
		
		public AddTask(int begin,int end) {
			this.begin = begin;
			this.end = end;
		}
		
		@Override
		protected Long compute() {
			if ((end - begin)<MAX_SIZE) {
				long sum = 0L;
				for (int i = begin; i < end; i++) {
					sum += numbers[i];
				}
				return sum;
			}else {
				int middle = begin + (end-begin)/2;
				AddTask task1 = new AddTask(begin, middle);
				AddTask task2 = new AddTask(middle, end);
				task1.fork();//开启新的任务分支
				task2.fork();
				return task1.join() + task2.join();
			}
		}
	}
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		long reslut = 0L;
		for (int i = 0; i < numbers.length; i++) {
			reslut += numbers[i];
		}
		System.out.println(reslut);
		
		ForkJoinPool pool = new ForkJoinPool();
		AddTask task = new AddTask(0, numbers.length);
		
		ForkJoinTask<Long> future = pool.submit(task);
		System.out.println(future.get());
	}
}
