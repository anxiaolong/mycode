package concurrent_08;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
/**
 * 固定容量线程池
 */
public class Test09_ThreadPoolExecutor {
	public static void main(String[] args) throws InterruptedException {
		ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(5, 5, 0L, TimeUnit.MILLISECONDS,
				new LinkedBlockingQueue<Runnable>());
		
		for (int i = 0; i < 10; i++) {
			threadPoolExecutor.execute(new Runnable() {
				@Override
				public void run() {
					System.out.println(Thread.currentThread().getName());
				}
			});
		}
		
		TimeUnit.SECONDS.sleep(3);
		System.out.println(threadPoolExecutor);
		threadPoolExecutor.shutdown();
	}
}
