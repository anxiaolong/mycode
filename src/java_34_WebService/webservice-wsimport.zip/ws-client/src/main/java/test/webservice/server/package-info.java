@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.webservice.test/")
package test.webservice.server;
