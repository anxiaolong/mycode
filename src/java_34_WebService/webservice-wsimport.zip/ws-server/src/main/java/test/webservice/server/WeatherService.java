package test.webservice.server;

import javax.jws.WebMethod;
import javax.jws.WebService;
/**
 * webservice����ӿ�
 */
@WebService
public interface WeatherService {
	@WebMethod
	String getWeatherByCity(String city);

}
