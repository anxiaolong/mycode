package test01_naming_style;

import org.junit.Test;

import java.util.List;

public class NamingStyle01 {

    /**
     * 1.常量名使用大写
     */
    @Test
    public void m1(){
        final String NAME = "naming style";
        final int COUNT = 100;
    }

    /**
     * 2.定义数组的规范方式
     */
    @Test
    public void m2(){
        int[] intArray = new int[]{1,2,3};
        int[] intArray2 = new int[10];
        String[] stringArray = new String[]{"1223","test"};
        String[] stringArray2 = new String[10];

        String stringArray3[];// 不推荐的使用方式来定义数组
    }

    /**
     * 3.boolean类型的属性命名前缀不加is
     * 它的get方法也是isXX,容易和框架产生冲突
     */
    private boolean isDeleted;
    public boolean isDeleted() {
        return isDeleted;
    }
}

/**
 * 4.带有返回值方法的命名
 */
interface TestMethodNaming{
    String getName();// 获取单个对象使用get前缀

    List<String> listString();// 获取多个对象使用list前缀

    int countObject();// 统计数据使用count作为前缀

    // 插入方法使用save/insert前缀
    int saveObject();
    int insertObject();

    // 删除方法用remove/delete前缀
    int removeObjcet();
    int deleteObject();

    // 修改方法使用update前缀
    int updateObject();
}
