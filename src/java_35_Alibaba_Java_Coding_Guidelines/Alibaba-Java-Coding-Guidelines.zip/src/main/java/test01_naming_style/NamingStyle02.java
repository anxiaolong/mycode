package test01_naming_style;

import java.util.List;

/**
 * 1.接口的方法前不加任何修饰符
 */
public interface NamingStyle02 {

    void m1();

    List<String> listString();

    /**
     * jdk8允许接口有默认的实现方法
     */
    default List<String> listString(int a){
        return null;
    }

}

/**
 * 2.接口实现类添加Impl后缀和接口做区分
 */
class NamingStyle02Impl implements NamingStyle02{

    @Override
    public void m1() {

    }

    @Override
    public List<String> listString() {
        return null;
    }

    public static void main(String[] args) {
        NamingStyle02Impl namingStyle02 = new NamingStyle02Impl();
        List<String> list = namingStyle02.listString(1);
    }
}

/**
 * 3.枚举类后缀加上Enum
 */
enum SexEnum{
    MAN(1,"男"),WOMAN(0,"女");
    private int code;
    private String sex;
    SexEnum(int code,String sex) {
        this.code = code;
        this.sex = sex;
    }
}

