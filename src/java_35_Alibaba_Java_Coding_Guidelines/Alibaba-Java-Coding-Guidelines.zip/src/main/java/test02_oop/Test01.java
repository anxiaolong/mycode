package test02_oop;

import org.junit.Ignore;
import org.junit.Test;

import java.util.Objects;

public class Test01 {

    /**
     * 1.Objects下的工具方法可以避免空指针
     */
    @Test
    @Ignore
    public void test1(){
        System.out.println(Objects.equals("111", "dfdf"));
    }

    /**
     * 2.split方法分隔符后没有内容是不会记录到数组
     */
    @Test
    @Ignore
    public void test2(){
        String s = "a,b,c,,";
        String[] split = s.split(",");
        System.out.println(split.length);
        for (String s1 : split) {
            System.out.println(s1);
        }
    }

    /**
     * 3.大量拼接字符串使用StringBuilder append方法
     */
    @Test
    public void test3(){
        // 需要大量拼接字符串不宜使用String类型
        String a = "";
        for (int i = 0; i < 10; i++) {
            a = "test"+i;
        }
        System.out.println(a);

        // 大量拼接字符串使用StringBuilder append方法
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(i);
        }
        System.out.println(sb);
    }

}
