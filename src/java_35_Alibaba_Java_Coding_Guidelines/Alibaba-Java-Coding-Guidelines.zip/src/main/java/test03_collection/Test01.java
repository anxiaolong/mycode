package test03_collection;

import org.junit.Ignore;
import org.junit.Test;

import java.util.*;

public class Test01 {
    /**
     * 1.subList方法返回的list不能强转为arraylist
     */
    @Test
    @Ignore
    public void test1(){
        List<String> list = new ArrayList<>();
        list.add("12");
        list.add("ere");
        list.add("3434");
        List<String> list1 = list.subList(0, 1);
        ArrayList<String> list11 = (ArrayList<String>) list1;
    }

    /**
     * 2.toArray方法传入的数组最好和list的size一致
     */
    @Test
    @Ignore
    public void test2(){
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(3);
        list.add(5);
        Integer[] intArray = new Integer[list.size()];
        Integer[] integers = list.toArray(intArray);
        for (Integer integer : integers) {
            System.out.println(integer);
        }
    }

    /**
     * 3.Arrays.asList只是接口转换，add方法会异常
     */
    @Test
    @Ignore
    public void test3(){
        String[] stringArray = new String[]{"dfdf","test","erere"};
        List<String> list = Arrays.asList(stringArray);
        list.add("test2");
    }

    /**
     * 4.集合再遍历过程中做删除操作会异常（用线程安全的容器）
     */
    @Test
    @Ignore
    public void test4(){
        List<String> list = new ArrayList<>();
        list.add("dfdf");
        list.add("aaaa");
        list.add("bbbb");

        for (String s : list) {
            if (s.equals("dfdf")){
                list.remove(s);
            }
        }
    }

    /**
     * 5.<? extends T>  <? super T>
     * <? extends T>不知道存了什么，不能add，只能get
     * <? super T>可以add T以及T的子类
     */
    @Test
    public void test5(){
        // 1.<? extends Father>不能使用add方法，可以使用get
        List<Father> list = new ArrayList<>();
        list.add(new Father());
        list.add(new Father());
        List<? extends Father> list1 = new ArrayList<>();
        //list1.add(new Son());
        list1 = list;
        System.out.println(list1.get(0));

        //2.<? super Father>
        List<? super Father> list2 = new ArrayList<>();
        list2.add(new Father());
        list2.add(new Son());
        System.out.println(list2.get(0));
        System.out.println(list2.get(1));
    }

    /**
     * 6.遍历map,使用foreach最方便
     */
    @Test
    @Ignore
    public void test6(){
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"dfdf");
        map.put(2,"ssss");
        map.put(3,"tttttt");
        map.forEach((key,value)->
                System.out.println(key+"-->"+value)
                );
    }
}

class GrandFather {}
class Father extends GrandFather {}
class Son extends Father{}
