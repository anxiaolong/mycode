package test04_concurrent;

import org.junit.Ignore;
import org.junit.Test;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAdjusters;

public class LocalDateTime_Test {
    /**
     * 1.日期处理类LocalDate
     */
    @Test
    @Ignore
    public void test1(){
        // 获取当前日期
        LocalDate now = LocalDate.now();
        System.out.println(now);
        // 设置日期
        LocalDate localDate = LocalDate.of(2018,3,21);
        System.out.println(localDate);
        // 获取年
        System.out.println(localDate.getYear());
        System.out.println(localDate.get(ChronoField.YEAR));
        // 获取月
        System.out.println(localDate.getMonthValue());
        System.out.println(localDate.get(ChronoField.MONTH_OF_YEAR));
        // 获取日
        System.out.println(localDate.getDayOfMonth());
        System.out.println(localDate.get(ChronoField.DAY_OF_MONTH));
        // 获取星期
        System.out.println(localDate.getDayOfWeek());
        System.out.println(localDate.get(ChronoField.DAY_OF_WEEK));
    }

    /**
     * 2.LocalTime时间处理类
     */
    @Test
    @Ignore
    public void test2(){
        // 获取当前时间
        LocalTime now = LocalTime.now();
        System.out.println(now);
        // 设置时间
        LocalTime localTime = LocalTime.of(23,13,55);
        System.out.println(localTime);
        // 获取小时
        System.out.println(localTime.getHour());
        System.out.println(localTime.get(ChronoField.HOUR_OF_DAY));
        // 获取分钟
        System.out.println(localTime.getMinute());
        System.out.println(localTime.get(ChronoField.MINUTE_OF_HOUR));
        // 获取秒
        System.out.println(localTime.getSecond());
        System.out.println(localTime.get(ChronoField.SECOND_OF_MINUTE));
    }

    /**
     * 3.LocalDateTime
     */
    @Test
    @Ignore
    public void test3(){
        // 获取当前时间
        LocalDateTime now = LocalDateTime.now();
        System.out.println(now);

        // 设置日期
        LocalDateTime localDateTime = LocalDateTime.of(2011,12,23,
                13,55,59);
        LocalDateTime localDateTime1 = LocalDateTime.of(
                LocalDate.of(2021,1,12),
                LocalTime.of(12,34,33));

        System.out.println(localDateTime);
        System.out.println(localDateTime1);

        // 获取LocalDate
        LocalDate localDate = localDateTime.toLocalDate();
        System.out.println(localDate);
        // 获取LocalDateTime
        LocalTime localTime = localDateTime.toLocalTime();
        System.out.println(localTime);
    }

    /**
     * 4.Instance获取秒和毫秒
     */
    @Test
    public void test4(){
        Instant instant = Instant.now();
        System.out.println(instant);
        System.out.println(instant.getEpochSecond());
        System.out.println(instant.toEpochMilli());
    }

    /**
     * 5.日期增减和运算
     */
    @Test
    @Ignore
    public void test5(){
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println(localDateTime);
        // 日期增加
        LocalDateTime localDateTime1 = localDateTime.plusYears(3)
                .plusMonths(5)
                .plusDays(6)
                .plusHours(3)
                .plusMinutes(20)
                .plusSeconds(33);
        System.out.println(localDateTime1);
        // 日期减
        LocalDateTime localDateTime2 = localDateTime.minusYears(3)
                .minusMonths(5)
                .minusDays(6)
                .minusHours(3)
                .minusMinutes(20)
                .minusSeconds(33);
        System.out.println(localDateTime2);
        // with修改年月日时分秒
        LocalDateTime localDateTime3 = localDateTime.withHour(23).withYear(1990);
        System.out.println(localDateTime3);
        // TemporalAdjusters工具类对计算简单日期
        LocalDate localDate = LocalDate.now();
        System.out.println(localDate.with(TemporalAdjusters.firstDayOfYear()));
        System.out.println(localDate.with(TemporalAdjusters.next(localDate.getDayOfWeek())));
    }

    /**
     * 6.日期格式化
     */
    @Test
    public void Test6(){
        LocalDateTime localDateTime = LocalDateTime.now();
        // 固定模板格式化
        System.out.println(localDateTime.format(DateTimeFormatter.BASIC_ISO_DATE));
        System.out.println(localDateTime.format(DateTimeFormatter.ISO_DATE_TIME));
        // 自定义格式化模板
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/mm/dd");
        String format = localDateTime.format(formatter);
        System.out.println(format);
    }

    /**
     * 7.获取时间戳
     */
    @Test
    public void test7(){
        LocalDateTime localDateTime = LocalDateTime.now();
        long timestamps = localDateTime.toInstant(ZoneOffset.of("+8")).toEpochMilli();
        System.out.println(timestamps);
        // 当前时间戳做简单获取方法
        System.out.println(System.currentTimeMillis());
    }
}