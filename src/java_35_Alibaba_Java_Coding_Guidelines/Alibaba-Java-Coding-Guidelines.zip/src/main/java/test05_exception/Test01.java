package test05_exception;

import org.junit.Test;
import java.io.*;

public class Test01 {
    /**
     * 1.try-catch-finally
     * 在finally中实现对资源的回收(比较繁琐)
     */
    @Test
    public void test1(){
        InputStream is = null;
        try {
            is = new FileInputStream(new File("/test.txt"));
            is.read();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 2.使用try with resource方法回收资源（推荐）
     */
    @Test
    public void test2(){
        try (InputStream is = new FileInputStream(new File("test.tex"))) {
            is.read();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
