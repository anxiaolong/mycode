package test05_exception;

import java.util.Optional;

/**
 * 使用Optional类防止参数空指针异常
 */
public class Test02_Optional {
    public Integer sum(Optional<Integer> a,Optional<Integer> b){
        // isPresent()判断值是否存在
        System.out.println("a是否存在:"+a.isPresent()+" b是否存在:"+b.isPresent());

        // orElse方法，取值存在返回它，不存在返回默认值
        Integer valueA = a.orElse(new Integer(0));
        Integer valueB = b.orElse(new Integer(0));
        return valueA+valueB;
    }

    public static void main(String[] args) {
        Test02_Optional t = new Test02_Optional();

        Integer value1 = null;
        Integer value2 = 3;
        // 允许参数为空
        Optional<Integer> a = Optional.ofNullable(value1);
        // 参数不允许为空
        Optional<Integer> b = Optional.of(value2);

        System.out.println(t.sum(a, b));
        System.out.println(t.sum(b, a));
    }
}
