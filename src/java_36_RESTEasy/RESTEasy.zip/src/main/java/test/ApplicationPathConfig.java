package test;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.springframework.stereotype.Component;

/**
 *指定servletMapping的路径，不写这个类默认根目录
 */
@Component
@ApplicationPath("/v1")
public class ApplicationPathConfig extends Application {

}
