package test.common;

import lombok.Data;

@Data
public class Response {
	private String resCode;
	private String resMsg;
	private Object data;
	
	public Response(ResEnum resEnum, Object data) {
		this.resCode = resEnum.getResCode();
		this.resMsg = resEnum.getResMsg();
		this.data = data;
	}
}
