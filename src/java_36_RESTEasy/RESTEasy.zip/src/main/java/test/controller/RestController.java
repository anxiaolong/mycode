package test.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

import org.jboss.resteasy.annotations.Form;
import org.springframework.stereotype.Component;

import test.common.ResEnum;
import test.common.Response;
import test.pojo.Music;
import test.pojo.MusicDTO;
import test.pojo.MusicQuery;
import test.service.MusicService;

/**
 * 测试使用resteasy常用注解
 * 1.GET
 * 2.PUT
 * 3.POST
 * 4.DELETE
 * 5.PathParam
 * 6.QueryParam
 * 7.HeaderParam
 * 8.CookieParam
 * 9.MatrixParam
 * 10.FormParam
 * 11.Form
 * 12.DefaultValue
 * 13.Context
 * 14.Encoded and encoding
 */
@Component
@Path("/music")
public class RestController {
	@Resource
	private MusicService musicService;
	
	/**
	 * 查询歌曲接口
	 * @return
	 */
	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public Response listMusic() {
		MusicQuery musicQuery = new MusicQuery();
		List<Music> listMusic = musicService.listMusic(musicQuery);
		Response response = new Response(ResEnum.SUCCESS, listMusic);
		return response;
	}
	
	/**
	 * 修改歌曲名接口
	 * @param musicId
	 * @param musicDTO
	 * @return
	 */
	@PUT
	@Path("/put/{musicId}")
	@Produces(MediaType.APPLICATION_JSON) // 响应参数为json
	@Consumes(MediaType.APPLICATION_JSON) // 请求参数为json
	public Response updateMusicName(@PathParam("musicId") String musicId,
			MusicDTO musicDTO) {
		Response response=null;
		musicDTO.setMusicId(musicId);
		int updateMusicName = musicService.updateMusicName(musicDTO);
		if (updateMusicName==1) {
			response = new Response(ResEnum.SUCCESS,"");
		}else {
			response = new Response(ResEnum.FAIL,"");
		}
		
		return response;
	}
	
	/**
	 * 更新歌曲信息接口
	 * @param musicId
	 * @param musicDTO
	 * @return
	 */
	@POST
	@Path("/update/{musicId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateMusic(@PathParam("musicId") String musicId,
			MusicDTO musicDTO) {
		musicDTO.setMusicId(musicId);
		int updateMusic = musicService.updateMusic(musicDTO);
		
		Response response=null;
		if (updateMusic==1) {
			response = new Response(ResEnum.SUCCESS,"");
		}else {
			response = new Response(ResEnum.FAIL,"");
		}
		return response;
	}

	/**
	 * 删除歌曲
	 * @param musicId
	 * @return
	 */
	@DELETE
	@Path("/delete/{musicId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteMusic(@PathParam("musicId") String musicId) {
		int i = musicService.deleteMusic(musicId);
		Response response = null;
		if (i == 1) {
			response = new Response(ResEnum.SUCCESS,"");
		}else {
			response = new Response(ResEnum.FAIL,"");
		}
		return response;
	}

	/**
	 * QueryParam获取url中的参数
	 * HeaderParam获取Header中参数
	 * CookieParam获取cookie中参数
	 * matrixParam用来分离参数和；一起使用
	 * DefaultValue可以在QueryParam前加一个默认值
	 * @param name
	 * @return
	 */
	@GET
	@Path("/query/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response queryMusicByName(@DefaultValue("我是DefaultValue")@QueryParam("name") String name,
									 @PathParam("name") String name2,
									 @HeaderParam("key-code") String key,
									 @CookieParam("cookie") String cookie,
									 @MatrixParam("name") String test){
		return new Response(ResEnum.SUCCESS,
				name+"--"+name2+"--"+key+"--"+cookie+"--"+test);
	}

	/**
	 *FormParam获取表单参数
	 */
	@POST
	@Path("/form")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED) // 设置表单传递参数
	public Response testFormParam(@FormParam("id") int id,
								  @FormParam("name") String name,
								  @FormParam("pwd") String pwd){
		return new Response(ResEnum.SUCCESS,id+"-"+name+"-"+pwd);
	}

	/**
	 *Form把参数直接注入对象
	 * @param musicDTO 直接把参数注入成对象
	 */
	@POST
	@Path("/form2/{musicId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response testForm(@Form MusicDTO musicDTO){
		return new Response(ResEnum.SUCCESS,musicDTO);
	}

	/**
	 *Context 注入上下文参数
	 * 过滤器中使用较多
	 */
	@POST
	@Path("/context")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response testContext(
			@Context HttpServletRequest request,
			@Context HttpServletResponse response,
			@Context ServletConfig servletConfig,
			@Context ServletContext servletContext,
			@Context HttpHeaders headers,
			@Context UriInfo uriInfo,
			@Context Request rsRequest,
			@Context ServletConfig servletConfig1
			){
		System.out.println(request);
		System.out.println(response);
		System.out.println(servletConfig);
		System.out.println(servletContext);
		System.out.println(headers);
		System.out.println(uriInfo);
		System.out.println(rsRequest);
		System.out.println(servletConfig1);
		return new Response(ResEnum.SUCCESS,"");
	}

	/**
	 * Encoded对参数url编码
	 */
	@POST
	@Path("/form3")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response testEcode(
			@Encoded@FormParam("test1") String test1,@Encoded@FormParam("test2") String test2){
		return new Response(ResEnum.SUCCESS,test1+"--"+test2);
	}

}
