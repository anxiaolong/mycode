package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import test.pojo.Music;
import test.pojo.MusicDTO;
import test.pojo.MusicQuery;

public interface MusicMapper {
	
	List<Music> listMusic(MusicQuery musicQuery);
	
	int updateMusicNameByMusicId(MusicDTO musicDTO);
	
	int updateMusicByMusicId(MusicDTO musicDTO);
	
	int deleteMusicByMusicId(@Param("musicId") String musicId);
}
