package test.pojo;

import lombok.Data;

import javax.ws.rs.FormParam;
import javax.ws.rs.PathParam;

@Data
public class MusicDTO {
	@PathParam("musicId")
	private String musicId;
	private String createTime;
	@FormParam("musicName")
	private String musicName;
	@FormParam("singerName")
	private String singerName;
	private String albumNames;
	private String songAuthorName;
	private String lyricAuthorName;
	private String length;
	private String language;
	private String picUrl;
	private String lrcUrl;
	private String isCollection;
	private String isCpAuth;
	private String auditionsFlag;
	private int vid;
}
