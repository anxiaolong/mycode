package test.service;

import java.util.List;

import test.pojo.Music;
import test.pojo.MusicDTO;
import test.pojo.MusicQuery;

public interface MusicService {
	
	List<Music> listMusic(MusicQuery musicQuery);
	
	int updateMusicName(MusicDTO musicDTO);
	
	int updateMusic(MusicDTO musicDTO);

	int deleteMusic(String musicId);
}
