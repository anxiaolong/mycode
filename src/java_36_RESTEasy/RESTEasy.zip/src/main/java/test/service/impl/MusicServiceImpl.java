package test.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import test.mapper.MusicMapper;
import test.pojo.Music;
import test.pojo.MusicDTO;
import test.pojo.MusicQuery;
import test.service.MusicService;

@Service
public class MusicServiceImpl implements MusicService {
	@Resource
	private MusicMapper musicMapper;

	@Override
	public List<Music> listMusic(MusicQuery musicQuery) {
		return musicMapper.listMusic(musicQuery);
	}

	@Override
	public int updateMusicName(MusicDTO musicDTO) {
		return musicMapper.updateMusicNameByMusicId(musicDTO);
	}

	@Override
	public int updateMusic(MusicDTO musicDTO) {
		return musicMapper.updateMusicByMusicId(musicDTO);
	}

	@Override
	public int deleteMusic(String musicId) {
		return musicMapper.deleteMusicByMusicId(musicId);
	}

}
