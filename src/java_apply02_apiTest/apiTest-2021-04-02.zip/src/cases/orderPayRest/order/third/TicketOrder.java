package cases.orderPayRest.order.third;
/**
 * ������Ʊ�µ�
 */

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.orderPayRest.order.third.TicketOrder;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TicketOrder extends ApiAdapter {
	public TicketOrder() {
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		//8170�ǲ��� 8178��ȫ����
		this.setUrl("http://10.25.193.30:8170/orderPayRest/order/third/ticketOrder");
		//1.������;����ȥ���˺���Ϣ��һ��ʹ��order�ӿ�ֱ�ӵ���
		//ticketItemId showItemId projectId��GetTicketProject��ȡ 
		//seatInfoId ��NotifySeatInfo��ȡ
		//vipFlag 0�ǰ׽� 1�׽� 2���Ѱ׽�
		JSONObject data=JSON.parseObject("{"
				+ "\"orderPayment\":{"
				+ "\"paymentId\":\"100000120201223032142001\","
				+ "\"totalPrice\":\"1200\","
				+ "\"source\":\"02\","
				+ "\"vipFlag\":\"1\","
				+ "\"msisdn\":\"15828637397\","
				+ "\"uid\":\"666-666-666\","
				+ "\"channelID\":\"010004D\","
				+ "\"notifyUrl\":\"http://10.25.193.180:18089/MIGUM2.0/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"showItemId\":\"12100098200\","
				+ "\"projectId\":\"121000982\","
				+ "\"cardPayPrice\":\"0\","
				+ "\"thirdPrice\":\"1200\","
				+ "\"goodsCount\":\"1\","
				+ "\"ticketItemId\":\"1010\","
				+ "\"receiveType\":\"3\","
				+ "\"orderType\":\"2\","
				+ "\"invoiceFlag\":\"0\","
				+ "\"cardPwd\":\"\","
				+ "\"seatInfoId\":\"20210222850ed51c-2231-4362-80a0-46cb50f11718\","
				+ "\"electronicType\":\"30\","
				+ "\"idCard\":\"\","
				+ "\"ticketList\":[{\"ticketNo\":\"\"}],"
				+ "\"postInfo\":{"
				+ "\"province\":\"�Ĵ�ʡ\","
				+ "\"city\":\"�ɶ���\","
				+ "\"country\":\"������\","
				+ "\"detailAddr\":\"������123��\","
				+ "\"charge\":\"100\","
				+ "\"receiver\":\"�ֺ�\","
				+ "\"phone\":\"15828637397\","
				+ "\"specialNote\":\"\"},"
				+ "\"invoiceInfo\":{"
				+ "\"invoiceType\":\"\","
				+ "\"invoiceTitle\":\"\","
				+ "\"taxpayerNum\":\"\","
				+ "\"invoiceObtainMode\":\"\","
				+ "\"invoiceEmail\":\"\","
				+ "\"invoiceExpressAddress\":\"\","
				+ "\"invoiceConsignee\":\"\","
				+ "\"invoicePhone\":\"\"},"
				+ "\"paidAccounts\":[{"
				+ "\"paidAccountNo\":\"\"},"
				+ "{\"paidAccountNo\":\"\"}],"
				+ "\"ticketHolders\":[{\"identityNum\":\"NTEwNjAzMTk4MzA1MTY1OTNY\",\"identityName\":\"5b2t5pyX\"}]}}");
		((JSONObject) data.get("orderPayment")).put("paymentId", DataUtils.getOrderId("1000014"));
		this.setData(data);
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("partner", this.getPartner());
		newReq.put("time", DataUtils.getTime());
		return newReq.toString();
	}
	
	@Test
	public void test_ticketOrder() throws IOException, EncoderException {
		TicketOrder ticketOrder=new TicketOrder();
		assertThat(DataUtils.sendRequest(ticketOrder.getUrl(), ticketOrder.getRequest()), 
				containsString("\"data\":null,\"retCode\":\"630020\",\"retMsg\":\"[PCARD]������Ŀ������Ʊ\""));
	}

}
