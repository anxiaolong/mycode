package cases.payment2.migu.senior;
/**
 * ����֧�������ѯ�ӿ�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.payment2.migu.senior.ChargeQuery2;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class ChargeQuery2 extends ApiAdapter {

	public ChargeQuery2() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment2/migu/senior/chargeQuery2");
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"partner\":\"1000014\","
				+ "\"time\":\"xx\","
				+ "\"signType\":\"MD5\","
				+ "\"transactionId\":"+"\"100001420210223153314697\""+","
				+ "\"transDate\":\"20210223\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		ChargeQuery2 charge=new ChargeQuery2();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
