package cases.ticketRest.ticket;
/**
 * �������͵�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.ticketRest.ticket.GiftForm;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class GiftForm extends ApiAdapter {
	public GiftForm() {
		this.setUrl("http://"+this.getAlltestip()+":18701/ticketRest/ticket/giftForm");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		this.setData(new JSONObject());
		this.getData().put("custId", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("orderId", "100000420210323101327700");
		this.getData().put("pid", "121001003");
		this.getData().put("custPhone", "15928791968");
		this.getData().put("giveNum", "5");
		
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("signType", "MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
	
	
	@Test
	public void test_GetTicketProject() throws Exception {
		GiftForm getTicketProject=new GiftForm();
		assertThat(DataUtils.sendRequest(getTicketProject.getUrl(), getTicketProject.getRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"��ѯ�ɹ�\""));
	}

}
