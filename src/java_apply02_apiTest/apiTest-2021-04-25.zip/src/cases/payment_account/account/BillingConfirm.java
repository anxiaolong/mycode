package cases.payment_account.account;
/**
 * ���Ʒ�ȷ�Ͻӿ�
 */
import java.io.IOException;
import org.apache.commons.codec.EncoderException;
import org.junit.Test;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import cases.payment_account.account.BillingConfirm;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;


public class BillingConfirm extends ApiAdapter {
	public BillingConfirm() {
		this.setUrl("http://"+this.getTestip()+":18101/payment-account/account/billingConfirm");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"amount\":\"10\","
				+ "\"activityId\":\"1676\","
				+ "\"goodcount\":\"1\","
				+ "\"busiType\":\"49\","
				+ "\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"copyRightId\":\"600504080015\","
				+ "\"channelCode\":\"TEST000\","
				+ "\"cardPrice\":\"3\","
				+ "\"bizCode\":\"600987040014706681\","
				+ "\"orderId\":\"100001420210422135928482\","
				+ "\"contentId\":\"600987040014706681\","
				+ "\"deviceId\":\"7654321\""
				+ "}");
		
		this.setData(parseObject);
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("signType","MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
	
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		BillingConfirm getAccountList=new BillingConfirm();
		DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getRequest());
	}

}
