package cases.payment_account.account;
/**
 * ר���ֿ�����б�
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

public class CardBalanceList extends ApiAdapter {
	public CardBalanceList() {
		this.setUrl("http://"+this.getTestip()+":18101/payment-account/account/cardBalanceList");
		this.setPartner("1000004");
		this.setKey("HWFI1KTJ2C8VNV9240VWOE923JS092JC");
		this.setData(new JSONObject());
		this.getData().put("uid","a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("accountId","15928791968");
		this.getData().put("copyrightId","600504080015");
		this.getData().put("cardType","49");
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("signType","MD5");
		newReq.put("partner",this.getPartner());
		return newReq.toString();
	}
	
	@Test
	public void test_CardPresentBalance() throws IOException, EncoderException {
		CardBalanceList cpb=new CardBalanceList();
		DataUtils.sendRequest(cpb.getUrl(), cpb.getRequest());
	}
}
