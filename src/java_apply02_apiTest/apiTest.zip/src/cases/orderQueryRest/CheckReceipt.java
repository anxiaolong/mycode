package cases.orderQueryRest;
/**
 * ��Ʒ֧������У��ӿ�
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

public class CheckReceipt extends ApiAdapter {
	public CheckReceipt() {
		//ȫ���Ի�����ַ
		this.setUrl("http://10.25.193.30:8178/orderQueryRest/checkReceipt");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"productId\": \"023\","
				+ "\"orderId\": \"100001420210223174153656\","
				+ "\"transactionId\": \"100001420210223174153656\","
				+ "\"uid\": \"d125c6e8-2079-4b81-bd91-9f337eec30ab\","
				+ "\"partner\": \"1000014\",\"time\": \"20210223174153\","
				+ "\"receiptData\":\"bbbbdfdfdfdf\",\"enviroment\":\"01\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_TicketOrderQuery() throws IOException, EncoderException {
		CheckReceipt toq=new CheckReceipt();
		DataUtils.sendRequest(toq.getUrl(), toq.getRequest());
	}

}
