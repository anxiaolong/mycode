package cases.payment2.migu.senior;
/**
 * �乾��/�乾ȯ������̨֧���ӿ�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.payment2.migu.senior.AuthCharge;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class AuthCharge extends ApiAdapter {

	public AuthCharge() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8178/payment2/migu/senior/authCharge");
		String orderId=DataUtils.getOrderId(this.getPartner());
		JSONObject parseObject = JSON.parseObject("{\"AccessMode\":\"3\",\"AccessPlatformID\":\"0146951\","
				+ "\"MSISDN\":\"18210030020\","
				+ "\"partner\":\"1000014\",\"passId\":\"383461296272569892\","
				+ "\"payInfo\":[{\"BizCode\":\"633986Z04000000140\","
				+ "\"ContentID\":\"633986Z04000000140\",\"CopyRightID\":\"633986V0140Q\","
				+ "\"ExpansionParam\":\"musicApp\",\"InterfaceType\":\"order\","
				+ "\"actionId\":\"musicApp\",\"count\":\"1\","
				+ "\"goodsName\":\"�������Ʊѡ\","
				+ "\"orderId\":\""+orderId+"\",\"price\":10}],\"productId\":\"028\","
						+ "\"time\":\""+DataUtils.getTime()+"\",\"totalPrice\":10,"
				+ "\"transactionId\":\""+orderId+"\",\"uid\":\"d125c6e8-2079-4b81-bd91-9f337eec30ab\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		AuthCharge charge=new AuthCharge();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
