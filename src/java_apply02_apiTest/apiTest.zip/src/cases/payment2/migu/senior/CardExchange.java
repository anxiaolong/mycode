package cases.payment2.migu.senior;
/**
 * ���ֿ��һ����ֲ�Ʒ�ӿ�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.payment2.migu.senior.CardExchange;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class CardExchange extends ApiAdapter {

	public CardExchange() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment2/migu/senior/cardExchange");
		String orderId=DataUtils.getOrderId(this.getPartner());
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"partner\":\"1000014\","
				+ "\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+orderId+"\","
				+ "\"orderId\":\""+orderId+"\","
				+ "\"uid\":\"5e0fd32d-c4dd-443b-8ed7-6a098b9ece31\","
				+ "\"msisdn\":\"13679078746\",\"cardSN\":\"EC20662100000677\","
				+ "\"accessPlatformID\":\"01478AT\","
				+ "\"showCodeGiveId\":\"2103170130\","
				+ "\"cardKey\":\"\",\"did\":\"1128050\",\"purchaseWay\":\"99\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		CardExchange charge=new CardExchange();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
