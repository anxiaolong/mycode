package cases.payment2.migu.senior;
/**
 * ������֧���˿�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.payment2.migu.senior.Refund;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class Refund extends ApiAdapter {

	public Refund() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment2/migu/senior/refund");
		//1.���ǲ��Զ����޷��ɹ���������������select * from T_ORD_REFUND t where t.order_id='100001420210224164057674';
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"partner\": \"1000014\","
				+ "\"time\": \"20210224164057\"," //time��Ҫ�Ͷ���һ��
				+ "\"transactionId\": \"100001420210224164057674\","
				+ "\"orgTransactionId\": \"100001420210224164057674\","
				+ "\"orderId\": \"100001420210224164057674\","
				+ "\"refundAmount\": \"390\"," //�˴��˿�����Ҫ�Ͷ���һ�»�С��
				+ "\"refundInfo\": \"�����޷�����\","
				+ "\"DID\": \"1128050\",\"refundNotifyURL\": \"\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		Refund charge=new Refund();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
