package cases.payment_account.account;
/**
 * ��ѯ�ҵĿ��ó�����
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.payment_account.account.GetCardBalance;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 

public class GetCardBalance extends ApiAdapter {
	public GetCardBalance() {
		//ȫ����10.25.245.181
		//����10.25.193.16
		this.setUrl("http://"+this.getAlltestip()+":18101/payment-account/account/getCardBalance");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		JSONObject parseObject = JSON.parseObject("{"
				+ "\"partner\": \""+this.getPartner()+"\","
				+ "\"UID\": \"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"MSISDN\": \"15928791968\","
				+ "\"cardType\": \"48\"}");
		this.setData(parseObject);
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		GetCardBalance getAccountList=new GetCardBalance();
		assertThat(DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�ɹ�\""));
	}

}
