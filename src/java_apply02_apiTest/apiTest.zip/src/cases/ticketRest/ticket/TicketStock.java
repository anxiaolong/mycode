package cases.ticketRest.ticket;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

public class TicketStock extends ApiAdapter {
	public TicketStock() {
		this.setUrl("http://10.25.193.16:18701/ticketRest/ticket/ticketStock");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		this.setData(new JSONObject());
		this.getData().put("pid", "121000902");
		this.getData().put("showId", "12100090200");
		this.getData().put("ticketItemId", "931");
		this.getData().put("source", "00");
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("signType", "MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
	
	@Test
	public void test_TicketStock() throws IOException, EncoderException {
		TicketStock t1=new TicketStock();
		assertThat(DataUtils.sendRequest(t1.getUrl(), t1.getRequest()),
				containsString("\"retCode\":\"000000\",\"retMsg\":\"��ѯ�ɹ�\""));
	}
}
