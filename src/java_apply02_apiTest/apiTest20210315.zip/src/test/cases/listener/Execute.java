package test.cases.listener;

import org.junit.runner.JUnitCore;

import cases.orderPayRest.order.third.AliPay;
import cases.orderPayRest.order.third.CancelTicketOrder;
import cases.orderPayRest.order.third.TicketOrder;
import cases.orderPayRest.order.third.TicketRefund;
import cases.orderQueryRest.TicketOrderQuery;
import cases.payment2.migu.senior.Charge;
import cases.payment2.migu.senior.SdkChargePre;
import cases.payment_account.account.CardPresentBalance;
import cases.payment_account.account.GetAccountList;
import cases.ticketRest.ticket.GetTicketProject;
import cases.ticketRest.ticket.NotifySeatInfo;
import cases.ticketRest.ticket.Order;
import cases.ticketRest.ticket.TicketProjectList;
import cases.ticketRest.ticket.TicketStock;

public class Execute {

    public static void main(String[] args) {
        run(
        		CancelTicketOrder.class,
        		Charge.class,
        		GetAccountList.class,
        		GetTicketProject.class,
        		NotifySeatInfo.class,
        		Order.class,
        		SdkChargePre.class,
        		TicketOrder.class,
        		TicketProjectList.class,
        		TicketRefund.class,
        		TicketStock.class,
        		AliPay.class,
        		TicketOrderQuery.class,
        		CardPresentBalance.class	
        		);
    }

    private static void run(Class<?>... classes) {
        for (Class<?> clazz : classes) {
            JUnitCore runner = new JUnitCore();
            ExecutionListener listener = new ExecutionListener();
            runner.addListener(listener);
            runner.run(clazz);
            MyResultRecorder recorder = listener.recorder;
            System.out.println(recorder);
        }
    }
}