package cases.orderNotifyRest;
/**
 * ר���ֿ�����ͬ���ӿ�
 */
import java.io.IOException;
import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;


public class SyncDeductionAlbum extends ApiAdapter {
	public SyncDeductionAlbum() {
		this.setData(new JSONObject());
		
		this.getData().put("purchasedCopyrightId", "600504080035");
		this.getData().put("purchasedCopyrightTime", "20201212013000");
		this.getData().put("deductionCopyrightId", "600504080015");
		this.getData().put("deductionCopyrightTime", "20201212013000");
		this.getData().put("deductionPrice", "2");
		
		this.setUrl("http://10.25.193.30:8170/orderNotifyRest/syncDeductionAlbum");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setIsUrlEcode("false");
	}
	
	@Override
		public String getRequest() throws EncoderException {
			JSONObject newRequest = JSON.parseObject(super.getRequest());
			newRequest.put("partner", "1000014");
			newRequest.put("time", DataUtils.getTime());
			return newRequest.toString();
		}
	
	
	@Test
	public void testNormalRequest() throws IOException, EncoderException {
		SyncDeductionAlbum request=new SyncDeductionAlbum();
		DataUtils.sendRequest(request.getUrl(),request.getRequest());
	}
}
