package cases.payment2.migu.card;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import java.io.IOException;

import org.apache.commons.codec.EncoderException; 
/**
 * Ʊ����ȡ�ӿ�
 */
public class Present extends ApiAdapter {

	public Present() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment2/migu/card/present");
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"uid\": \"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"partner\": \"1000014\","
				+ "\"channel\": \"0140070\","
				+ "\"actionId\": \"02021914310\","
				+ "\"appKey\": \"1000014\",\"time\": \""+DataUtils.getTime()+"\","
				+ "\"terminal\": \"IOS\",\"msisdn\": \"15928791968\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		Present present=new Present();
		DataUtils.sendRequest(present.getUrl(), present.getRequest());
	}

}
