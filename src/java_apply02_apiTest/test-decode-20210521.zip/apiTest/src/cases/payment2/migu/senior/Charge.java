package cases.payment2.migu.senior;
import org.junit.Ignore;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cases.payment2.migu.senior.Charge;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import java.io.IOException;

import org.apache.commons.codec.EncoderException; 

/**
 * ��ҳ�µ��ӿ�
 */
public class Charge extends ApiAdapter {

	public Charge() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment2/migu/senior/charge");
	}
	
	//1.�������µ�
	@Test 
	@Ignore
	public void test01() throws IOException, EncoderException {
		Charge charge=new Charge();
		
		charge.setOrderId(DataUtils.getOrderId(charge.getPartner()));
		//����payInfo����
		JSONObject payInfJson=new JSONObject();
		payInfJson.put("orderId", charge.getOrderId());
		payInfJson.put("price", "500");
		payInfJson.put("InterfaceType", "listen");
		payInfJson.put("count", "5");
		payInfJson.put("goodsName", "");
		payInfJson.put("BizCode", "600987040019144861");
		payInfJson.put("MonLength", "1");
		payInfJson.put("ExpansionParam", "");
		//���payInfo
		JSONArray payInfo=new JSONArray();
		payInfo.add(payInfJson);
		
		//���data����
		charge.setData(new JSONObject());
		charge.getData().put("partner", charge.getPartner());
		charge.getData().put("time", DataUtils.getTime());
		charge.getData().put("transactionId", charge.getOrderId());
		charge.getData().put("totalPrice", "500");
		charge.getData().put("DID", "1128050");
		charge.getData().put("type", "WAP");
		charge.getData().put("notifyUrl", "http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do");
		charge.getData().put("passId", "405535601515956602");
		charge.getData().put("MSISDN", "15928791968");
		charge.getData().put("uid", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		charge.getData().put("MemberType", "0");
		charge.getData().put("productId", "014");
		charge.getData().put("AccessPlatformID", "002002A");
		charge.getData().put("AccessMode", "2");
		charge.getData().put("payMethod", "30");
		charge.getData().put("bankId", "WX");
		charge.getData().put("payInfo", payInfo);
		
		DataUtils.sendRequest(charge.getUrl(), charge.getRequest());
	}
	
	//2.�µ���������ר��
	@Test
	@Ignore
	public void test02() throws IOException, EncoderException {
		Charge charge=new Charge();
		
		charge.setOrderId(DataUtils.getOrderId(charge.getPartner()));
		//����payInfo����
		JSONObject payInfJson=new JSONObject();
		payInfJson.put("orderId", charge.getOrderId());
		payInfJson.put("price", "100");
		payInfJson.put("InterfaceType", "listen");
		payInfJson.put("count", "1");
		payInfJson.put("goodsName", "");
		payInfJson.put("BizCode", "600987040019144861");
		payInfJson.put("MonLength", "1");
		payInfJson.put("ExpansionParam", "");
		//���payInfo
		JSONArray payInfo=new JSONArray();
		payInfo.add(payInfJson);
		charge.setData(new JSONObject());
		charge.getData().put("payInfo", payInfo);
		
		//���data����
		
		String data = "{\"partner\":\"1000014\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+charge.getOrderId()+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"50\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"0\",\"appleProductId\":\"\","
				+ "\"memberFlag\":\"0\",\"payInfo\":[{\"orderId\":\""+charge.getOrderId()+"\","
				+ "\"price\":\"50\",\"InterfaceType\":\"order\",\"count\":\"5\","
				+ "\"goodsName\":\"�״ι�������ר���µ�\",\"BizCode\":\"600987040014706681\","
				+ "\"ContentID\":\"600987040014706681\",\"CopyRightID\":\"600504080015\","
				+ "\"terminal\":\"Android\",\"MonLength\":\"\",\"ExpansionParam\":\"\","
				+ "\"saleMode\":\"1\"}]"+"}";
		JSONObject parseObject = JSON.parseObject(data);
		charge.setData(parseObject);
		charge.getData().put("type", "WAP");
		
		DataUtils.sendRequest(charge.getUrl(), charge.getRequest());
	}
	
	//3.�µ���������ר��ʹ�õֿ�
	@Test
	@Ignore
	public void test03() throws IOException, EncoderException {
		Charge charge=new Charge();
		
		charge.setOrderId(DataUtils.getOrderId(charge.getPartner()));
		//����payInfo����
		JSONObject payInfJson=new JSONObject();
		payInfJson.put("orderId", charge.getOrderId());
		payInfJson.put("price", "100");
		payInfJson.put("InterfaceType", "listen");
		payInfJson.put("count", "1");
		payInfJson.put("goodsName", "");
		payInfJson.put("BizCode", "600987040019144861");
		payInfJson.put("MonLength", "1");
		payInfJson.put("ExpansionParam", "");
		//���payInfo
		JSONArray payInfo=new JSONArray();
		payInfo.add(payInfJson);
		charge.setData(new JSONObject());
		charge.getData().put("payInfo", payInfo);
		
		//���data����
		
		String data = "{\"partner\":\"1000014\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+charge.getOrderId()+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"10\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"0\",\"appleProductId\":\"\","
				+ "\"memberFlag\":\"0\",\"payInfo\":[{\"orderId\":\""+charge.getOrderId()+"\","
				+ "\"price\":\"10\",\"InterfaceType\":\"order\",\"count\":\"1\","
				+ "\"goodsName\":\"��������ר��ʹ�õֿ�\",\"BizCode\":\"600987040014706681\","
				+ "\"ContentID\":\"600987040014706681\",\"CopyRightID\":\"600504080015\","
				+ "\"terminal\":\"Android\",\"MonLength\":\"\",\"ExpansionParam\":\"\","
				+ "\"saleMode\":\"1\"}]"
				+ ",\"cardPayInfo\":[{\"cardPayPrice\":\"3\","
				+ "\"cardPayType\":\"49\"}]}";
		JSONObject parseObject = JSON.parseObject(data);
		charge.setData(parseObject);
		charge.getData().put("type", "WAP");
		
		DataUtils.sendRequest(charge.getUrl(), charge.getRequest());
	}

	//4.��ҳ�µ� ʹ�û���֧���µ�
	@Test
	@Ignore
	public void test04() throws IOException, EncoderException {
		Charge charge=new Charge();
		
		charge.setOrderId(DataUtils.getOrderId(charge.getPartner()));
		//����payInfo����
		JSONObject payInfJson=new JSONObject();
		payInfJson.put("orderId", charge.getOrderId());
		payInfJson.put("price", "500");

		payInfJson.put("InterfaceType", "listen");//thmon����
		payInfJson.put("count", "5");
		payInfJson.put("goodsName", "");
		payInfJson.put("BizCode", "600987040019144861");
		payInfJson.put("MonLength", "1");
		payInfJson.put("ExpansionParam", "");
		//���payInfo
		JSONArray payInfo=new JSONArray();
		payInfo.add(payInfJson);
		
		//���data����
		charge.setData(new JSONObject());
		charge.getData().put("partner", charge.getPartner());
		charge.getData().put("time", DataUtils.getTime());
		charge.getData().put("transactionId", charge.getOrderId());
		charge.getData().put("totalPrice", "500");
		charge.getData().put("DID", "1128050");
		charge.getData().put("type", "WAP");
		charge.getData().put("notifyUrl", "http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do");
		charge.getData().put("passId", "405535601515956602");
		charge.getData().put("MSISDN", "15928791968");
		charge.getData().put("uid", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		charge.getData().put("MemberType", "0");
		charge.getData().put("productId", "014");
		charge.getData().put("AccessPlatformID", "002002A");
		charge.getData().put("AccessMode", "2");
		charge.getData().put("payMethod", "30");
		charge.getData().put("bankId", "WX");
		charge.getData().put("isPhonePay", "0");
		charge.getData().put("payInfo", payInfo);
		
		DataUtils.sendRequest(charge.getUrl(), charge.getRequest());
	}

	//5.��ҳ�µ�ʹ�û�Ա����Żݿ��ֿ�
	@Test
	public void test05() throws IOException, EncoderException {
		Charge charge=new Charge();
		
		charge.setOrderId(DataUtils.getOrderId(charge.getPartner()));
		//����payInfo����
		JSONObject payInfJson=new JSONObject();
		payInfJson.put("orderId", charge.getOrderId());
		payInfJson.put("price", "200");
		payInfJson.put("InterfaceType", "listen");
		payInfJson.put("count", "2");
		payInfJson.put("goodsName", "");
		payInfJson.put("BizCode", "600987040019144861");
		payInfJson.put("MonLength", "1");
		payInfJson.put("ExpansionParam", "");
		//���payInfo
		JSONArray payInfo=new JSONArray();
		payInfo.add(payInfJson);
		charge.setData(new JSONObject());
		charge.getData().put("payInfo", payInfo);
		
		//���data����
		String data = "{\"partner\":\"1000014\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+charge.getOrderId()+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"10\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"0\",\"appleProductId\":\"\","
				+ "\"memberFlag\":\"0\",\"payInfo\":[{\"orderId\":\""+charge.getOrderId()+"\","
				+ "\"price\":\"10\",\"InterfaceType\":\"order\",\"count\":\"1\","
				+ "\"goodsName\":\"��������ר��ʹ�õֿ�\",\"BizCode\":\"600987040014706681\","
				+ "\"ContentID\":\"600987040014706681\",\"CopyRightID\":\"600504080015\","
				+ "\"terminal\":\"Android\",\"MonLength\":\"\",\"ExpansionParam\":\"\","
				+ "\"saleMode\":\"1\"}]"
				+ ",\"cardPayInfo\":[{\"cardPayPrice\":\"1\","
				+ "\"cardPayType\":\"50\"}]}";
		JSONObject parseObject = JSON.parseObject(data);
		charge.setData(parseObject);
		charge.getData().put("type", "WAP");
		
		DataUtils.sendRequest(charge.getUrl(), charge.getRequest());
	}
}
