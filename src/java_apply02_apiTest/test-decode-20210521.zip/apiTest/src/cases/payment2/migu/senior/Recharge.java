package cases.payment2.migu.senior;
/**
 * �乾�ҳ�ֵҳ��ӿ�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cases.payment2.migu.senior.Recharge;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class Recharge extends ApiAdapter {

	public Recharge() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8178/payment2/migu/coin/recharge");
		String orderId=DataUtils.getOrderId(this.getPartner());
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"transactionId\":\""+orderId+"\","
				+ "\"totalPrice\":1,\"type\":\"WEB\","
				+ "\"returnUrl\":\"http://music.migu.cn/v2/async/payment/recharge_back\","
				+ "\"notifyUrl\":\"http://10.25.136.13:8080/music-migu-web/migumusic/payment/notification\","
				+ "\"passId\":\"383461296272569892\",\"uid\":\"d125c6e8-2079-4b81-bd91-9f337eec30ab\","
				+ "\"token\":\"STnid000001157475465161620Lz2bjWdx8Ro5rCckjW3j04NG4eRRaL\","
				+ "\"productId\":\"023\",\"AccessPlatformID\":\"001002A\","
				+ "\"AccessMode\":\"1\",\"partner\":\"1000014\","
				+ "\"time\":\""+DataUtils.getTime()+"\",\"signType\":\"1\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		Recharge charge=new Recharge();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
