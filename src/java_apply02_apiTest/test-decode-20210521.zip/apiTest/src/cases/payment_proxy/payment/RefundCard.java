package cases.payment_proxy.payment;
/**
 * ���˿�
 */
import java.io.IOException;
import org.apache.commons.codec.EncoderException;
import org.junit.Test;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils; 

public class RefundCard extends ApiAdapter {
	public RefundCard() {
		//���ԣ�10.25.193.16:18800
		//ȫ���ԣ�10.25.245.181:18800
		this.setUrl("http://10.25.193.16:18800/payment-proxy/payment/refundCard");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		this.setOrderId(DataUtils.getOrderId(this.getPartner()));
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("partner", this.getPartner());
		jsonObject.put("tradeId", "100001420210422173948777");
		jsonObject.put("cash", "603");
		jsonObject.put("reason", "��������ר���ֿۿ��˿�");
		jsonObject.put("tradeCancelFlag", "F");
		
		
		this.setData(jsonObject);
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	@Test
	public void test01() throws IOException, EncoderException {
		RefundCard getAccountList=new RefundCard();
		DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getRequest());
	}
	


}
