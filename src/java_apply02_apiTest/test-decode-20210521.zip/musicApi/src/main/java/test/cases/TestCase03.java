package test.cases;

import java.io.IOException;
import javax.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import test.App;
import test.mapper.MusicInfoMapper;
import test.mapper.TempMapper;
import test.pojo.MusicInfo;
import test.utils.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestCase03 {
	@Resource
	private TempMapper tempMapper;
	@Resource
	private MusicInfoMapper musicInfoMapper;
	
	/**
	 * 获取 歌单id、歌单名称、歌曲信息
	 * @throws IOException 
	 */
	@Test
	public void test01() throws IOException {
		//1.查歌单id列表
		String url1 = "https://open.migu.cn:98/sportMusic/1.0/rest/musicSheet/query?evident";
		String request1 = "{\"typeId\":1}";
		String authorization1="OEPAUTH chCode=\"014A106\",smartDeviceId=\"11c8478c000068\"";
		String resp1 = RequestUtils.sendRequest(url1, request1, authorization1);
		System.out.println(resp1);
		JSONArray jsonArray = JSON.parseObject(resp1).getJSONArray("musicSheetInfos");
		//System.out.println(jsonArray);
		for (int i = 0; i < jsonArray.size(); i++) {
			//2.获取歌单id和歌单名称
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String musicSheetId = jsonObject.getString("musicSheetId");
			String title = jsonObject.getString("title");
			System.out.println(musicSheetId+"-->"+title);
			
			//3.通过歌单id查询歌单下面的歌曲
			String url2 = "http://218.200.227.123:9921/sportMusic/1.0/rest/musicSheet/music/query?evident";
			String request2 = "{\"musicSheetId\":"+musicSheetId+",\"startNum\":1,\"endNum\":50}";
			String authorization2="OEPAUTH chCode=\"014A106\",smartDeviceId=\"11c8478c000068\"";
			String resp2 = RequestUtils.sendRequest(url2, request2, authorization2);
			System.out.println(resp2);
			JSONArray musicInfosArray = JSON.parseObject(resp2).getJSONArray("musicInfos");
			for (int j = 0; j < musicInfosArray.size(); j++) {
				MusicInfo musicInfo = musicInfosArray.getObject(j, MusicInfo.class);
				System.out.println(musicInfo);
				//4.歌单id、歌单名称、歌曲id入库
				tempMapper.insMusicSheet(musicSheetId, title, musicInfo.getMusicId());
				//5.歌曲信息入库
				musicInfoMapper.insMusicInfo(musicInfo);
			}
		}
	}
}
