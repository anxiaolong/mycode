package test.cases;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.App;
import test.mapper.TempMapper;
import test.pojo.MusicInfo;
import test.utils.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestCase05 {
	@Resource
	private TempMapper tempMapper;
	
	@Test
	public void test01() throws IOException, InterruptedException {
		
		List<String> selAllSongId = tempMapper.selAllSongId();
		System.out.println(selAllSongId.size());
		
		//1.多线程配置
		CountDownLatch latch = new CountDownLatch(selAllSongId.size());
		ExecutorService fixedThreadPool = Executors.newFixedThreadPool(20);
		
		for (String songid : selAllSongId) {
			fixedThreadPool.execute(new Runnable() {
				@Override
				public void run() {
					System.out.println(Thread.currentThread().getName());
					try {
						String url2 = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
						String request2 = "{\"musicId\":\""+songid+"\",\"pageSize\":\"S\"}";
						String authorization2="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
						String resp2 = RequestUtils.sendRequest(url2, request2, authorization2);
						System.out.println(resp2);
						JSONObject parseObject = JSON.parseObject(resp2);
						MusicInfo musicInfo = parseObject.getObject("musicInfo", MusicInfo.class);
						if (musicInfo!=null) {
							tempMapper.updAuditionsFlag(musicInfo.getAuditionsFlag(), songid);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					latch.countDown();
				}
			});
		}
		latch.await();
	}

}
