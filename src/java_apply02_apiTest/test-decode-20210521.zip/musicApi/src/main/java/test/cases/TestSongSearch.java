package test.cases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import test.App;
import test.mapper.MusicInfoMapper;
import test.mapper.SongMapper;
import test.mapper.VoiceBoxSearchSongMapper;
import test.pojo.MusicInfo;
import test.pojo.Song;
import test.pojo.VoiceBoxSearchSong;
import test.utils.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestSongSearch {
	@Resource
	private MusicInfoMapper musicInfoMapper;
	@Resource
	private SongMapper songMapper;
	@Resource
	private VoiceBoxSearchSongMapper voiceBoxSearchSongMapper;

	@Test
	@Disabled
	@DisplayName("解析搜索结果")
	public void parseResult() {
		List<Song> allSongs = songMapper.selAllSongs();
		for (Song song : allSongs) {
			JSONObject resp = JSON.parseObject(song.getResult());
			song.setResCode(resp.getString("resCode"));
			song.setResMsg(resp.getString("resMsg"));
			System.out.println(song);
			songMapper.upd(song);
			
			JSONObject mJsonObject = (JSONObject) resp.get("musicInfo");
			if (mJsonObject!=null) {
				MusicInfo musicInfo = new MusicInfo();
				musicInfo.setMusicId(mJsonObject.getString("musicId"));
				musicInfo.setMusicName(mJsonObject.getString("musicName"));
				musicInfo.setSingerName(mJsonObject.getString("singerName"));
				musicInfo.setAlbumNames(mJsonObject.getString("albumNames"));
				musicInfo.setSongAuthorName(mJsonObject.getString("songAuthorName"));
				musicInfo.setLyricAuthorName(mJsonObject.getString("lyricAuthorName"));
				musicInfo.setLength(mJsonObject.getString("length"));
				musicInfo.setLanguage(mJsonObject.getString("language"));
				musicInfo.setPicUrl(mJsonObject.getString("picUrl"));
				musicInfo.setLrcUrl(mJsonObject.getString("lrcUrl"));
				musicInfo.setIsCollection(mJsonObject.getString("isCollection"));
				musicInfo.setIsCpAuth(mJsonObject.getString("isCpAuth"));
				musicInfo.setAuditionsFlag(mJsonObject.getString("auditionsFlag"));
				System.out.println(musicInfo);
				musicInfoMapper.insMusicInfo(musicInfo);
			}
		}
	}
	
	@Test
	@Disabled
	@DisplayName("歌曲详情查询")
	public void testSong1() throws IOException {
		List<Song> list = songMapper.selAllSongs();
		//List<String> results = new ArrayList<String>();
		//1.音源不存在60069100805
		for (Song song : list) {
			if (song.getResult()==null||song.getResult().equals("")) {
				String url = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
				String request = "{\"musicId\":\""+song.getId()+"\",\"pageSize\":\"S\"}";
				String authorization="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
				String resp = null;
				try {
					resp = RequestUtils.sendRequest(url, request,authorization);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String result=url+"-->"+request+"-->"+resp;
				System.out.println(result);
				song.setResult(resp);
				songMapper.upd(song);
			}
		}
	}
	
	@Test
	@Disabled
	@DisplayName("语音搜歌")
	public void voiceBoxSearchSong() throws IOException {
		List<VoiceBoxSearchSong> list = voiceBoxSearchSongMapper.selDJ();
		for (VoiceBoxSearchSong vbss : list) {
			//String singerName = vbss.getArtistName();
			String musicName = vbss.getSongName()
					.substring(0, vbss.getSongName().indexOf("("));
			System.out.println(musicName);
			String url = "https://open.migu.cn:98/sportMusic/rest/search/voiceBoxSearchSong?evident";
			String request = "{\"text\":\""+musicName+"\","
					+ "\"searchType\":\"4\","
					+ "\"searchRange\":{\"singerName\":[\""+""+"\"],"
					+ "\"songName\":[\""+musicName+"\"]}}";
			String authorization="OEPAUTH chCode=\"014D08K\",smartDeviceId=\"c0:84:7d:9f:89:b8\",secretToken=\"d62d200cf7f39b4da0ea033bf32048dd\"";
			
			String resp = RequestUtils.sendRequest(url, request, authorization);
			vbss.setResult(resp);
			voiceBoxSearchSongMapper.insVoiceBoxSearchSong(vbss);
			System.out.println(resp);
		}
	}
	
	@Test
	@Disabled
	@DisplayName("找到匹配歌曲")
	public void matchSong() throws IOException {
		Map<Integer, JSONObject> map = new HashMap<Integer, JSONObject>();
		List<VoiceBoxSearchSong> list = voiceBoxSearchSongMapper.selDJ();
		System.out.println(list.size());
		for (VoiceBoxSearchSong vbss : list) {
			String result2 = vbss.getResult();
			//System.out.println(result2);
			JSONArray resultArray = (JSONArray) ((JSONObject)((JSONObject)JSON.parseObject(result2)
					.get("searchVoiceBox")).get("data")).get("result");
			System.out.println("歌曲数量："+resultArray.size());
			for (int i = 0; i < resultArray.size(); i++) {
				JSONObject songJson = (JSONObject) resultArray.get(i);
				//System.out.println(songJson);
				//1.找到歌曲名
				String songName = (String) songJson.get("name");
				System.out.println("歌曲名："+songName);
				//2.找到歌手名
				boolean isMatchSinger=false;
				JSONArray singerArray = (JSONArray) songJson.get("singers");
				for (int j = 0; j < singerArray.size(); j++) {
					JSONObject singerJson = (JSONObject) singerArray.get(j);
					String singerName = (String) singerJson.get("name");
					System.out.println("歌手名："+singerName);
					if (vbss.getArtistName().contains(singerName)) {
						isMatchSinger=true;
					}
				}
				//3.找到专辑名
				JSONArray albumsArray = (JSONArray) songJson.get("albums");
				for (int j = 0; j < albumsArray.size(); j++) {
					JSONObject albumJson = (JSONObject) albumsArray.get(j);
					String albumName = (String) albumJson.get("name");
					System.out.println("专辑名："+albumName);
				}
				System.out.println("-------------------------------");
				//判断歌曲中是否匹配搜索关键词
				if (vbss.getSongName().equals(songName)&&isMatchSinger) {
					map.put(vbss.getId(), songJson);
				}
			}
		}
		System.out.println(map.size());
		List<String> cpridList = new ArrayList<String>();
		Set<Integer> keySet = map.keySet();
		for (Integer integer : keySet) {
			JSONArray fullSongsaArray = (JSONArray) map.get(integer).get("fullSongs");
			String copyrightId = (String) ((JSONObject)fullSongsaArray.get(0)).get("copyrightId");
			System.out.println(copyrightId);
			cpridList.add(copyrightId);
			
			//发送请求查询歌曲
			String url = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
			String request = "{\"musicId\":\""+copyrightId+"\",\"pageSize\":\"S\"}";
			String authorization="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
			String resp = RequestUtils.sendRequest(url, request,authorization);
			System.out.println(resp);
			JSONObject mJsonObject = (JSONObject) JSON.parseObject(resp).get("musicInfo");
			if (mJsonObject!=null) {
				MusicInfo musicInfo = new MusicInfo();
				musicInfo.setMusicId(mJsonObject.getString("musicId"));
				musicInfo.setMusicName(mJsonObject.getString("musicName"));
				musicInfo.setSingerName(mJsonObject.getString("singerName"));
				musicInfo.setAlbumNames(mJsonObject.getString("albumNames"));
				musicInfo.setSongAuthorName(mJsonObject.getString("songAuthorName"));
				musicInfo.setLyricAuthorName(mJsonObject.getString("lyricAuthorName"));
				musicInfo.setLength(mJsonObject.getString("length"));
				musicInfo.setLanguage(mJsonObject.getString("language"));
				musicInfo.setPicUrl(mJsonObject.getString("picUrl"));
				musicInfo.setLrcUrl(mJsonObject.getString("lrcUrl"));
				musicInfo.setIsCollection(mJsonObject.getString("isCollection"));
				musicInfo.setIsCpAuth(mJsonObject.getString("isCpAuth"));
				musicInfo.setAuditionsFlag(mJsonObject.getString("auditionsFlag"));
				musicInfo.setVid(integer);
				System.out.println(musicInfo);
				musicInfoMapper.insMusicInfo(musicInfo);
			}else {
				MusicInfo musicInfo = new MusicInfo();
				musicInfo.setVid(integer);
				musicInfo.setMusicId(copyrightId);
				musicInfoMapper.insMusicInfo(musicInfo);
			}
		}
		System.out.println(cpridList.size());
	}
}
