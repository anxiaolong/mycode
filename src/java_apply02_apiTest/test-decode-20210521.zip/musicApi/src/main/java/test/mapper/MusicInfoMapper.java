package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import test.pojo.MusicInfo;

public interface MusicInfoMapper {
	@Insert("insert into musicinfo "
			+ "(musicId,musicName,singerName,albumNames,songAuthorName,"
			+ "lyricAuthorName,length,language,picUrl,lrcUrl,isCollection,"
			+ "isCpAuth,auditionsFlag,vid) VALUE "
			+ "(#{musicId},#{musicName},#{singerName},#{albumNames},#{songAuthorName},#{lyricAuthorName},#{length},"
			+ "#{language},#{picUrl},#{lrcUrl},#{isCollection},#{isCpAuth},#{auditionsFlag},#{vid})")
	int insMusicInfo(MusicInfo musicInfo);
	
	@Select("SELECT * FROM musicinfo")
	List<MusicInfo> selAllMusicInfo();
}
