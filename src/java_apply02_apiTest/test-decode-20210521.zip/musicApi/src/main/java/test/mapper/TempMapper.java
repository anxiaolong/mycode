package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface TempMapper {
	@Select("SELECT songId FROM temp01")
	List<String> selAllSongId();
	
	@Update("update temp01 set auditionsFlag=#{auditionsFlag} where songId=#{songid}")
	int updAuditionsFlag(@Param("auditionsFlag") String auditionsFlag,
			@Param("songid") String songid);
	
	@Insert("INSERT INTO temp02 (musicSheetId,title,musicId) VALUE"
			+ " (#{musicSheetId},#{title},#{musicId})")
	int insMusicSheet(
			@Param("musicSheetId") String musicSheetId,
			@Param("title") String title,
			@Param("musicId") String musicId
			);
	
	@Select("SELECT text FROM music_temp")
	List<String> selAllText();
	
	@Select("SELECT contentFilter FROM music_temp")
	List<String> selAllContentFilter();
	
	@Update("UPDATE music_temp set resp=#{resp},req=#{req} WHERE text=#{text} AND contentFilter=#{contentFilter};")
	int updRespByTextAndContentFilter(
			@Param("text") String text,
			@Param("contentFilter") String contentFilter,
			@Param("resp") String resp,
			@Param("req") String req
			);
}
