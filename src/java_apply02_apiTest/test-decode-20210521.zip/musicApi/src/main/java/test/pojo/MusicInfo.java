package test.pojo;

import lombok.Data;

@Data
public class MusicInfo {
	private String musicId;
	private String musicName;
	private String singerName;
	private String albumNames;
	private String songAuthorName;
	private String lyricAuthorName;
	private String length;
	private String language;
	private String picUrl;
	private String lrcUrl;
	private String isCollection;
	private String isCpAuth;
	private String auditionsFlag;
	private int vid;
}
