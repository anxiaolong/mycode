package test.pojo;

import lombok.Data;

@Data
public class VoiceBoxSearchSong {
	private int id;
	private String artistName;
	private String songName;
	private String albumName;
	private String result;	
}
