package cases.orderPayRest.order.third;
/**
 * �������һ��ӿ�
 */

import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class RankExchange extends ApiAdapter {

	public RankExchange() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8178/orderPayRest/order/third/rankExchange");
		String orderId=DataUtils.getOrderId(this.getPartner());
		JSONObject parseObject = JSON.parseObject("{"
				+ "\"partner\":\"1000014\","
				+ "\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+orderId+"\","
				+ "\"contentID\":\"1111\","
				+ "\"copyRightID\":\"333333333\","
				+ "\"orderId\":\""+orderId+"\",\"uid\":\"d125c6e8-2079-4b81-bd91-9f337eec30ab\","
				+ "\"msisdn\":\"18210030020\",\"productId\":\"028\",\"totalPrice\":\"1\","
				+ "\"accessPlatformID\":\"22222\",\"did\":\"1128050\",\"interfaceType\":\"feeRank\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		RankExchange charge=new RankExchange();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getFinalRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
