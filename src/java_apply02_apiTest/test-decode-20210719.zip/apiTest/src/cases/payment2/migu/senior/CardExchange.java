package cases.payment2.migu.senior;


import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

/**
 * ���ֿ��һ����ֲ�Ʒ�ӿ�
 */
public class CardExchange extends ApiAdapter {


	@Test
	public void test_Charge() throws IOException, EncoderException {
		CardExchange charge=new CardExchange();
		charge.setIsUrlEcode("false");
		charge.setPartner("1000014");
		charge.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		charge.setUrl("http://10.25.193.30:8170/payment2/migu/senior/cardExchange");
		String orderId=DataUtils.getOrderId(charge.getPartner());
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"partner\":\"1000014\","
				+ "\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+orderId+"\","
				+ "\"orderId\":\""+orderId+"\","
				+ "\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"msisdn\":\"15928791968\",\"cardSN\":\"\","
				+ "\"accessPlatformID\":\"01478AT\","
				+ "\"showCodeGiveId\":\"2104138752\","
				+ "\"cardKey\":\"\",\"did\":\"1128050\",\"purchaseWay\":\"48\"}");
		charge.setData(parseObject);
		DataUtils.sendRequest(charge.getUrl(), charge.getFinalRequest());
	}

}
