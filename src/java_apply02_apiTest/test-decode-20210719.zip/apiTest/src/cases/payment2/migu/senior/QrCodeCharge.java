package cases.payment2.migu.senior;
/**
 * ��ά��֧������
 */

import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class QrCodeCharge extends ApiAdapter {

	public QrCodeCharge() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8178/payment2/migu/senior/qrCodeCharge");
		String orderId=DataUtils.getOrderId(this.getPartner());
		JSONObject parseObject = JSON.parseObject("{\"partner\":\"1000014\","
				+ "\"time\":\""+DataUtils.getTime()+"\","
				+ "\"payInfo\":[{\"orderId\":\""+orderId+"\","
				+ "\"price\":\"5\",\"count\":\"1\",\"goodsName\":\"�׽��Ա-֧������������\",\"MonLength\":\"1\","
				+ "\"BizCode\":\"698039020100000129\",\"InterfaceType\":\"thmon\"}],"
				+ "\"transactionId\":\""+orderId+"\","
				+ "\"totalPrice\":\"5\",\"payMethod\":\"1\","
				+ "\"bankCode\":\"AP\",\"notifyUrl\":\"http://tv.ising.migu.cn//pay/callback\",\"passId\":\"383461296272569892\","
				+ "\"uid\":\"d125c6e8-2079-4b81-bd91-9f337eec30ab\",\"productId\":\"008\",\"MSISDN\":\"18210030020\",\"AccessMode\":\"3\","
				+ "\"AccessPlatformID\":\"014BD44\",\"MemberType\":\"1\",\"DID\":\"1128040\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		QrCodeCharge charge=new QrCodeCharge();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getFinalRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
