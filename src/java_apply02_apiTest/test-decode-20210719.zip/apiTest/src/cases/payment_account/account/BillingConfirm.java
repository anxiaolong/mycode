package cases.payment_account.account;

import java.io.IOException;
import org.apache.commons.codec.EncoderException;
import org.junit.Ignore;
import org.testng.annotations.Test;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

/**
 * ���Ʒ�ȷ�Ͻӿ�
 */
public class BillingConfirm extends ApiAdapter {
	public BillingConfirm() {
		this.setUrl("http://"+this.getTestip()+":18101/payment-account/account/billingConfirm");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType","MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
	
	/**
	 * 1.����ר���ֿۼƷ�
	 */
	@Test
	@Ignore
	public void test_GetAccountList() throws IOException, EncoderException {
		BillingConfirm billingConfirm=new BillingConfirm();
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"amount\":\"10\","
				+ "\"activityId\":\"1676\","
				+ "\"goodcount\":\"1\","
				+ "\"busiType\":\"49\","
				+ "\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"copyRightId\":\"600504080015\","
				+ "\"channelCode\":\"TEST000\","
				+ "\"cardPrice\":\"1\","
				+ "\"bizCode\":\"600987040014706681\","
				+ "\"orderId\":\"100001420210422135928482\","
				+ "\"contentId\":\"600987040014706681\","
				+ "\"deviceId\":\"7654321\""
				+ "}");
		
		billingConfirm.setData(parseObject);
		DataUtils.sendRequest(billingConfirm.getUrl(), billingConfirm.getFinalRequest());
	}
	
	/**
	 * 2.��Ա������ֿۼƷ�
	 */
	@Test
	public void test_02() throws IOException, EncoderException {
		BillingConfirm billingConfirm=new BillingConfirm();
		JSONObject parseObject = JSON.parseObject("{"
				+ "\"amount\":\"1000\","
				+ "\"activityId\":\"\","
				+ "\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"busiType\":\"50\","
				+ "\"copyRightId\":\"600504080015\","
				+ "\"accountId\":\"15928791968\","
				+ "\"channelCode\":\"0146921\","
				+ "\"cardPrice\":\"600\","
				+ "\"periodType\":\"2\","
				+ "\"monthLength\":\"1\","
				+ "\"bizCode\":\"600927020000005010\","
				+ "\"contentId\":\"600987040014706681\","
				+ "\"deviceId\":\"1128050\","
				+ "\"orderId\":\"100001420210524143258960\"}");
		
		billingConfirm.setData(parseObject);
		DataUtils.sendRequest(billingConfirm.getUrl(), billingConfirm.getFinalRequest());
	}

}
