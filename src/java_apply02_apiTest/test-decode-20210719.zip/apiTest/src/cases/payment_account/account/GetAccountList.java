package cases.payment_account.account;
/**
 * ��ȡ֧������Ϣ�б��ӿ�
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 

public class GetAccountList extends ApiAdapter {
	public GetAccountList() {
		this.setUrl("http://10.25.193.16:18101/payment-account/account/getAccountList");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		this.setData(new JSONObject());
		this.getData().put("partner","1000014");
		this.getData().put("accountId","15828637397");
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		GetAccountList getAccountList=new GetAccountList();
		assertThat(DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getFinalRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�ɹ�\""));
	}

}
