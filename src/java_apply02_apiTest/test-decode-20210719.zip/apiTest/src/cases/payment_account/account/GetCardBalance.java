package cases.payment_account.account;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 
/**
 * ��ѯ�ҵĿ��ó��������
 * ��ѯ��Ա��������
 */
public class GetCardBalance extends ApiAdapter {
	public GetCardBalance() {
		//ȫ����10.25.245.181
		//����10.25.193.16
		this.setUrl("http://"+this.getTestip()+":18101/payment-account/account/getCardBalance");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		JSONObject parseObject = JSON.parseObject("{"
				+ "\"partner\": \""+this.getPartner()+"\","
				+ "\"UID\": \"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"MSISDN\": \"15928791968\","
				+ "\"cardType\": \"50\"}");
		this.setData(parseObject);
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		GetCardBalance getAccountList=new GetCardBalance();
		assertThat(DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getFinalRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�ɹ�\""));
	}

}
