package cases.payment_account.account;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import java.io.IOException;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;
/**
 * IOS���ֿ�������ϸ��ѯ�ӿ�
 */
public class GetDCConsumeList extends ApiAdapter {
	public GetDCConsumeList() {
		this.setUrl("http://10.25.193.16:18101/payment-account/account/getDCConsumeList");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		this.setData(new JSONObject());
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType","MD5");
		newReq.put("partner",this.getPartner());
		return newReq.toString();
	}
	
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		GetDCConsumeList getDCConsumeList=new GetDCConsumeList();
		getDCConsumeList.getData().put("MSISDN","15928791968");
		getDCConsumeList.getData().put("UID","a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		getDCConsumeList.getData().put("terminal","IOS");
		getDCConsumeList.getData().put("operType","0");
		getDCConsumeList.getData().put("cardType","40");
		getDCConsumeList.getData().put("pageNum","1");
		getDCConsumeList.getData().put("pageCount","50");
		DataUtils.sendRequest(getDCConsumeList.getUrl(), getDCConsumeList.getFinalRequest());
	}

}
