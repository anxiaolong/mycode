package cases.payment_proxy.payment;
/**
 * �������ݿ�֧��
 */
import java.io.IOException;
import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils; 

public class PayDcOrder extends ApiAdapter {
	public PayDcOrder() {
		//���ԣ�10.25.193.16:18800
		//ȫ���ԣ�10.25.245.181:18800
		this.setUrl("http://10.25.193.16:18800/payment-proxy/payment/payDcOrder");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		this.setOrderId(DataUtils.getOrderId(this.getPartner()));
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	//1.ʹ��һ�ſ��ֿ�
	@Test
	@Ignore
	public void test01() throws IOException, EncoderException {
		PayDcOrder pdo=new PayDcOrder();
		
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"partner\":\""+pdo.getPartner()+"\",\"channelId\":\"1000004\","
				+ "\"tradeId\":\""+pdo.getOrderId()+"\",\"tradeFee\":\"600\","
				+ "\"accountPhone\":\"15928791968\","
				+ "\"accountId\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"tradeDesc\":\"��������\",\"terminal\":\"IOS\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"payType\":\"101\",\"orderInfo\":{\"orderId\":\""+pdo.getOrderId()+"\","
				+ "\"orderDesc\":\"��������\",\"goodsInfo\":[{\"id\":\"633986Z04000000141\","
				+ "\"price\":\"6\",\"name\":\"ר���ֿ۲���\",\"quantity\":\"3\"}]},"
				+ "\"paymentInfo\":[{\"paidTotalFee\":\"600\",\"paidAccountType\":\"50\",\"cardId\":\"2929\"},"
				+ "]}");
		pdo.setData(parseObject);
		
		DataUtils.sendRequest(pdo.getUrl(), pdo.getFinalRequest());
	}
	
	//2.ʹ�ö��ſ��ֿ�
	@Test
	@Ignore
	public void test02() throws IOException, EncoderException {
		PayDcOrder obj=new PayDcOrder();
		
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"partner\":\""+obj.getPartner()+"\",\"channelId\":\"1000004\","
				+ "\"tradeId\":\""+obj.getOrderId()+"\",\"tradeFee\":\"3\","
				+ "\"accountPhone\":\"15928791968\","
				+ "\"accountId\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"tradeDesc\":\"��������\",\"terminal\":\"IOS\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"payType\":\"101\",\"orderInfo\":{\"orderId\":\""+obj.getOrderId()+"\","
				+ "\"orderDesc\":\"��������\",\"goodsInfo\":[{\"id\":\"633986Z04000000141\","
				+ "\"price\":\"6\",\"name\":\"ר���ֿ۲���\",\"quantity\":\"3\"}]},"
				+ "\"paymentInfo\":[]}");
		obj.setData(parseObject);
		
		obj.getData().getJSONArray("paymentInfo").clear();
		JSONObject parseObject1 = JSON.parseObject
				("{\"paidTotalFee\":\"1\",\"paidAccountType\":\"49\",\"cardId\":\"2773\"}");
		JSONObject parseObject2 = JSON.parseObject
				("{\"paidTotalFee\":\"2\",\"paidAccountType\":\"49\",\"cardId\":\"2774\"}");
		obj.getData().getJSONArray("paymentInfo").add(parseObject1);
		obj.getData().getJSONArray("paymentInfo").add(parseObject2);
		DataUtils.sendRequest(obj.getUrl(), obj.getFinalRequest());
	}
	
	//2.�������ݿ�֧���ֿ�
	@Test
	@Ignore
	public void test03() throws IOException, EncoderException {
		PayDcOrder obj=new PayDcOrder();
		
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"partner\":\""+obj.getPartner()+"\",\"channelId\":\"1000004\","
				+ "\"tradeId\":\""+obj.getOrderId()+"\",\"tradeFee\":\"603\","
				+ "\"accountPhone\":\"15928791968\","
				+ "\"accountId\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"tradeDesc\":\"��������\",\"terminal\":\"IOS\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"payType\":\"101\",\"orderInfo\":{\"orderId\":\""+obj.getOrderId()+"\","
				+ "\"orderDesc\":\"��������\",\"goodsInfo\":[{\"id\":\"633986Z04000000141\","
				+ "\"price\":\"6\",\"name\":\"ר���ֿ۲���\",\"quantity\":\"3\"}]},"
				+ "\"paymentInfo\":[]}");
		obj.setData(parseObject);
		
		obj.getData().getJSONArray("paymentInfo").clear();
		JSONObject parseObject1 = JSON.parseObject
				("{\"paidTotalFee\":\"1\",\"paidAccountType\":\"49\",\"cardId\":\"2773\"}");
		JSONObject parseObject2 = JSON.parseObject
				("{\"paidTotalFee\":\"2\",\"paidAccountType\":\"49\",\"cardId\":\"2774\"}");
		JSONObject parseObject3 = JSON.parseObject
				("{\"paidTotalFee\":\"600\",\"paidAccountType\":\"40\",\"cardId\":\"829\"}");
		obj.getData().getJSONArray("paymentInfo").add(parseObject1);
		obj.getData().getJSONArray("paymentInfo").add(parseObject2);
		obj.getData().getJSONArray("paymentInfo").add(parseObject3);
		DataUtils.sendRequest(obj.getUrl(), obj.getFinalRequest());
	}

}
