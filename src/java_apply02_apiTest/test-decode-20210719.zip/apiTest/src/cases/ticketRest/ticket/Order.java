package cases.ticketRest.ticket;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;
/**
 * �ڲ��ӿ�ֱ���µ���Ʊ
 */
public class Order extends ApiAdapter {
	public Order() {
		//�ڲ��ӿ�ֱ���µ�
		//ticketItemId showItemId projectId��GetTicketProject��ȡ 
		//seatInfoId ��NotifySeatInfo��ȡ
		//vipFlag 0�ǰ׽� 1�׽� 2���Ѱ׽�
		/**
		 * 1."custId\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\
		 * 2."custPhone\":\"15928791968\","
		 * �ƶ��ţ�13541092060 91046574994
		 * 13258369639
		 *11ab19d4-7572-4790-b52b-e5714eacd685
		 */

	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("partner",this.getPartner());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	/**
	 * 1.�ڲ��µ������ݳ���Ʊ
	 * 2.�����ܱ���Ʒ
	 */
	@Test
	@Ignore
	public void test_Order() throws Exception {
		Order order=new Order();
		JSONObject data=JSON.parseObject(
				"{\"orderId\":\"100001420210109191220271\","
				+ "\"orderType\":\"2\","
				+ "\"custId\":\"777-666-555\","
				+ "\"custPhone\":\"12828637397\","
				+ "\"totalPrice\":\"901\","
				+ "\"cardPayPrice\":\"0\","
				+ "\"thirdPrice\":\"900\","
				+ "\"ticketNum\":\"1\","
				+ "\"projectId\":\"121001205\","
				+ "\"showItemId\":\"12100120500\","
				+ "\"ticketItemId\":\"1110\","
				+ "\"receiveType\":\"2\","  //receiveType 6������ 1��ȡ 2���
				+ "\"electronicType\":\"30\","
				+ "\"invoiceFlag\":\"0\","
				+ "\"invoiceInfo\":{\"invoiceType\":\"\",\"invoiceTitle\":\"\","
				+ "\"taxpayerNum\":\"\",\"invoiceObtainMode\":\"\",\"invoiceEmail\":\"\","
				+ "\"invoiceExpressAddress\":\"\",\"invoiceConsignee\":\"\",\"invoicePhone\":\"\"},"
				+ "\"postInfo\":{\"province\":\"�Ĵ�ʡ\",\"city\":\"�ɶ���\",\"country\":\"������\","
				+ "\"detailAddr\":\"������123��\",\"charge\":\"1\",\"receiver\":\"�ֺ�\"," //charge�ʷѳɶ�  1��   ʡ��  3��  ����  5��
				+ "\"phone\":\"13258369639\",\"specialNote\":\"\"},"
				+ "\"ticketList\":[{\"ticketNo\":\"\"}],"
				+ "\"seatInfoId\":\"20210524b954ed40-7963-4655-b99f-5a60fcd2587e\","
				+ "\"channelId\":\"010004D\",\"source\":\"00\",\"vipFlag\":\"0\","
				+ "\"ticketHolders\":[{\"identityNum\":\"NTEwNjAzMTk4MzA1MTY1OTNY\",\"identityName\":\"5b2t5pyX\"}]}");
		
		order.setPartner("1000004");
		order.setKey("HWFI1KTJ2C8VNV9240VWOE923JS092JC");
		order.setData(data);
		order.setUrl("http://"+this.getTestip()+":18800/ticketRest/ticket/order");
		order.getData().put("orderId", DataUtils.getOrderId(order.getPartner()));
		DataUtils.sendRequest(order.getUrl(), order.getFinalRequest());
	}

	// 2.�µ���������룬���Թ�������Ʊ�Զ��һ�
	@Test
	//@Ignore
	public void test_Order02() throws Exception {
		Order order=new Order();
		JSONObject data=JSON.parseObject(
				"{\"orderId\":\"100001420210109191220271\","
				+ "\"orderType\":\"2\","
				+ "\"custId\":\"837f416b-54f8-424f-ba51-7d9dda45b193\","
				+ "\"custPhone\":\"18328480433\","
				+ "\"totalPrice\":\"6\","
				+ "\"cardPayPrice\":\"0\","
				+ "\"thirdPrice\":\"2\","
				+ "\"ticketNum\":\"3\","
				+ "\"projectId\":\"121000941\","
				+ "\"showItemId\":\"12100094100\","
				+ "\"ticketItemId\":\"1121\","
				+ "\"receiveType\":\"6\","  //receiveType 6������ 1��ȡ 2���
				+ "\"electronicType\":\"30\","
				+ "\"invoiceFlag\":\"0\","
				+ "\"invoiceInfo\":{\"invoiceType\":\"\",\"invoiceTitle\":\"\","
				+ "\"taxpayerNum\":\"\",\"invoiceObtainMode\":\"\",\"invoiceEmail\":\"\","
				+ "\"invoiceExpressAddress\":\"\",\"invoiceConsignee\":\"\",\"invoicePhone\":\"\"},"
				+ "\"postInfo\":{\"province\":\"�Ĵ�ʡ\",\"city\":\"�ɶ���\",\"country\":\"������\","
				+ "\"detailAddr\":\"������123��\",\"charge\":\"1\",\"receiver\":\"�ֺ�\"," //charge�ʷѳɶ�  1��   ʡ��  3��  ����  5��
				+ "\"phone\":\"13258369639\",\"specialNote\":\"\"},"
				+ "\"ticketList\":[{\"ticketNo\":\"\"}],"
				+ "\"seatInfoId\":\"202107059f8718e8-85e7-440b-914f-fd7789a089f0\","
				+ "\"channelId\":\"010004D\",\"source\":\"00\",\"vipFlag\":\"0\","
				+ "\"ticketHolders\":[{\"identityNum\":\"NTEwNjAzMTk4MzA1MTY1OTNY\",\"identityName\":\"5b2t5pyX\"}]}");

		order.setPartner("1000004");
		order.setKey("HWFI1KTJ2C8VNV9240VWOE923JS092JC");
		order.setData(data);
		order.setUrl("http://"+this.getAlltestip()+":18800/ticketRest/ticket/order");
		order.getData().put("orderId", DataUtils.getOrderId(order.getPartner()));
		DataUtils.sendRequest(order.getUrl(), order.getFinalRequest());
	}

}
