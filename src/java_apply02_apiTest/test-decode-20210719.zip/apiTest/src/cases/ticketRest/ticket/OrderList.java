package cases.ticketRest.ticket;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

/**
 * �����б���ѯ
 */
public class OrderList extends ApiAdapter {
	public OrderList() {
		this.setUrl("http://"+this.getTestip()+":18701/ticketRest/ticket/orderList");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		this.setData(new JSONObject());
		this.getData().put("orderType", "0");
		this.getData().put("custId", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("custPhone", "15928791968");
		this.getData().put("orderCategory", "2");// 1.��Ʊ 2.�ܱ߲�Ʒ
		this.getData().put("orderStatus", "0");// 0.���У�Ĭ�ϣ� 1.֧���ɹ�
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType", "MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
	
	
	@Test
	public void test_GetTicketProject() throws Exception {
		OrderList getTicketProject=new OrderList();
		DataUtils.sendRequest(getTicketProject.getUrl(), getTicketProject.getFinalRequest());
	}

}
