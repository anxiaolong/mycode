package test.cases.music;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.util.DataUtils;
import test.util.RequestUtils;

import java.io.IOException;

public class MusicCase_20210617 {
    @DataProvider(name = "musicId")
    public Object[] getMusicId(){
        return new Object[]{"6005661HD67","6005663EHE4","69940400044","6996512PLMK"};
    }

    @Test(dataProvider = "musicId")
    public void test_music(String musicId) throws IOException {
        String url = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
        String request = "{\"musicId\":\""+musicId+"\",\"picSize\":\"S\"}";
        String authorization="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
        String resp = RequestUtils.sendRequest(url, request, authorization);
        DataUtils.logToReport(url,request,authorization,resp);
    }

    @Test
    public void test_radio() throws IOException {
        String url = "https://open.migu.cn:98/sportMusic/1.0/rest/migu/app/radio/get?evident";
        String request = "";
        String authorization="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
        String resp = RequestUtils.sendRequest(url, request, authorization);
        DataUtils.logToReport(url,request,authorization,resp);
    }
}
