package test.cases.music;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.util.DataUtils;
import test.util.RequestUtils;

import java.io.IOException;
import java.util.Objects;

public class MusicCase_20210712 {
    @DataProvider(name = "smartDeviceId_keywords")
    public Object[] getMusicId(){
        Object[] testData =
                new Object[]{"uid","appID","msisdn","pubKey",
                        "netMode","packageName","version","chCode",
                        "imei","sim","os","brand","model","mac"};
        return testData;
    }

    @Test(dataProvider = "smartDeviceId_keywords")
    public void test_smartDeviceId_keywords_exception(String keyword) throws IOException {
        String url = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
        String request = "{\"musicId\":\""+"60084600079"+"\",\"picSize\":\"S\"}";
        String authorization="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001"+keyword+"\"";
        String resp = RequestUtils.sendRequest(url, request, authorization);
        DataUtils.logToReport(url,request,authorization,resp);
        Assert.assertTrue(resp.contains("\"resCode\":\"999029\""),
                "有问题，响应不是smartDeviceId未导入对应的状态码999029");
    }

}
