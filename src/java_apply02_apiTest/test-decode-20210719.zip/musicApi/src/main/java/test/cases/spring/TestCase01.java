package test.cases.spring;

import java.io.IOException;

import javax.annotation.Resource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import test.App;
import test.mapper.MusicInfoMapper;
import test.pojo.MusicInfo;
import test.util.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestCase01 {
	@Resource
	private MusicInfoMapper musicInfoMapper;
	
	@Test
	public void test01() throws IOException {
		//1.请求所有歌单
		String url = "https://open.migu.cn:98/sportMusic/1.0/rest/musicSheet/query?evident";
		String request = "{\"typeId\":2}";
		String authorization = "OEPAUTH chCode=\"014D030\",smartDeviceId=\"11c8478c000068\",secretToken=\"94bd7c82b79b98d0040bf97cc3547888\"";
		String resp = RequestUtils.sendRequest(url, request, authorization);
		//System.out.println(resp);
		
		//2.解析获得歌单id
		JSONObject respJson = JSON.parseObject(resp);
		JSONArray jsonArray = respJson.getJSONArray("musicSheetInfos");
		for (int i = 0; i < jsonArray.size(); i++) {
			String musicSheetId = jsonArray.getJSONObject(i).getString("musicSheetId");
			String title = jsonArray.getJSONObject(i).getString("title");
			//3.遍历歌单id同时请求歌单中歌曲
			String url1 = "https://open.migu.cn:98/sportMusic/1.0/rest/musicSheet/music/query?evident";
			String request1 = "{\"musicSheetId\":"+musicSheetId+",\"startNum\":1,\"endNum\":50,“picSize”:\"M\"}";
			String authorization1 = "OEPAUTH chCode=\"014D030\",smartDeviceId=\"11c8478c000068\",secretToken=\"94bd7c82b79b98d0040bf97cc3547888\"";
			String resp1 = RequestUtils.sendRequest(url1, request1, authorization1);
			//System.out.println(resp1);
			JSONArray jsonArray2 = JSON.parseObject(resp1).getJSONArray("musicInfos");
			for (int j = 0; j < jsonArray2.size(); j++) {
				MusicInfo musicInfo = jsonArray2.getObject(j, MusicInfo.class);
				//4.判断isCpAuth=0入库
				if (musicInfo.getIsCpAuth().equals("0")) {
					musicInfo.setAlbumNames(musicSheetId);
					musicInfo.setSongAuthorName(title);
					System.out.println(musicInfo);
					musicInfoMapper.insMusicInfo(musicInfo);
				}
			}
		}
	}
}
