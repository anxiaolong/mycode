package test.cases.spring;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import test.App;
import test.mapper.MusicInfoMapper;
import test.mapper.SongIdMapper;
import test.pojo.MusicInfo;
import test.util.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestCase02 {
	@Resource
	private MusicInfoMapper musicInfoMapper;
	@Resource
	private SongIdMapper songIdMapper;
		
	@Test
	@Disabled
	public void test02() throws IOException {
		List<String> allSongId = songIdMapper.getAllSongId();
		System.out.println(allSongId.size());
		for (String songId : allSongId) {
			//System.out.println(songId);
			String url = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
			String request = "{\"musicId\":\""+songId+"\",\"pageSize\":\"S\"}";
			String authorization="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
			String resp1 = RequestUtils.sendRequest(url, request, authorization);
			//System.out.println(resp1);
			JSONObject parseObject = JSON.parseObject(resp1);
			MusicInfo musicInfo = parseObject.getObject("musicInfo", MusicInfo.class);
			System.out.println(musicInfo);
			musicInfoMapper.insMusicInfo(musicInfo);
		}
	}
	
	@Test
	public void test03() throws IOException {
		//1.获取电台下所有歌曲id
		List<String> allSongIdList = new ArrayList<String>();
		
		String url1 = "https://open.migu.cn:98/sportMusic/1.0/rest/migu/app/radio/get?evident";
		String request1 = "{\"typeId\":2}";
		String authorization1="OEPAUTH chCode=\"a39d713b25e95b2b\",smartDeviceId=\"11c8478c000068\"";
		String resp1 = RequestUtils.sendRequest(url1, request1, authorization1);
		JSONArray parseArray = JSON.parseArray(resp1);
		System.out.println("响应对象大小："+parseArray.size());
		
		for (int i = 0; i < parseArray.size(); i++) {
			String columnName = parseArray.getJSONObject(i).getString("columnName");
			System.out.println(columnName);
			JSONArray radiosArray = parseArray.getJSONObject(i).getJSONArray("radios");
			System.out.println("radiosArray大小："+radiosArray.size());
			for (int j = 0; j < radiosArray.size(); j++) {
				JSONObject radioObject = radiosArray.getJSONObject(j);
				JSONArray songIdArray = radioObject.getJSONArray("songIds");
				//System.out.println(songIdArray);
				List<String> jsongIdList = songIdArray.toJavaList(String.class);
				//System.out.println(jsongIdList);
				allSongIdList.addAll(jsongIdList);
			}
		}
		System.out.println("歌曲总数量"+allSongIdList.size());
		//System.out.println(allSongIdList);
		
		//2.获取歌曲详情并入库
		for (int i = 0; i < allSongIdList.size(); i++) {
			String songid = allSongIdList.get(i);
			System.out.println(i+"歌曲id："+songid);
			//songIdMapper.insSongId(songid,null,null,null,null);
			
			String url2 = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
			String request2 = "{\"musicId\":\""+songid+"\",\"pageSize\":\"S\"}";
			String authorization2="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
			String resp2 = RequestUtils.sendRequest(url2, request2, authorization2);
			//System.out.println(resp1);
			JSONObject parseObject = JSON.parseObject(resp2);
			MusicInfo musicInfo = parseObject.getObject("musicInfo", MusicInfo.class);
			System.out.println(musicInfo);
			musicInfoMapper.insMusicInfo(musicInfo);
		}
	}
}
