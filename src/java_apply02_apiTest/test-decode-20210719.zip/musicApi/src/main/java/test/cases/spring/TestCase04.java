package test.cases.spring;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import test.App;
import test.mapper.TempMapper;
import test.util.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestCase04 {
	@Resource
	private TempMapper tempMapper;
	
	@Test
	public void test01() throws IOException {
		List<String> selAllText = tempMapper.selAllText();
		List<String> selAllContentFilter = tempMapper.selAllContentFilter();
		
		for (int i = 0; i < selAllText.size(); i++) {
			String url1 = "https://open.migu.cn:98/sportMusic/rest/search/voiceBoxSearchSong?evident";
			String request1 = "{\"text\":\""+selAllText.get(i)+"\",\"searchType\":4,"
					+ "\"contentFilter\":\""+selAllContentFilter.get(i)+"\","
							+ "\"searchRange\":{\"singerName\":[\""+selAllText.get(i)+"\"]}}";
			String authorization1="OEPAUTH chCode=\"014D04Q\", smartDeviceId=\"704F0801841A\"";
			String resp1 = RequestUtils.sendRequest(url1, request1, authorization1);
			System.out.println(request1);
			System.out.println(resp1);
			tempMapper.updRespByTextAndContentFilter(selAllText.get(i), 
					selAllContentFilter.get(i), resp1,request1);
		}
	}
}
