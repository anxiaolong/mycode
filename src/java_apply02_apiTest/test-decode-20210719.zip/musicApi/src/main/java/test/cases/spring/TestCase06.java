package test.cases.spring;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;

import test.pojo.MusicInfo;
import test.util.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestCase06 {
	
	static Logger logger = LoggerFactory.getLogger(TestCase06.class);
	
	@Test
	public void test01() throws IOException  {
		//1.测试歌手数据
		String singers = "卫兰,TFBOYS,孙燕姿,蔡依林,戴佩妮,薛凯琪,陈柏宇";
		String[] split = singers.split(",");
		
		//2.获取tokenmd5(wwwmiguff2102dcf16002d8c1dde6547ea988241620872066) appid+appkey+timestamp
		String timestamp = (String) (Calendar.getInstance().getTimeInMillis()+"").subSequence(0, 10);
		String token1 = "wwwmigu"+"ff2102dcf16002d8c1dde6547ea98824"+timestamp;
		String token = DigestUtils.md5Hex(token1);
		System.out.println(token);
		
		//3.获取歌手搜索结果
		for (int i = 0; i < split.length; i++) {
			String url = "https://jadeite.migu.cn:8030/musicsearch/api/json/voiceBoxSearchSong?"
					+ "text="+split[i]+"&searchType=2&sort=1&issemantic=1&isCorrect=1&isCopyright=0&expire=000000&searchRange={\"movieName\":[\"\"],\"songName\":[\"\"],\"singerName\":[\"\"],\"writterName\":[\"\"],\"albumName\":[\"\"],\"tagName\":[\"\"]}"
							+ "&appId=wwwmigu&timestamp="+timestamp+"&sid=1&sessionId=1&"
					+ "token="+token+"&contentFilter=01&pageSize=50&pageIndex=1";
			System.out.println(url);
			logger.info(url);
			
			Connection conn = Jsoup.connect(url).ignoreContentType(true)
					.method(Method.GET);
			Response rsp = conn.execute();
			String body = rsp.body();
			JSONObject parseObject = JSON.parseObject(body);
			
			//4.获取搜索结果 歌曲数、歌曲名称、歌曲id
			String total = parseObject.getJSONObject("data").getString("total");
			String fullSongTotal = parseObject.getJSONObject("data").getString("fullSongTotal");
			System.out.println("total:"+total+"-->fullSongTotal:"+fullSongTotal);
			JSONArray jsonArray = parseObject.getJSONObject("data").getJSONArray("result");
			for (int j = 0; j < jsonArray.size(); j++) {
				JSONArray jsonArray2 = jsonArray.getJSONObject(j).getJSONArray("singers");
				List<String> singerList = new ArrayList<String>();
				for (int k = 0; k < jsonArray2.size(); k++) {
					String string = jsonArray2.getJSONObject(k).getString("name");
					singerList.add(string);
				}
				String songName = jsonArray.getJSONObject(j).getString("name");
				String songid = jsonArray.getJSONObject(j).getJSONArray("fullSongs").getJSONObject(0).getString("copyrightId");
				System.out.println(singerList+"-->"+songName+"-->"+songid);
				logger.info(singerList+"-->"+songName+"-->"+songid);
				
				//5.查询歌曲详情，找到不等于auditionsFlag = 7的歌
				String url2 = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
				String request2 = "{\"musicId\":\""+songid+"\",\"pageSize\":\"S\"}";
				String authorization2="OEPAUTH chCode=\"a39d713b25e95b2b\", smartDeviceId=\"liebaotest001\"";
				String resp2 = RequestUtils.sendRequest(url2, request2, authorization2);
				JSONObject parseResp2 = JSON.parseObject(resp2);
				MusicInfo musicInfo = parseResp2.getObject("musicInfo", MusicInfo.class);
				if (!musicInfo.getAuditionsFlag().equals("7")) {
					System.out.println(musicInfo.getAuditionsFlag());
					logger.info(musicInfo.getAuditionsFlag());
				}
			}
		}
	}

}
