package test.cases.spring;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import test.App;
import test.mapper.TempMapper01;

@SpringBootTest(classes = App.class)
public class TestCase07 {
	@Resource
	private TempMapper01 tempMapper01;
	
	@Test
	public void test01() throws IOException {
		List<String> selAllName = tempMapper01.selAllName();
		
		Random random = new Random();
		
		//1.遍历所有人
		for (String name : selAllName) {
			//2.找到这个人所有出勤的日期并去重
			System.out.println(name);
			List<Date> selAllDate = tempMapper01.selAllDate("%"+name+"%");
			System.out.println(selAllDate.size());
			//3.遍历日期
			for (Date date : selAllDate) {
				//4.该日期下随机生成8—9点的时间上班时间
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				 
				cal.set(Calendar.HOUR_OF_DAY, 8); //时
				cal.set(Calendar.MINUTE, random.nextInt(59)); //分
				cal.set(Calendar.SECOND, random.nextInt(59)); //秒
				Date startTime = cal.getTime();
				
				//5.该日期下生成一个18-19点的下班时间
				cal.set(Calendar.HOUR_OF_DAY, 18); //时
				cal.set(Calendar.MINUTE, random.nextInt(59)); //分
				cal.set(Calendar.SECOND, random.nextInt(59)); //秒
				Date endTime = cal.getTime();
				System.out.println("上班时间："+startTime+"-->下班时间："+endTime);
				
				//5.上下班时间入库
				tempMapper01.insSign(name, startTime);
				tempMapper01.insSign(name, endTime);
			}
		}
	}
}
