package test.cases.spring;

import javax.annotation.Resource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import test.App;
import test.mapper.TempMapper03;
/**
 * 测试数据库字段加索引的查询效率
 */
@SpringBootTest(classes = App.class)
public class TestCase10 {
	@Resource
	private TempMapper03 tempMapper03;
	
	/**
	 * 加索引
	 * 耗时：5583
	 */
	@Test
	@Disabled 
	public void test01() {
		long start = System.currentTimeMillis();
		for (int i = 0; i < 9999; i++) {
			tempMapper03.selSignByName("曹莎莎");
		}
		long end = System.currentTimeMillis();
		
		System.out.println("耗时："+(end-start));
	}
	
	/**
	 * 去掉索引后
	 * 耗时：81443
	 */
	@Test
	public void test02() {
		long start = System.currentTimeMillis();
		for (int i = 0; i < 9999; i++) {
			tempMapper03.selSignByName("曹莎莎");
		}
		long end = System.currentTimeMillis();
		
		System.out.println("耗时："+(end-start));
	}
}
