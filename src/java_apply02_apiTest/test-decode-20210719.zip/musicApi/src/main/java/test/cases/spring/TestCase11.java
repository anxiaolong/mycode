package test.cases.spring;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import test.App;
import test.mapper.MusicInfoMapper;
import test.pojo.MusicInfo;
import test.util.DataUtils;
import test.util.RequestUtils;

@SpringBootTest(classes = App.class)
public class TestCase11 {
	@Resource
	private MusicInfoMapper musicInfoMapper;

	@Test
	public void test01() throws IOException {
		//1.获取电台下所有歌曲id,radioName,radioId
		String url1 = "https://open.migu.cn:98/sportMusic/1.0/rest/migu/app/radio/get?evident";
		String request1 = "";
		String authorization1="OEPAUTH chCode=\"014D08C\", smartDeviceId=\"869634045029820\"";
		String resp1 = RequestUtils.sendRequest(url1, request1, authorization1);
		JSONArray parseArray = JSON.parseArray(resp1);
		System.out.println("响应对象大小："+parseArray.size());

		for (int i = 0; i < parseArray.size(); i++) {
			String columnId = parseArray.getJSONObject(i).getString("columnId");
			String columnName = parseArray.getJSONObject(i).getString("columnName");
			//System.out.println(columnName);
			JSONArray radiosArray = parseArray.getJSONObject(i).getJSONArray("radios");
			System.out.println("radiosArray大小："+radiosArray.size());
			for (int j = 0; j < radiosArray.size(); j++) {
				JSONObject radioObject = radiosArray.getJSONObject(j);
				String radioId = radioObject.getString("radioId");
				String radioName = radioObject.getString("radioName");
				String radioPic = radioObject.getString("radioPic");
				JSONArray songIdArray = radioObject.getJSONArray("songIds");
				for (int k = 0; k < songIdArray.size(); k++) {
					System.out.println(columnId+"-->"+columnName+
							"-->"+radioId+"-->"+radioName+
							"-->"+songIdArray.getString(k)+
							"-->"+radioPic);
					//2.歌曲信息对应电台信息入库
					musicInfoMapper.insSongId(songIdArray.getString(k), columnId,
							columnName, radioId, radioName,radioPic);
				}
			}
		}

		//2.获取歌曲详情并入库
		List<String> allSongIdList = musicInfoMapper.getAllSongId();
		for (String songid : allSongIdList) {
			System.out.println(songid);
			String url2 = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
			String request2 = "{\"musicId\":\""+songid+"\",\"pageSize\":\"S\"}";
			String authorization2="OEPAUTH chCode=\"014D08C\", smartDeviceId=\"869634045029820\"";
			String resp2 = RequestUtils.sendRequest(url2, request2, authorization2);
			//System.out.println(resp1);
			JSONObject parseObject = JSON.parseObject(resp2);
			MusicInfo musicInfo = parseObject.getObject("musicInfo", MusicInfo.class);
			if (musicInfo!=null){
				musicInfo.setCreateTime(DataUtils.dateTimeFormat(new Date()));
			}
			System.out.println(musicInfo);
			musicInfoMapper.insMusicInfo(musicInfo);
		}
	}
	 
}
