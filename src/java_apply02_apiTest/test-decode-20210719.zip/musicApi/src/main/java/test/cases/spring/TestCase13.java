package test.cases.spring;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.mapper.MusicInfoMapper2;
import test.pojo.MusicInfo;
import test.util.DataUtils;
import test.util.RequestUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Date;
import java.util.Objects;

@SpringBootTest(classes = App.class)
public class TestCase13 {
	@Resource
	private MusicInfoMapper2 musicInfoMapper2;

	/**
	 * 1.语音搜歌，搜几个标签
	 * 2.结果抽屉取第一条
	 * 3.查歌曲详情入库
	 */
	@Test
	public void test01() throws IOException {
		String[] selAllText = new String[]{"粤语","蓝调","歌剧","R&B","雷鬼","歌手"};

		for (int i = 0; i < selAllText.length; i++) {
			String url1 = "https://open.migu.cn:98/sportMusic/rest/search/voiceBoxSearchSong?evident";
			String request1 = "{\"text\":\"新歌\",\"searchType\":4," +
					"\"sort\":1,\"pageSize\":50,\"sortType\":1,\"contentFilter\":\"01\"," +
					"\"searchRange\":{\"tagName\":[\""+selAllText[i]+"\"]}}";
			// "歌手" 用movieName搜
			String request3 = "{\"text\":\"新歌\",\"searchType\":4," +
					"\"sort\":1,\"pageSize\":50,\"sortType\":1,\"contentFilter\":\"01\"," +
					"\"searchRange\":{\"movieName\":[\""+selAllText[i]+"\"]}}";
			String authorization1="OEPAUTH chCode=\"014D08C\", smartDeviceId=\"869634045029820\"";

			String resp1 = null;
			if (Objects.equals("歌手",selAllText[i])){
				resp1 = RequestUtils.sendRequest(url1, request3, authorization1);
			}else {
				resp1 = RequestUtils.sendRequest(url1, request1, authorization1);
			}
			System.out.println(request1);
			System.out.println(resp1);
			JSONObject resJsonObject = JSON.parseObject(resp1);
			JSONArray resultArray = resJsonObject.getJSONObject("searchVoiceBox")
					.getJSONObject("data")
					.getJSONArray("result");
			for (Object object : resultArray) {
				JSONArray fullSongs = ((JSONObject) object).getJSONArray("fullSongs");
				// 取第一个copyrightId
				String copyrightId = fullSongs.getJSONObject(0).getString("copyrightId");
				// System.out.println(copyrightId);
				// 查询歌曲详情并入库
				String url2 = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
				String request2 = "{\"musicId\":\""+copyrightId+"\",\"pageSize\":\"S\"}";
				String authorization2="OEPAUTH chCode=\"014D08C\", smartDeviceId=\"869634045029820\"";
				String resp2 = RequestUtils.sendRequest(url2, request2, authorization2);
				//System.out.println(resp2);
				MusicInfo musicInfo = JSON.parseObject(resp2).getObject("musicInfo", MusicInfo.class);
				if (musicInfo!=null){
					musicInfo.setCreateTime(DataUtils.dateTimeFormat(new Date()));
					musicInfoMapper2.insMusicInfo(musicInfo);
					musicInfoMapper2.saveMusicAndTag(copyrightId,selAllText[i]);
				}
			}
		}
	}
}