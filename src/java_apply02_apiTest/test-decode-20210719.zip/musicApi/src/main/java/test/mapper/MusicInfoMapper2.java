package test.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import test.pojo.MusicInfo;

import java.util.List;

public interface MusicInfoMapper2 {
	@Insert("insert into musicinfo "
			+ "(musicId,createTime,musicName,singerName,albumNames,songAuthorName,"
			+ "lyricAuthorName,length,language,picUrl,lrcUrl,listenUrl,isCollection,"
			+ "isCpAuth,auditionsFlag,vid) VALUE "
			+ "(#{musicId},#{createTime},#{musicName},#{singerName},#{albumNames},#{songAuthorName},#{lyricAuthorName},#{length},"
			+ "#{language},#{picUrl},#{lrcUrl},#{listenUrl},#{isCollection},#{isCpAuth},#{auditionsFlag},#{vid})")
	int insMusicInfo(MusicInfo musicInfo);
	
	@Select("SELECT * FROM musicinfo")
	List<MusicInfo> selAllMusicInfo();

	@Select("SELECT songId FROM songid;")
	List<String> listSongId();

	@Insert("insert into music_tag (songId,tag) value (#{songId},#{tag});")
	int saveMusicAndTag(@Param("songId") String songId,@Param("tag") String tag);
}
