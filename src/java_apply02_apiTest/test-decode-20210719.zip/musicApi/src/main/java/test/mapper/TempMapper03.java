package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import test.pojo.Sign;

public interface TempMapper03 {
	@Select("SELECT * FROM temp_sign t WHERE t.name=#{name};")
	List<Sign> selSignByName(@Param("name") String name);
}
