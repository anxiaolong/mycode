package test.pojo;

import lombok.Data;

@Data
public class Song {
	private String id;
	private String result;
	private String resCode;
	private String resMsg;
}
