package test.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class Temp_work {
	private int id;
	private String name;
	private Date month;
	private int work_days;
	private int overtime_days;
}
