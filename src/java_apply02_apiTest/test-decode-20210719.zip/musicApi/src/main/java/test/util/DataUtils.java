package test.util;

import org.testng.Reporter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DataUtils {

    public static String dateTimeFormat(Date date){
        //创建一个格式化日期对象
        DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //格式化后的时间
        String punchTime = simpleDateFormat.format(date);
        return punchTime;
    }

    public static void logToReport(String url,String request,String authorization,String resp){
        Reporter.log("input-->" +url+"---"+request+"---"+authorization);
        Reporter.log("---------------------------------------------------");
        Reporter.log("output-->" +resp);
    }
}
