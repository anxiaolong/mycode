/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 80020
Source Host           : localhost:3306
Source Database       : testjdbc

Target Server Type    : MYSQL
Target Server Version : 80020
File Encoding         : 65001

Date: 2021-07-13 23:41:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dbeaver_new
-- ----------------------------
DROP TABLE IF EXISTS `dbeaver_new`;
CREATE TABLE `dbeaver_new` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `pwd` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for image
-- ----------------------------
DROP TABLE IF EXISTS `image`;
CREATE TABLE `image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `imageName` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for musicinfo
-- ----------------------------
DROP TABLE IF EXISTS `musicinfo`;
CREATE TABLE `musicinfo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `musicId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `musicName` varchar(255) DEFAULT NULL,
  `singerName` varchar(255) DEFAULT NULL,
  `albumNames` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `songAuthorName` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `lyricAuthorName` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `length` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `listenUrl` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `picUrl` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `lrcUrl` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `isCollection` varchar(255) DEFAULT NULL,
  `isCpAuth` varchar(255) DEFAULT NULL,
  `auditionsFlag` varchar(255) DEFAULT NULL,
  `vid` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `f_vid` (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for music_tag
-- ----------------------------
DROP TABLE IF EXISTS `music_tag`;
CREATE TABLE `music_tag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `songId` varchar(50) DEFAULT NULL,
  `tag` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for song
-- ----------------------------
DROP TABLE IF EXISTS `song`;
CREATE TABLE `song` (
  `id` varchar(255) NOT NULL,
  `resCode` varchar(255) DEFAULT NULL,
  `resMsg` varchar(255) DEFAULT NULL,
  `result` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for songid
-- ----------------------------
DROP TABLE IF EXISTS `songid`;
CREATE TABLE `songid` (
  `id` int NOT NULL AUTO_INCREMENT,
  `songId` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `songName` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `resultSet` text,
  `result` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10926 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for ssm_demo
-- ----------------------------
DROP TABLE IF EXISTS `ssm_demo`;
CREATE TABLE `ssm_demo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for temp01
-- ----------------------------
DROP TABLE IF EXISTS `temp01`;
CREATE TABLE `temp01` (
  `id` int NOT NULL AUTO_INCREMENT,
  `songId` varchar(255) DEFAULT NULL,
  `columnId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `columnName` varchar(255) DEFAULT NULL,
  `radioId` varchar(255) DEFAULT NULL,
  `radioName` varchar(255) DEFAULT NULL,
  `radioPic` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13400 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for temp_jiaban
-- ----------------------------
DROP TABLE IF EXISTS `temp_jiaban`;
CREATE TABLE `temp_jiaban` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `month` int DEFAULT NULL,
  `jiaban` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for temp_people
-- ----------------------------
DROP TABLE IF EXISTS `temp_people`;
CREATE TABLE `temp_people` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for temp_ribao
-- ----------------------------
DROP TABLE IF EXISTS `temp_ribao`;
CREATE TABLE `temp_ribao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `names` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `names` (`names`),
  KEY `date` (`date`,`names`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for temp_sign
-- ----------------------------
DROP TABLE IF EXISTS `temp_sign`;
CREATE TABLE `temp_sign` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34827 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for temp_work
-- ----------------------------
DROP TABLE IF EXISTS `temp_work`;
CREATE TABLE `temp_work` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `month` date DEFAULT NULL,
  `work_days` int DEFAULT NULL,
  `overtime_days` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=859 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` char(30) DEFAULT NULL,
  `pwd` char(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30002 DEFAULT CHARSET=utf8;
