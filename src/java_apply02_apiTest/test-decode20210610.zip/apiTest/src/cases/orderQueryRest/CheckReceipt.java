package cases.orderQueryRest;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;
/**
 * ��Ʒ֧������У��ӿ�
 */
public class CheckReceipt extends ApiAdapter {
	public CheckReceipt() {
		//ȫ���Ի�����ַ
		this.setUrl("http://10.25.193.30:8170/orderQueryRest/checkReceipt");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"productId\": \"014\","
				+ "\"channelId\":\"\","
				+ "\"orderId\": \"100001420210311093028502\","
				+ "\"transactionId\": \"100001420210311093028502\","
				+ "\"uid\": \"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"partner\": \"1000014\",\"time\": \"20210311093028\","
				+ "\"receiptData\":\"bbbbdfdfdfdf\",\"enviroment\":\"01\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_TicketOrderQuery() throws IOException, EncoderException {
		CheckReceipt toq=new CheckReceipt();
		DataUtils.sendRequest(toq.getUrl(), toq.getFinalRequest());
	}

}
