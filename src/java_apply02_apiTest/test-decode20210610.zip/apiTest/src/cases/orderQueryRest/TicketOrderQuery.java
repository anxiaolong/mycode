package cases.orderQueryRest;
/**
 * ֧�������ѯ
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

public class TicketOrderQuery extends ApiAdapter {
	public TicketOrderQuery() {
		//ȫ���Ի�����ַ
		this.setUrl("http://10.25.193.30:8178/orderQueryRest/ticketOrderQuery");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		
		JSONObject data = new JSONObject();
		data.put("orderId", "100001420210126093938230");
		this.setData(data);
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("time", DataUtils.getTime());
		newReq.put("partner", this.getPartner());
		return newReq.toString();
	}
	
	
	@Test
	public void test_TicketOrderQuery() throws IOException, EncoderException {
		TicketOrderQuery toq=new TicketOrderQuery();
		DataUtils.sendRequest(toq.getUrl(), toq.getFinalRequest());
	}

}
