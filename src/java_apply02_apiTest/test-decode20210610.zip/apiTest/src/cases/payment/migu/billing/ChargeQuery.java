package cases.payment.migu.billing;
/**
 * ����֧�������ѯ�ӿ�
 */

import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class ChargeQuery extends ApiAdapter {

	public ChargeQuery() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment/migu/billing/chargeQuery");
		JSONObject parseObject = JSON.parseObject("{\"partner\": \"1000014\","
				+ "\"time\": \""+DataUtils.getTime()+"\",\"signType\": \"MD5\","
				+ "\"transactionId\":\"0101720210107155121895\","
				+ "\"transDate\":\"20210107\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		ChargeQuery charge=new ChargeQuery();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getFinalRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
