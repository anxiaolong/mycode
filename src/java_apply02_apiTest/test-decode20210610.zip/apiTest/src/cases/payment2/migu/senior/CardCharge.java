package cases.payment2.migu.senior;
/**
 * ��̨��֧������ӿ�
 */
import org.testng.annotations.Test;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;
import java.io.IOException;
import org.apache.commons.codec.EncoderException; 

public class CardCharge extends ApiAdapter {

	public CardCharge() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment2/migu/senior/cardCharge");
		String orderId=DataUtils.getOrderId(this.getPartner());

		JSONObject parseObject = JSON.parseObject("{\"AccessMode\":\"4\",\"AccessPlatformID\":\"0140070\","
				+ "\"DID\":\"1128000\",\"MSISDN\":\"15928791968\",\"cardType\":\"40\","
				+ "\"partner\":\"1000014\",\"passId\":\"383461296272569892\","
				+ "\"payInfo\":[{\"BizCode\":\"600987040014706681\","
				+ "\"ContentID\":\"633986Z04000000140\","
				+ "\"CopyRightID\":\"600504080015\",\"ExpansionParam\":\"musicApp\","
				+ "\"InterfaceType\":\"order\","
				+ "\"actionId\":\"musicApp\",\"count\":\"1\",\"goodsName\":\"�������Ʊѡ\","
				+ "\"orderId\":\""+orderId+"\","
				+ "\"price\":\"10\",\"terminal\":\"\"}],\"productId\":\"028\","
				+ "\"terminal\":\"IOS\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"totalPrice\":\"10\","
				+ "\"transactionId\":\""+orderId+"\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		CardCharge charge=new CardCharge();
		JSONArray parseArray = JSON.parseArray("[{\"cardPayPrice\":\"3\",\"cardPayType\":\"49\"}]");
		charge.getData().put("cardPayInfo", parseArray);
		DataUtils.sendRequest(charge.getUrl(), charge.getFinalRequest());
	}
	
}
