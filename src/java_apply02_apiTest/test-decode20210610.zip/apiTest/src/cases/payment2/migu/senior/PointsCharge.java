package cases.payment2.migu.senior;
/**
 * �乾��/�乾ȯ������̨֧���ӿ�
 */

import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class PointsCharge extends ApiAdapter {

	public PointsCharge() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/payment2/migu/senior/pointsCharge");
		String orderId=DataUtils.getOrderId(this.getPartner());
		JSONObject parseObject = JSON.parseObject(""
				+ "{\"uid\":\"d125c6e8-2079-4b81-bd91-9f337eec30ab\","
				+ "\"MSISDN\":\"18210030020\","
				+ "\"partner\":\"1000014\","
				+ "\"productId\":\"008\","
				+ "\"orderId\":\""+orderId+"\","
						+ "\"totalPrice\":\"1\",\"count\":1,"
						+ "\"time\":\""+DataUtils.getTime()+"\","
						+ "\"transactionId\":\""+orderId+"\","
						+ "\"BizCode\":\"698039020100000129\"}");
		this.setData(parseObject);
	}
	
	@Test
	public void test_Charge() throws IOException, EncoderException {
		PointsCharge charge=new PointsCharge();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getFinalRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
