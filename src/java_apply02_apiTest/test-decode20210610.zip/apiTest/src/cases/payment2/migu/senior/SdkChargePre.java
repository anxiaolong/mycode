package cases.payment2.migu.senior;


import java.io.IOException;
import org.apache.commons.codec.EncoderException;
import org.junit.Ignore;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;
/**
 * sdk�µ�
 */
public class SdkChargePre extends ApiAdapter {
	public SdkChargePre() {
		this.setUrl("http://10.25.193.30:8170/payment2/migu/senior/sdkChargePre");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setOrderId(DataUtils.getOrderId(this.getPartner()));
	}
	
	//1.�����µ�������
	@Test
	//@Ignore
	public void test01() throws IOException, EncoderException {
		SdkChargePre request=new SdkChargePre();
		
		request.setData(new JSONObject());
		JSONArray payInfoArray=new JSONArray();
		JSONObject payInfo=new JSONObject();
		//�������������
		request.setOrderId(DataUtils.getOrderId("1000014"));
		payInfo.put("BizCode", "600987040010730013");
		payInfo.put("ExpansionParam", "");
		payInfo.put("InterfaceType", "listen");
		payInfo.put("MonLength", "1");
		payInfo.put("bankCode", "WX");
		payInfo.put("wechatCode", "testwechatCode");
		payInfo.put("openid", "testopenid");
		payInfo.put("count", "1");
		payInfo.put("goodsName", "");
		payInfo.put("holdpay", "1");
		payInfo.put("isShowCasher", "1");
		payInfo.put("orderId", request.getOrderId());
		payInfo.put("price", "1000");
		payInfo.put("terminal", "ANDROID");
		payInfoArray.add(payInfo);
		
		request.getData().put("AccessMode", "7");
		request.getData().put("AccessPlatformID", "014000D");
		request.getData().put("DID", "1128050");
		request.getData().put("MSISDN", "15928791968");
		request.getData().put("notifyUrl", "http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do");
		request.getData().put("partner", "1000014");
		request.getData().put("passId", "405535601515956602");
		request.getData().put("productId", "014");
		request.getData().put("time", DataUtils.getTime());
		request.getData().put("totalPrice", "1000");
		request.getData().put("transactionId",request.getOrderId());
		request.getData().put("uid", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		request.getData().put("payInfo", payInfoArray);
		
		DataUtils.sendRequest(request.getUrl(), request.getFinalRequest());
	}
	
	//2.�����µ�����ר��
	@Test
	@Ignore
	public void test02() throws IOException, EncoderException {
		SdkChargePre request=new SdkChargePre();
		
		String data = "{\"partner\":\"1000014\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+request.getOrderId()+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"50\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"0\",\"appleProductId\":\"\","
				+ "\"memberFlag\":\"0\",\"payInfo\":[{\"orderId\":\""+request.getOrderId()+"\","
				+ "\"price\":\"50\",\"InterfaceType\":\"order\",\"count\":\"5\","
				+ "\"goodsName\":\"�״ι�������ר���µ�\",\"BizCode\":\"600987040014706681\","
				+ "\"ContentID\":\"600987040014706681\",\"CopyRightID\":\"600504080015\","
				+ "\"terminal\":\"Android\",\"MonLength\":\"\",\"ExpansionParam\":\"\","
				+ "\"saleMode\":\"1\"}]"+"}";
		JSONObject parseObject = JSON.parseObject(data);
		request.setData(parseObject);
		
		DataUtils.sendRequest(request.getUrl(), request.getFinalRequest());
	}
	
	//3.�����µ�����ר�������еֿ�
	@Test
	@Ignore
	public void test03() throws IOException, EncoderException {
		SdkChargePre request=new SdkChargePre();
		
		String data = "{\"partner\":\"1000014\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+request.getOrderId()+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"10\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"0\",\"appleProductId\":\"\","
				+ "\"memberFlag\":\"0\",\"payInfo\":[{\"orderId\":\""+request.getOrderId()+"\","
				+ "\"price\":\"10\",\"InterfaceType\":\"order\",\"count\":\"1\","
				+ "\"goodsName\":\"��������ר��ʹ�õֿ�\",\"BizCode\":\"600987040014706681\","
				+ "\"ContentID\":\"600987040014706681\",\"CopyRightID\":\"600504080015\","
				+ "\"terminal\":\"Android\",\"MonLength\":\"\",\"ExpansionParam\":\"\","
				+ "\"saleMode\":\"1\"}]"
				+ ",\"cardPayInfo\":[{\"cardPayPrice\":\"3\","
				+ "\"cardPayType\":\"49\"}]}";
		JSONObject parseObject = JSON.parseObject(data);
		request.setData(parseObject);
		
		DataUtils.sendRequest(request.getUrl(), request.getFinalRequest());
	}
	
	//4.����ios���ֿ�
	@Test
	@Ignore
	public void test04() throws IOException, EncoderException {
		SdkChargePre charge=new SdkChargePre();
		
		charge.setOrderId(DataUtils.getOrderId(charge.getPartner()));
		//����payInfo����
		JSONObject payInfJson=new JSONObject();
		payInfJson.put("orderId", charge.getOrderId());
		payInfJson.put("price", "3000");
		payInfJson.put("InterfaceType", "digital");
		payInfJson.put("count", "5");
		payInfJson.put("goodsName", "ios���ֿ�");
		payInfJson.put("BizCode", "600987040004949396");
		payInfJson.put("MonLength", "1");
		payInfJson.put("ExpansionParam", "");
		payInfJson.put("terminal", "IOS");
		//���payInfo
		JSONArray payInfo=new JSONArray();
		payInfo.add(payInfJson);
		
		//���data����
		String data = "{\"partner\":\"1000014\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+charge.getOrderId()+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"3000\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"0\",\"appleProductId\":\"\","
				+ "\"memberFlag\":\"0\""
				+ "}";
		JSONObject parseObject = JSON.parseObject(data);
		charge.setData(parseObject);
		charge.getData().put("payInfo", payInfo);
		charge.getData().put("appleProductId", "com.migu.dev.mobilemusic.6yuan");
		
		DataUtils.sendRequest(charge.getUrl(), charge.getFinalRequest());
	}
	
	//5.�����Աʹ�û�Ա������ֿ�
	@Test
	@Ignore
	public void test05() throws IOException, EncoderException {
		SdkChargePre request=new SdkChargePre();
		
		String data = "{\"partner\":\"1000014\",\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+request.getOrderId()+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"1000\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\",\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"0\",\"appleProductId\":\"\","
				+ "\"memberFlag\":\"0\",\"payInfo\":[{\"orderId\":\""+request.getOrderId()+"\","
				+ "\"price\":\"1000\","
				+ "\"InterfaceType\":\"thmon\",\"count\":\"1\","
				+ "\"goodsName\":\"ʹ�û�Ա����������Ա\","
				+ "\"BizCode\":\"600927020000005010\","
				+ "\"ContentID\":\"600987040014706681\",\"CopyRightID\":\"600504080015\","
				+ "\"terminal\":\"Android\","
				+ "\"MonLength\":\"1\",\"ExpansionParam\":\"\","
				+ "\"saleMode\":\"1\"}]"
				+ ",\"cardPayInfo\":[{\"cardPayPrice\":\"600\","
				+ "\"cardPayType\":\"50\"}]}";
		JSONObject parseObject = JSON.parseObject(data);
		request.setData(parseObject);
		
		DataUtils.sendRequest(request.getUrl(), request.getFinalRequest());
	}
	
	//6.sdk�µ�������ӽ�
	@Test
	@Ignore
	public void test06() throws IOException, EncoderException {
		SdkChargePre request=new SdkChargePre();
		String orderId = DataUtils.getOrderId(this.getPartner());
		String data = "{\"partner\":\"1000014\","
				+ "\"time\":\""+DataUtils.getTime()+"\","
				+ "\"transactionId\":\""+orderId+"\","
				+ "\"rewardUserId\":\"\",\"rewardMSISDN\":\"\",\"format\":\"\","
				+ "\"DID\":\"1128050\",\"productId\":\"006\","
				+ "\"totalPrice\":\"100\",\"isMarket\":\"0\","
				+ "\"notifyUrl\":\"http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do\","
				+ "\"MSISDN\":\"15928791968\","
				+ "\"uid\":\"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"AccessPlatformID\":\"0146921\",\"AccessMode\":\"3\","
				+ "\"appleProductId\":\"\",\"memberFlag\":\"0\","
				+ "\"payInfo\":[{\"orderId\":\""+orderId+"\","
				+ "\"price\":\"100\",\"InterfaceType\":\"thmon\",\"count\":\"1\","
				+ "\"goodsName\":\"ֱ���ӽ��й�����\",\"BizCode\":\"633986Z08000000023\","
				+ "\"ContentID\":\"600987040019144861\",\"CopyRightID\":\"\","
				+ "\"terminal\":\"Android\",\"MonLength\":\"6\",\"ExpansionParam\":\"\","
				+ "\"saleMode\":\"1\",\"wechatCode\":\"\",\"openid\":\"\"}]}";
		JSONObject parseObject = JSON.parseObject(data);
		request.setData(parseObject);
		
		DataUtils.sendRequest(request.getUrl(), request.getFinalRequest());
	}
	
	
}
