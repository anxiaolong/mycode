package cases.payment_account.account;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 

/**
 * ��ȡ�ҵĿ�ȯ�б�
 */
public class CardCouponList extends ApiAdapter {
	public CardCouponList() {
		this.setUrl("http://10.25.193.16:18101/payment-account/account/CardCouponList");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		this.setData(new JSONObject());
		this.getData().put("uid","a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("msisdn","15928791968");
		this.getData().put("cardTypes","50");
		this.getData().put("cardStatus","1"); //1δʹ�� 2�ѹ���
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType","MD5");
		newReq.put("partner",this.getPartner());
		return newReq.toString();
	}
	
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		CardCouponList getAccountList=new CardCouponList();
		assertThat(DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getFinalRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�ɹ�\""));
	}

}
