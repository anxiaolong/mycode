package cases.payment_account.account;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;
/**
 * ��ȡ��������Ϣ�б�
 */
public class GetCardOrderList extends ApiAdapter {
	public GetCardOrderList() {
		this.setUrl("http://"+this.getTestip()+":18101/payment-account/account/getCardOrderList");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		this.setData(new JSONObject());
		this.getData().put("uid","a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("cardType","49");
		this.getData().put("pageNum","1");
		this.getData().put("pageCount","20");
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("partner","1000014");
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		GetCardOrderList getCardOrderList=new GetCardOrderList();
		DataUtils.sendRequest(getCardOrderList.getUrl(), getCardOrderList.getFinalRequest());
	}

}
