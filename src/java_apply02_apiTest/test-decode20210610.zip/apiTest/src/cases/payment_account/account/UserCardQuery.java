package cases.payment_account.account;
/**
 * �����ҵĳ�����
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 

public class UserCardQuery extends ApiAdapter {
	public UserCardQuery() {
		this.setUrl("http://"+this.getTestip()+":18101/payment-account/account/userCardQuery");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		JSONObject parseObject = JSON.parseObject("{"
				+ "\"partner\": \""+this.getPartner()+"\","
				+ "\"uid\": \"a1c59a9d-88ab-4ed0-8b65-962b411d7e75\","
				+ "\"MSISDN\": \"15928791968\","
				+ "\"cardType\": \"48\"}");
		this.setData(parseObject);
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	@Test
	public void test_GetAccountList() throws IOException, EncoderException {
		UserCardQuery getAccountList=new UserCardQuery();
		assertThat(DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getFinalRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�ɹ�\""));
	}

}
