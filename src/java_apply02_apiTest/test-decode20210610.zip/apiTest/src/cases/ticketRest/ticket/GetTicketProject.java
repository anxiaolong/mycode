package cases.ticketRest.ticket;
import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import org.apache.commons.codec.EncoderException; 

public class GetTicketProject extends ApiAdapter {
	public GetTicketProject() {
		this.setUrl("http://"+this.getTestip()+":18701/ticketRest/ticket/getTicketProject");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		this.setData(new JSONObject());
		this.getData().put("projectId", "121001002");
		this.getData().put("custId", "7ddbdc27-1fee-4ebd-b909-c2d50b1f02e2");
		this.getData().put("custPhone", "18408244027");
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType", "MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
	
	
	@Test
	public void test_GetTicketProject() throws Exception {
		GetTicketProject getTicketProject=new GetTicketProject();
		DataUtils.sendRequest(getTicketProject.getUrl(), getTicketProject.getFinalRequest());
	}

}
