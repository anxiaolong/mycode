package cases.ticketRest.ticket;
/**
 * ���ɹ��������͵�
 */

import org.testng.annotations.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import test.api.adapter.ApiAdapter;
import test.api.utils.DataUtils;

import static org.junit.Assert.assertThat;

import org.apache.commons.codec.EncoderException;

public class GiftForm extends ApiAdapter {
	public GiftForm() {
		this.setUrl("http://"+this.getTestip()+":18701/ticketRest/ticket/giftForm");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		this.setData(new JSONObject());
		this.getData().put("custId", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("orderId", "100000420210413150427207");
		this.getData().put("pid", "121001091");
		this.getData().put("custPhone", "15928791968");
		this.getData().put("giveNum", "1");
		
	}
	
	@Override
	public String getFinalRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getFinalRequest());
		newReq.put("signType", "MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
	
	
	@Test
	public void test_GetTicketProject() throws Exception {
		GiftForm getTicketProject=new GiftForm();
		DataUtils.sendRequest(getTicketProject.getUrl(), getTicketProject.getFinalRequest());
	}

}
