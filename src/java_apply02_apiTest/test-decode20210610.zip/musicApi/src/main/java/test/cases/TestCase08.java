package test.cases;

import java.io.IOException;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import test.App;
import test.mapper.TempMapper01;
import test.pojo.Sign;

@SpringBootTest(classes = App.class)
public class TestCase08 {
	@Resource
	private TempMapper01 tempMapper01;
	
	@Test
	@Disabled
	public void test01() throws IOException {
		List<String> selAllName = tempMapper01.selAllName();
		
		Random random = new Random();
		
		//1.遍历所有人
		for (String name : selAllName) {
			//2.找到这个人所有出勤的日期并去重
			System.out.println(name);
			List<Date> selAllDate = tempMapper01.selAllDate("%"+name+"%");
			System.out.println(selAllDate.size());
			//3.遍历日期
			for (Date date : selAllDate) {
				//4.该日期下随机生成8—9点的时间上班时间
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				 
				cal.set(Calendar.HOUR_OF_DAY, 8); //时
				cal.set(Calendar.MINUTE, random.nextInt(59)); //分
				cal.set(Calendar.SECOND, random.nextInt(59)); //秒
				Date startTime = cal.getTime();
				
				//5.该日期下生成一个18-19点的下班时间
				cal.set(Calendar.HOUR_OF_DAY, 18); //时
				cal.set(Calendar.MINUTE, random.nextInt(59)); //分
				cal.set(Calendar.SECOND, random.nextInt(59)); //秒
				Date endTime = cal.getTime();
				System.out.println("上班时间："+startTime+"-->下班时间："+endTime);
				
				//5.上下班时间入库
				tempMapper01.insSign(name, startTime);
				tempMapper01.insSign(name, endTime);
			}
		}
	}
	
	@Test
	@Disabled
	public void test04() {
		List<Sign> selAllSign = tempMapper01.selAllSign();
		for (Sign sign : selAllSign) {
			sign.getDate().setYear(120);
			tempMapper01.updSign(sign);
		}
	}
	
	@Test
	public void test02() {
		//1.查所有人
		List<String> selAllName = tempMapper01.selAllName();
		//2.遍历所有人
		for (String name : selAllName) {
			//3.遍历所有考勤月
			for (int i = 3; i <= 12; i++) {
				//3.查询这个人 i月有多少天加班
				Integer selJiaBan = tempMapper01.selJiaBan(name, i);
				if (selJiaBan==null) {
					continue;
				}
				int JiaBanDays = selJiaBan*2;
				//4.查询这个人所有考勤记录
				List<Sign> signList = tempMapper01.selSignByName(name);
				//5.打乱考勤顺序,再遍历
				Collections.shuffle(signList);
				for (int j = 0; j < signList.size(); j++) {
					if (JiaBanDays==0) {
						break;
					}
					if (signList.get(j).getDate().getMonth()==(i-1)
							&&signList.get(j).getDate().getHours()>9) {
						signList.get(j).getDate().setHours(23);
						tempMapper01.updSign(signList.get(j));
						JiaBanDays--;
						System.out.println(signList.get(j));
					}
				}
			}
		}
	}
}
