package test.cases;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import test.App;
import test.mapper.TempMapper01;
import test.mapper.TempMapper02;
import test.pojo.Temp_work;

@SpringBootTest(classes = App.class)
public class TestCase09 {
	@Resource
	private TempMapper02 tempMapper02;
	@Resource
	private TempMapper01 tempMapper01;
	
	 /**
	  * 获取date是星期几
	  * @param date
	  * @return
	  */
	public static String getWeekOfDate(Date date) {
		String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
		if (w < 0)
			w = 0;
		return weekDays[w];
	}
	
	/**
	 * 1.非周末日期入库
	 * @throws IOException
	 */
	@Test
	@Disabled
	public void test01() throws IOException {
		//1.2018-12 2019-12所有工作日
		Date date = new Date();
		date.setYear(118);//a.年是从1900年开始
		date.setMonth(11);//b.月是从0开始
		date.setDate(7);//c.setDate可以迭代日期
		//2.考勤初始日期为2018-12-07
		System.out.println(date);
		//3.考勤结束日期为2020年1月1日
		Date date2 = new Date();
		date2.setYear(120);
		date2.setMonth(0);
		date2.setDate(1);
		System.out.println(date2);
		
		System.out.println("--------------------------------------");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		while (true) {
			if (date.getYear()==date2.getYear()&&date.getMonth()==date2.getMonth()
					&&date.getDate()==date2.getDate()) {
				break;
			}
			System.out.println(date+"--"+getWeekOfDate(date));
			
			//4.过滤掉所有的周六周日
			if (!getWeekOfDate(date).equals("星期六")&&!getWeekOfDate(date).equals("星期日")) {
				//5.入库没有周六周日的日期
				//System.out.println(dateFormat.format(date));
				String formatDate = dateFormat.format(date);
				System.out.println(formatDate);
				tempMapper02.insDate(formatDate);
			}
			date.setDate(date.getDate()+1);
		}
	}
	
	/**
	 * 2.处理法定假日
	 */
	@Test
	@Disabled
	public void test02() {
		//1.手动删除每个月多余日期
		//2.添加少了的日期
		//tempMapper02.insDate("20181229");
		//tempMapper02.insDate("20190202");
		//tempMapper02.insDate("20190203");
		//tempMapper02.insDate("20190428");
		//tempMapper02.insDate("20190505");
		//tempMapper02.insDate("20190929");
		tempMapper02.insDate("20190615");
		tempMapper02.insDate("20190622");
	}
	
	/**
	 * 3.根据出勤数量和加班数量生成日报
	 */
	@Test
	//@Disabled
	public void test03() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
		Random random = new Random();
		//1.查询temp_work表所有数据
		List<Temp_work> selTemp_works = tempMapper02.selTemp_works();
		for (Temp_work temp_work : selTemp_works) {
			//a.人名
			String name = temp_work.getName();
			//b.上班的年月
			Date month = temp_work.getMonth();
				//b1.查询这个年月所有的工作日
			List<Date> allWorkDaysInMonth = 
					tempMapper02.selDatesByYearAndMonth("%"+dateFormat.format(month)+"%");
			//c.上班数量和加班数量生成这个月的考勤
			int work_days = temp_work.getWork_days();
			int overtime_days = temp_work.getOvertime_days()*2;
			//e.打乱考勤的日期顺序
			Collections.shuffle(allWorkDaysInMonth);
			//f.按出勤天数遍历考勤日期
			for (int i = 0; i < work_days; i++) {
				//h.设置上班时间，该日期下随机生成8—9点的时间上班时间
				Calendar cal = Calendar.getInstance();
				cal.setTime(allWorkDaysInMonth.get(i));
				 
				cal.set(Calendar.HOUR_OF_DAY, 8); //时
				cal.set(Calendar.MINUTE, random.nextInt(59)); //分
				cal.set(Calendar.SECOND, random.nextInt(59)); //秒
				Date startTime = cal.getTime();
				
				//i.该日期下生成一个18-19点的下班时间
				cal.set(Calendar.HOUR_OF_DAY, 18); //时
				cal.set(Calendar.MINUTE, random.nextInt(59)); //分
				cal.set(Calendar.SECOND, random.nextInt(59)); //秒
				Date endTime = cal.getTime();
				
				if (overtime_days!=0) {//g.还有加班数量
					//j.下班时间设置为11点之后
					endTime.setHours(23);
					overtime_days--;
				}
				
				//k.上下班时间入库
				tempMapper01.insSign(name, startTime);
				tempMapper01.insSign(name, endTime);
				System.out.println(name+"--"+startTime);
				System.out.println(name+"--"+endTime);
			}
			
		}
	}
	
	public static void main(String[] args) {
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
//		Date date = new Date();
//		System.out.println(dateFormat.format(date));
//		List<Integer> list = new ArrayList<Integer>();
//		list.add(1);
//		list.add(2);
//		list.add(3);
//		list.add(4);
//		System.out.println(list.get(1));
	}
	
}
