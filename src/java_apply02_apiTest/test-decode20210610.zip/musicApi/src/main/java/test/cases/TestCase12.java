package test.cases;

import com.alibaba.fastjson.JSON;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.mapper.MusicInfoMapper2;
import test.pojo.MusicInfo;
import test.util.DataUtils;
import test.util.RequestUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.*;

@SpringBootTest(classes = App.class)
public class TestCase12 {
	@Resource
	private MusicInfoMapper2 musicInfoMapper2;
	
	@Test
	public void test01() throws IOException {
		// 1.查出所有歌曲id
		List<String> list = musicInfoMapper2.listSongId();
		System.out.println(list.size());

		// System.out.println(DataUtils.dateTimeFormat(new Date()));
		// 2.遍历list查询歌曲详情
		for (String songid : list) {
			String url2 = "https://open.migu.cn:98/sportMusic/2.0/rest/music/get?evident";
			String request2 = "{\"musicId\":\""+songid+"\",\"pageSize\":\"S\"}";
			String authorization2="OEPAUTH chCode=\"014D08C\", smartDeviceId=\"869634045029820\"";
			String resp2 = RequestUtils.sendRequest(url2, request2, authorization2);
			System.out.println(resp2);
			MusicInfo musicInfo = JSON.parseObject(resp2).getObject("musicInfo", MusicInfo.class);
			if (musicInfo!=null){
				musicInfo.setCreateTime(DataUtils.dateTimeFormat(new Date()));
				musicInfoMapper2.insMusicInfo(musicInfo);
			}
		}
	}
}
