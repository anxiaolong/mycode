package test.cases;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import test.App;
import test.mapper.MusicInfoMapper;
import test.mapper.SongMapper;
import test.mapper.VoiceBoxSearchSongMapper;
import test.pojo.MusicInfo;

import javax.annotation.Resource;
import java.util.*;

@SpringBootTest(classes = App.class)
public class TestCaseDemo {
	@Resource
	private MusicInfoMapper musicInfoMapper;
	@Resource
	private SongMapper songMapper;
	@Resource
	private VoiceBoxSearchSongMapper voiceBoxSearchSongMapper;

	@Test
	@DisplayName("解析搜索结果")
	public void parseResult() {
		List<MusicInfo> musicInfos = musicInfoMapper.selAllMusicInfo();
		for (MusicInfo musicInfo : musicInfos) {
			System.out.println(musicInfo);
		}
	}

}
