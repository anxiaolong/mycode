package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import test.pojo.MusicInfo;

public interface MusicInfoMapper {
	// 查询歌曲id
	@Select("SELECT songId from temp01")
	List<String> getAllSongId();

	// 电台信息和图片入库
	@Insert("INSERT INTO temp01 (songId,columnId,columnName,radioId,radioName,radioPic) VALUE "
			+ "(#{songid},#{columnId},#{columnName},#{radioId},#{radioName},#{radioPic});")
	int insSongId(@Param("songid") String songid, @Param("columnId") String columnId,
				  @Param("columnName") String columnName, @Param("radioId") String radioId,
				  @Param("radioName") String radioName, @Param("radioPic") String radioPic);

	// 歌曲信息入库
	@Insert("insert into musicinfo "
			+ "(musicId,createTime,musicName,singerName,albumNames,songAuthorName,"
			+ "lyricAuthorName,length,language,picUrl,lrcUrl,isCollection,"
			+ "isCpAuth,auditionsFlag,vid) VALUE "
			+ "(#{musicId},#{createTime},#{musicName},#{singerName},#{albumNames},#{songAuthorName},#{lyricAuthorName},#{length},"
			+ "#{language},#{picUrl},#{lrcUrl},#{isCollection},#{isCpAuth},#{auditionsFlag},#{vid})")
	int insMusicInfo(MusicInfo musicInfo);

	@Select("SELECT * FROM musicinfo")
	List<MusicInfo> selAllMusicInfo();
}
