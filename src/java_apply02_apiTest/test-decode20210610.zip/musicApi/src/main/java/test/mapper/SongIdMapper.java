package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface SongIdMapper {
	@Select("SELECT songId from temp01")
	List<String> getAllSongId();

	@Insert("INSERT INTO temp01 (songId,columnId,columnName,radioId,radioName,radioPic) VALUE "
			+ "(#{songid},#{columnId},#{columnName},#{radioId},#{radioName},#{radioPic});")
	int insSongId(@Param("songid") String songid,@Param("columnId") String columnId,
			@Param("columnName") String columnName,@Param("radioId") String radioId,
			@Param("radioName") String radioName,@Param("radioPic") String radioPic);
}
