package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import test.pojo.Song;

public interface SongMapper {
	@Select("SELECT * FROM song")
	List<Song> selAllSongs();
	
	@Update("update song s set s.resCode=#{resCode},s.resMsg=#{resMsg} where id=#{id}")
	int upd(Song song);
}
