package test.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import test.pojo.Sign;

public interface TempMapper01 {
	
	@Select("SELECT DISTINCT(date) FROM temp_ribao WHERE `names` LIKE #{name};")
	List<Date>  selAllDate(@Param("name") String name);
	
	@Select("SELECT name FROM temp_people;")
	List<String> selAllName();
	
	@Insert("INSERT INTO temp_sign (name,date) VALUES (#{name},#{date});")
	int insSign(@Param("name") String name,@Param("date") Date date);
	
	@Select("SELECT jiaban FROM temp_jiaban WHERE name=#{name} AND month=#{month};")
	Integer selJiaBan(@Param("name") String name,@Param("month") int month);
	
	@Select("SELECT * FROM temp_sign WHERE name=#{name};")
	List<Sign> selSignByName(@Param("name") String name);
	
	@Update("update temp_sign set date=#{date} where id=#{id}")
	int updSign(Sign sign);
	
	@Select("SELECT * FROM temp_sign;")
	List<Sign> selAllSign();
}
