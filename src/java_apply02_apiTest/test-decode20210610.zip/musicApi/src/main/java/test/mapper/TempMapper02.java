package test.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import test.pojo.Temp_work;

public interface TempMapper02 {
	@Insert("INSERT into temp_ribao (date) VALUE (#{date}); ")
	int insDate(@Param("date") String date);
	
	@Select("SELECT * FROM temp_work ORDER BY name;")
	List<Temp_work> selTemp_works();
	
	@Select("SELECT date FROM temp_ribao WHERE date LIKE #{date1} ORDER BY date;")
	List<Date> selDatesByYearAndMonth(@Param("date1") String date1);
}
