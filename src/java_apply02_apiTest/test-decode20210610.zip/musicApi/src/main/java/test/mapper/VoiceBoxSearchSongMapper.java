package test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import test.pojo.VoiceBoxSearchSong;

public interface VoiceBoxSearchSongMapper {
	@Update("UPDATE voiceboxsearchsong SET result=#{result} WHERE id=#{id};")
	int insVoiceBoxSearchSong(VoiceBoxSearchSong voiceBoxSearchSong);
	
	@Select("select * from voiceboxsearchsong")
	List<VoiceBoxSearchSong> selAllvbss();
	
	@Select("SELECT * " + 
			" FROM" + 
			" voiceboxsearchsong v " + 
			" WHERE" + 
			" v.result LIKE CONCAT('%', v.artistName, '%')" + 
			" AND v.result LIKE CONCAT('%', v.songName, '%');")
	List<VoiceBoxSearchSong> selMatchSong();
	
	@Select("SELECT * FROM voiceboxsearchsong v WHERE v.songName LIKE '%dj%' AND v.result NOT LIKE '%\"total\":0,\"%';")
	List<VoiceBoxSearchSong> selDJ();
}
