package test.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DataUtils {

    public static String dateTimeFormat(Date date){
        //创建一个格式化日期对象
        DateFormat simpleDateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //格式化后的时间
        String punchTime = simpleDateFormat.format(date);
        return punchTime;
    }
}
