package test.util;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;

public class RequestUtils {
	
	public static String sendRequest(String url,String request,String authorization) throws IOException {
		Connection conn = Jsoup.connect(url).ignoreContentType(true)
				.method(Method.POST)
				.header("Content-Type", "application/json")
				.header("Authorization", authorization)
				.requestBody(request.toString());
		Response rsp = conn.execute();
		return rsp.body();
	}
}
