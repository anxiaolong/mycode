package com.migu.cases;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import com.migu.request.SdkChargePre;
import com.migu.utils.DataUtils;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 


public class TestSdkChargePre {
	
	static String url="http://10.25.245.202:8174/payment2/migu/senior/sdkChargePre";
	SdkChargePre request=new SdkChargePre();
	
	@Test
	public void testCase01() throws IOException {
		assertThat(DataUtils.sendRequest(url, request.getRequest().toString()),containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}
	
	@Test
	public void testCase02() throws Exception {
		String urlEncode=DataUtils.getUrlEncode(request.getRequest().toString());
		assertThat(DataUtils.sendRequest(url, urlEncode),containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}
}
