package com.migu.request;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.migu.utils.DataUtils;

public class SdkChargePre {
	String partner="1000014";
	String key="B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN";
	String time=DataUtils.getTime();
	String orderId=DataUtils.getOrderId(partner);
	
	public JSONObject getRequest() {
		//������յ���������
		JSONObject request=new JSONObject();
		JSONObject data=getData();
		request.put("data", data);
		request.put("sign", DataUtils.getSign(data, key));
		return request;
	}
	
	public JSONObject getData() {
		JSONObject data=new JSONObject();
		JSONArray payInfoArray=new JSONArray();
		JSONObject payInfo=new JSONObject();
		//�������������
		payInfo.put("BizCode", "600927020000005010");
		payInfo.put("ExpansionParam", "");
		payInfo.put("InterfaceType", "thmon");
		payInfo.put("MonLength", "1");
		payInfo.put("bankCode", "WX");
		payInfo.put("count", "1");
		payInfo.put("goodsName", "");
		payInfo.put("holdpay", "1");
		payInfo.put("isShowCasher", "1");
		payInfo.put("orderId", orderId);
		payInfo.put("price", "2");
		payInfo.put("terminal", "ANDROID");
		payInfoArray.add(payInfo);
		
		data.put("AccessMode", "3");
		data.put("AccessPlatformID", "014000D");
		data.put("DID", "1128050");
		data.put("MSISDN", "15928791968");
		data.put("notifyUrl", "http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do");
		data.put("partner", this.partner);
		data.put("passId", "405535601515956602");
		data.put("productId", "014");
		data.put("time", time);
		data.put("totalPrice", "2");
		data.put("transactionId", orderId);
		data.put("uid", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		data.put("payInfo", payInfoArray);
		
		return data;
	}
}
