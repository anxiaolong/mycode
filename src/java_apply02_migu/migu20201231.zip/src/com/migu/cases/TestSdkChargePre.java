package com.migu.cases;

import static org.junit.Assert.*;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.migu.utils.DataUtils;

import payment2.migu.senior.SdkChargePre;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 


public class TestSdkChargePre {
	
	@Test
	public void testCase01() throws IOException, EncoderException {
		SdkChargePre request=new SdkChargePre();
		assertThat(DataUtils.sendRequest(request.getUrl(), request.getRequest()),containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}
	
	@Test
	public void testCase02() throws Exception {
		SdkChargePre request=new SdkChargePre();
		String urlEncode=DataUtils.getUrlEncode(request.getRequest().toString());
		assertThat(DataUtils.sendRequest(request.getUrl(), urlEncode),containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}
}
