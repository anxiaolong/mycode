package com.migu.payment.adapter;

import org.apache.commons.codec.EncoderException;

import com.alibaba.fastjson.JSONObject;
import com.migu.utils.DataUtils;
 /**
  * payment�ӿڵ�������
  * @author Administrator
  *
  */
public class PaymentAdapter {
	private String url=null;
	private JSONObject request=null;
	private JSONObject data=null;
	private String key=null;
	private String isUrlEcode="false";
		
	

	//�ṩһ���вι��죬��servlet��ȡ���ݲ���
	public PaymentAdapter(String url,JSONObject data,String key,String isUrlEcode) {
		this.url=url;
		this.data=data;
		this.key=key;
		this.isUrlEcode=isUrlEcode;
	}

	//�����Ҫת������������
	public String getRequest() throws EncoderException {
		request=new JSONObject();
		request.put("data", this.data);
		request.put("sign", DataUtils.getSign(this.data, key));
		String requestString=request.toString();
		if (isUrlEcode.equals("true")) {
			requestString=DataUtils.getUrlEncode(request.toString());
		}
		return requestString;
	}
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public JSONObject getData() {
		return data;
	}

	public void setData(JSONObject data) {
		this.data = data;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getIsUrlEcode() {
		return isUrlEcode;
	}

	public void setIsUrlEcode(String isUrlEcode) {
		this.isUrlEcode = isUrlEcode;
	}
}
