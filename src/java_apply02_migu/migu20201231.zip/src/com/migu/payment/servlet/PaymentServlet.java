package com.migu.payment.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.EncoderException;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.migu.payment.adapter.PaymentAdapter;
import com.migu.utils.DataUtils;

/**
 * Servlet����ת��payment����
 */
@WebServlet("/payment")
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//1.���ñ���
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		//2.�����ı�����Ϊjson
		resp.setContentType("application/json");
		
		//3.��ȡ���
		BufferedReader br = new BufferedReader(new InputStreamReader(req.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer("");
        String temp;
        while ((temp = br.readLine()) != null) {
            sb.append(temp);
        }
        br.close();
        String param = sb.toString().replace(" ", "");
        
        //4.����Ϊjson
        JSONObject reqJson = JSON.parseObject(param);
        
        //5.��������������
        JSONObject data=JSON.parseObject(reqJson.getString("data"));
        PaymentAdapter paymentAdapter=new PaymentAdapter(reqJson.getString("url"),data,reqJson.getString("key"),reqJson.getString("isUrlEcode"));
        
        //6.��������ת����Ӧ����
        try {
        	String input=paymentAdapter.getRequest();
			String output=DataUtils.sendRequest(paymentAdapter.getUrl(),input);
			JSONObject respJson=new JSONObject();
			respJson.put("input", input);
			respJson.put("output", JSON.parse(output));
			resp.getWriter().println(respJson);
		} catch (EncoderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
