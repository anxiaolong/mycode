package com.migu.utils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.net.URLCodec;
import org.apache.log4j.Logger;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;

import com.alibaba.fastjson.JSONObject;

public class DataUtils {
	
	static Logger logger=Logger.getLogger(DataUtils.class);
	
	//1.��ø�ʽ�����time����
	public static String getTime() {
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		//System.out.println(dateFormat.format(date));
		return dateFormat.format(date);
	}
	
	//1.��ø�ʽ�����orderId��transactionId
	public static String getOrderId(String partner) {
		return partner+getTime()+(Math.round(Math.random()*900)+100);
	}
	
	//3.��ȡsignǩ��
	public static String getSign(JSONObject data,String key) {
		//System.out.println(data.toString()+"&key="+key);
		return DigestUtils.md5Hex(data.toString()+"&key="+key);
	}
	
	//4.������
	public static String sendRequest(String url,String request) throws IOException {
		Connection conn = Jsoup.connect(url)
				.method(Method.POST).ignoreContentType(true)
				.header("Content-Type", "application/json")
				.requestBody(request.toString());
		Response rsp = conn.execute();
		logger.info("input��"+request);
		logger.info("output��"+rsp.body());
		return rsp.body();
	}
	
	//5.url����
	public static String getUrlEncode(String request) throws EncoderException {
		URLCodec urlCodec=new URLCodec();
		return urlCodec.encode(request);
	}
}
