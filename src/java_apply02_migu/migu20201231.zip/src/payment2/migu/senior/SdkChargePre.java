package payment2.migu.senior;

import org.apache.commons.codec.EncoderException;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.migu.utils.DataUtils;

public class SdkChargePre {
	private String url=null;
	private JSONObject request=null;
	private JSONObject data=null;
	private JSONArray payInfoArray=null;
	private JSONObject payInfo=null;
	private String key="B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN";
	private Boolean isUrlEcode=false;
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	//Ĭ�Ϲ��췽���У���ʼ��һ��Ĭ�ϵĲ�������
	public SdkChargePre() {
		url="http://10.25.245.202:8174/payment2/migu/senior/sdkChargePre";
		String partner="1000014";
		String time=DataUtils.getTime();
		String orderId=DataUtils.getOrderId(partner);
		
		data=new JSONObject();
		payInfoArray=new JSONArray();
		payInfo=new JSONObject();
		//�������������
		payInfo.put("BizCode", "600927020000005010");
		payInfo.put("ExpansionParam", "");
		payInfo.put("InterfaceType", "thmon");
		payInfo.put("MonLength", "1");
		payInfo.put("bankCode", "WX");
		payInfo.put("count", "1");
		payInfo.put("goodsName", "");
		payInfo.put("holdpay", "1");
		payInfo.put("isShowCasher", "1");
		payInfo.put("orderId", orderId);
		payInfo.put("price", "2");
		payInfo.put("terminal", "ANDROID");
		payInfoArray.add(payInfo);
		
		data.put("AccessMode", "3");
		data.put("AccessPlatformID", "014000D");
		data.put("DID", "1128050");
		data.put("MSISDN", "15928791968");
		data.put("notifyUrl", "http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do");
		data.put("partner", partner);
		data.put("passId", "405535601515956602");
		data.put("productId", "014");
		data.put("time", time);
		data.put("totalPrice", "2");
		data.put("transactionId", orderId);
		data.put("uid", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		data.put("payInfo", payInfoArray);
	}
	
	//�ṩһ���вι��죬��servlet��ȡ���ݲ���
	public SdkChargePre(String url,JSONObject data,String key,Boolean isUrlEcode) {
		this.url=url;
		this.data=data;
		this.isUrlEcode=isUrlEcode;
	}
	
	//������յ���������
	public String getRequest() throws EncoderException {
		request=new JSONObject();
		request.put("data", this.data);
		request.put("sign", DataUtils.getSign(this.data, key));
		String requestString=request.toString();
		if (isUrlEcode) {
			requestString=DataUtils.getUrlEncode(request.toString());
		}
		return requestString;
	}

	public JSONObject getData() {
		return data;
	}

	public void setData(JSONObject data) {
		this.data = data;
	}

	public JSONArray getPayInfoArray() {
		return payInfoArray;
	}

	public void setPayInfoArray(JSONArray payInfoArray) {
		this.payInfoArray = payInfoArray;
	}

	public JSONObject getPayInfo() {
		return payInfo;
	}

	public void setPayInfo(JSONObject payInfo) {
		this.payInfo = payInfo;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setRequest(JSONObject request) {
		this.request = request;
	}
}
