package com.migu.cases;

import static org.junit.Assert.*;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.migu.api.utils.DataUtils;
import com.migu.cases.request.SdkChargePre;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 


public class TestSdkChargePre {
	
	@Test
	public void testNormalRequest() throws IOException, EncoderException {
		SdkChargePre request=new SdkChargePre();
		assertThat(DataUtils.sendRequest(request.getUrl(), request.getRequest()),containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}
	
	@Test
	public void testUrlEcodeRequest() throws Exception {
		SdkChargePre request=new SdkChargePre();
		request.setIsUrlEcode("true");
		assertThat(DataUtils.sendRequest(request.getUrl(), request.getRequest()),containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}
	
	@Test
	public void test03(){
		
	}
}
