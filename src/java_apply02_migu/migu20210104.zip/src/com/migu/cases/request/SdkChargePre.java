package com.migu.cases.request;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;
import com.migu.api.utils.DataUtils;

public class SdkChargePre extends ApiAdapter {
	
	//�Զ������������
	public SdkChargePre(String url,JSONObject data,String key,String isUrlEcode) {
		super(url, data, key, isUrlEcode);
	}
	
	//Ĭ�ϲ���������
	public SdkChargePre() {
		this.setData(new JSONObject());
		JSONArray payInfoArray=new JSONArray();
		JSONObject payInfo=new JSONObject();
		//�������������
		String orderId=DataUtils.getOrderId("1000014");
		payInfo.put("BizCode", "600927020000005010");
		payInfo.put("ExpansionParam", "");
		payInfo.put("InterfaceType", "thmon");
		payInfo.put("MonLength", "1");
		payInfo.put("bankCode", "WX");
		payInfo.put("count", "1");
		payInfo.put("goodsName", "");
		payInfo.put("holdpay", "1");
		payInfo.put("isShowCasher", "1");
		payInfo.put("orderId", orderId);
		payInfo.put("price", "2");
		payInfo.put("terminal", "ANDROID");
		payInfoArray.add(payInfo);
		
		this.getData().put("AccessMode", "3");
		this.getData().put("AccessPlatformID", "014000D");
		this.getData().put("DID", "1128050");
		this.getData().put("MSISDN", "15928791968");
		this.getData().put("notifyUrl", "http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do");
		this.getData().put("partner", "1000014");
		this.getData().put("passId", "405535601515956602");
		this.getData().put("productId", "014");
		this.getData().put("time", DataUtils.getTime());
		this.getData().put("totalPrice", "2");
		this.getData().put("transactionId",orderId);
		this.getData().put("uid", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("payInfo", payInfoArray);
		
		this.setUrl("http://10.25.245.202:8174/payment2/migu/senior/sdkChargePre");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setIsUrlEcode("false");
	}
	
	

}
