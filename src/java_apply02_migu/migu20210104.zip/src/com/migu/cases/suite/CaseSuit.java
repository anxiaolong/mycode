package com.migu.cases.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.migu.cases.TestSdkChargePre;

@RunWith(Suite.class)
@SuiteClasses({TestSdkChargePre.class })
public class CaseSuit {}
