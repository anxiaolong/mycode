package com.migu.cases;

import static org.junit.Assert.*;

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.payment2.migu.senior.Charge;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TestCharge {

	@Test
	public void test01() throws IOException, EncoderException {
		Charge charge=new Charge();
		assertThat(DataUtils.sendRequest(charge.getUrl(), charge.getRequest()),
				containsString("\"retCode\":\"000\",\"retMsg\":\"request success\""));
	}

}
