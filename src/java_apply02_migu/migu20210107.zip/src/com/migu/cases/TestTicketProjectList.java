package com.migu.cases;

import static org.junit.Assert.*;

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.ticketRest.ticket.TicketProjectList;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TestTicketProjectList {

	@Test
	public void test01() throws IOException, EncoderException {
		//Ʊ����Ŀ�б���ѯkey��Ҫ��̨����ϵͳ��ȡ
		TicketProjectList ticketProjectList=new TicketProjectList();
		assertThat(DataUtils.sendRequest(ticketProjectList.getUrl(), ticketProjectList.getRequest()),
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�ɹ�\""));
	}

}
