package com.migu.cases;
/**
 * ��ȡ֧������Ϣ�б��ӿ�
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.payment_account.account.GetAccountList;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 

public class TestGetAccountList {

	@Test
	public void test01() throws IOException, EncoderException {
		GetAccountList getAccountList=new GetAccountList();
		assertThat(DataUtils.sendRequest(getAccountList.getUrl(), getAccountList.getRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�ɹ�\""));
	}

}
