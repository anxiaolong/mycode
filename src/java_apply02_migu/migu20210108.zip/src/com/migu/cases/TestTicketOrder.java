package com.migu.cases;
/**
 * ������Ʊ�µ�
 */

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.orderPayRest.order.third.TicketOrder;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TestTicketOrder {

	@Test
	public void test01() throws IOException, EncoderException {
		TicketOrder ticketOrder=new TicketOrder();
		DataUtils.sendRequest(ticketOrder.getUrl(), ticketOrder.getRequest());
	}

}
