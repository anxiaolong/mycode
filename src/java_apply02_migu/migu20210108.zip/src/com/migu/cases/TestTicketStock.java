package com.migu.cases;
/**
 * ƱƷ����ѯ�ӿ�
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.ticketRest.ticket.TicketStock;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 

public class TestTicketStock {

	@Test
	public void test01() throws IOException, EncoderException {
		TicketStock t1=new TicketStock();
		assertThat(DataUtils.sendRequest(t1.getUrl(), t1.getRequest()),
				containsString("\"retCode\":\"000000\",\"retMsg\":\"��ѯ�ɹ�\""));
	}

}
