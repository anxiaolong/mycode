package request.orderPayRest.order.third;

import org.apache.commons.codec.EncoderException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;
import com.migu.api.utils.DataUtils;

public class TicketOrder extends ApiAdapter {
	public TicketOrder() {
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/orderPayRest/order/third/ticketOrder");
		
		JSONObject data=JSON.parseObject("{"
				+ "\"orderPayment\":"
				+ "{\"cardPayPrice\":\"0\","
				+ "\"cardPwd\":\"\","
				+ "\"channelID\":\"0140070\","
				+ "\"electronicType\":\"\","
				+ "\"goodsCount\":\"4\","
				+ "\"invoiceFlag\":\"0\","
				+ "\"invoiceInfo\":{\"invoiceConsignee\":\"\","
				+ "\"invoiceEmail\":\"\","
				+ "\"invoiceExpressAddress\":\"\","
				+ "\"invoiceObtainMode\":\"\","
				+ "\"invoicePhone\":\"\",\"invoiceTitle\":\"\","
				+ "\"invoiceType\":\"1\","
				+ "\"taxpayerNum\":\"\"},\"msisdn\":\"17844586820\","
				+ "\"orderType\":\"2\","
				+ "\"paymentId\":\"100001420201229545887786\","
				+ "\"projectId\":\"120000863\",\"receiveType\":\"1\","
				+ "\"seatInfoId\":\"2020122969db6e8a-c434-468e-b048-efa1ed7e602a\","
				+ "\"showItemId\":\"12000086301\",\"source\":\"00\","
				+ "\"thirdPrice\":\"1200\",\"ticketItemId\":\"987\","
				+ "\"ticketList\":[{\"ticketNo\":\"2020122969db6e8a-c434-468e-b048-efa1ed7e602a\"}],"
				+ "\"totalPrice\":\"1200\","
				+ "\"uid\":\"5d2ede99-5445-4567-9042-eb85b6bd21fc\","
				+ "\"vipFlag\":\"1\"}"
				+ "}");
		((JSONObject) data.get("orderPayment")).put("paymentId", DataUtils.getOrderId("1000014"));
		this.setData(data);
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("partner", this.getPartner());
		newReq.put("time", DataUtils.getTime());
		return newReq.toString();
	}
}
