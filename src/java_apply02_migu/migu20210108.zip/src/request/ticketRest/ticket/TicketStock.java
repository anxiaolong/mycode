package request.ticketRest.ticket;

import org.apache.commons.codec.EncoderException;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;

public class TicketStock extends ApiAdapter {
	public TicketStock() {
		this.setUrl("http://10.25.193.16:18701/ticketRest/ticket/ticketStock");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		this.setData(new JSONObject());
		this.getData().put("pid", "120000851");
		this.getData().put("showId", "12000085100");
		this.getData().put("ticketItemId", "882");
		this.getData().put("source", "00");
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("signType", "MD5");
		newReq.put("partner", "1000014");
		return newReq.toString();
	}
}
