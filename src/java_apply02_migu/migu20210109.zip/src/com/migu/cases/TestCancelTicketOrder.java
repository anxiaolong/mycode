package com.migu.cases;
/**
 * ȡ����Ʊ����
 */

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.orderPayRest.order.third.CancelTicketOrder;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TestCancelTicketOrder {

	@Test
	public void test01() throws IOException, EncoderException {
		CancelTicketOrder cancelTicketOrder=new CancelTicketOrder();
		cancelTicketOrder.getData().put("orderId", "100001420210109162759743");
		assertThat(DataUtils.sendRequest(cancelTicketOrder.getUrl(), cancelTicketOrder.getRequest()), 
				containsString("\"retCode\":\"000\",\"retMsg\":\"����ȡ���ɹ�|[ORDER]cancelTicketOrder success\""));
	}

}
