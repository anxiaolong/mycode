package com.migu.cases;
/**
 * �ݳ���Ŀ�����ѯ
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.ticketRest.ticket.GetTicketProject;

import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.containsString; 

public class TestGetTicketProject {

	@Test
	public void test01() throws Exception {
		GetTicketProject getTicketProject=new GetTicketProject();
		assertThat(DataUtils.sendRequest(getTicketProject.getUrl(), getTicketProject.getRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"��ѯ�ɹ�\""));
	}

}
