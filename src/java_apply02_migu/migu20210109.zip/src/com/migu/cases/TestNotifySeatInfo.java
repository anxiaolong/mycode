package com.migu.cases;
/**
 * Ʊ��Ԥ�µ��ӿ�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.ticketRest.ticket.NotifySeatInfo;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TestNotifySeatInfo {

	@Test
	public void test01() throws IOException, EncoderException {
		NotifySeatInfo notifySeatInfo=new NotifySeatInfo();
		assertThat(DataUtils.sendRequest(notifySeatInfo.getUrl(), notifySeatInfo.getRequest()),
				containsString("\"retCode\":\"000000\",\"retMsg\":\"��ѯ�ɹ�\""));
	}

}
