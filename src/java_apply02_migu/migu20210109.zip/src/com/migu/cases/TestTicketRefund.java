package com.migu.cases;
/**
 * ������Ʊ�˿�
 */

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.orderPayRest.order.third.TicketRefund;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TestTicketRefund {

	@Test
	public void test01() throws IOException, EncoderException {
		TicketRefund ticketRefund=new TicketRefund();
		assertThat(DataUtils.sendRequest(ticketRefund.getUrl(), ticketRefund.getRequest()), 
				containsString("\"retCode\":\"000\",\"retMsg\":\"������Ʊ�µ��ɹ���\""));
	}

}
