package com.migu.cases;
/**
 * Ʊ���µ���ֱ�ӱ���Ʊ��ӿڣ�
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.migu.api.utils.DataUtils;

import request.ticketRest.ticket.Order;
import request.ticketRest.ticket.TicketStock;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Ignore;

import static org.hamcrest.CoreMatchers.containsString; 

public class TestOrder {
	
	@Ignore
	@Test
	public void test01() throws Exception {
		Order order=new Order();
		order.getData().put("orderId", DataUtils.getOrderId(order.getPartner()));
		assertThat(DataUtils.sendRequest(order.getUrl(), order.getRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�µ��ɹ�\""));
	}
	
	@Test
	public void test02() throws IOException, EncoderException {
		//1.��ѯ���
		TicketStock t1=new TicketStock();
		DataUtils.sendRequest(t1.getUrl(), t1.getRequest());
		//2.ƱƷ�µ�
		Order order=new Order();
		order.getData().put("orderId", DataUtils.getOrderId(order.getPartner()));
		DataUtils.sendRequest(order.getUrl(), order.getRequest());
		//3.ȷ�Ͽ��
		DataUtils.sendRequest(t1.getUrl(), t1.getRequest());
	}

}
