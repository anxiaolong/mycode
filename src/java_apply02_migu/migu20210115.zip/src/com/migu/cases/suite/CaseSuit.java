package com.migu.cases.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.migu.cases.TestCharge;
import com.migu.cases.TestSdkChargePre;
import com.migu.cases.TestTicketProjectList;

@RunWith(Suite.class)
@SuiteClasses({
	TestCharge.class,
	TestTicketProjectList.class,
	TestSdkChargePre.class
})
public class CaseSuit {}
