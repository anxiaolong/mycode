package request.payment2.migu.senior;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;
import com.migu.api.utils.DataUtils;

public class Charge extends ApiAdapter {
	
	public Charge(String url,JSONObject data,String key,String isUrlEcode) {
		super(url, data, key,isUrlEcode);
	}
	
	public Charge() {
		this.setIsUrlEcode("false");
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.245.202:8174/payment2/migu/senior/charge");
		this.setOrderId(DataUtils.getOrderId(this.getPartner()));
		//����payInfo����
		JSONObject payInfJson=new JSONObject();
		payInfJson.put("orderId", this.getOrderId());
		payInfJson.put("price", "2");
		payInfJson.put("InterfaceType", "thmon");
		payInfJson.put("count", "1");
		payInfJson.put("goodsName", "");
		payInfJson.put("BizCode", "600927020000005010");
		payInfJson.put("MonLength", "1");
		payInfJson.put("ExpansionParam", "");
		//���payInfo
		JSONArray payInfo=new JSONArray();
		payInfo.add(payInfJson);
		
		//���data����
		this.setData(new JSONObject());
		this.getData().put("partner", this.getPartner());
		this.getData().put("time", DataUtils.getTime());
		this.getData().put("transactionId", this.getOrderId());
		this.getData().put("totalPrice", "2");
		this.getData().put("DID", "1128050");
		this.getData().put("type", "WAP");
		this.getData().put("notifyUrl", "http://10.25.246.132:31003/v1.0/payment/thirdpartyPayNotify.do");
		this.getData().put("passId", "405535601515956602");
		this.getData().put("MSISDN", "15928791968");
		this.getData().put("uid", "a1c59a9d-88ab-4ed0-8b65-962b411d7e75");
		this.getData().put("MemberType", "0");
		this.getData().put("productId", "014");
		this.getData().put("AccessPlatformID", "002002A");
		this.getData().put("AccessMode", "2");
		this.getData().put("payMethod", "30");
		this.getData().put("bankId", "WX");
		this.getData().put("payInfo", payInfo);
	}
}
