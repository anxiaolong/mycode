package request.ticketRest.ticket;


import org.apache.commons.codec.EncoderException;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;

public class TicketProjectList extends ApiAdapter {
	
	public TicketProjectList(String url,JSONObject data,String key,String isUrlEcode) {
		super(url, data, key,isUrlEcode);
	}
	
	public TicketProjectList() {
		this.setUrl("http://10.25.193.16:18701/ticketRest/ticket/ticketProjectList");
		this.setPartner("1000014");
		this.setKey("LFRKLGI4PRUWWVY2STIYD5HW6GAGZK6C");
		
		this.setData(new JSONObject());
		this.getData().put("pageNum","1");
		this.getData().put("pageCount","4");
		this.getData().put("cityCode","510100");
		this.getData().put("category","01");
	}
	
	@Override
	public String getRequest() throws EncoderException {
		//�ڻ�ȡrequest������һ������
		JSONObject reqJsonObject=JSON.parseObject(super.getRequest());
		reqJsonObject.put("partner","1000014");
		reqJsonObject.put("signType","MD5");
		return reqJsonObject.toString();
	}
}
