package cases.ticketRest.ticket;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Ignore;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;
import com.migu.api.utils.DataUtils;

public class Order extends ApiAdapter {
	public Order() {
		//ticketItemId showItemId projectId���ݳ���Ŀ����ӿڻ�ȡ
		//seatInfoId��Ԥ�µ��ӿ��л�ȡ
		JSONObject data=JSON.parseObject(
				"{\"orderId\":\"100001420210109191220271\","
				+ "\"orderType\":\"2\","
				+ "\"custId\":\"666-666-666\","
				+ "\"custPhone\":\"15828637397\","
				+ "\"totalPrice\":\"1600\","
				+ "\"cardPayPrice\":\"0\","
				+ "\"thirdPrice\":\"1600\","
				+ "\"ticketNum\":\"1\","
				+ "\"projectId\":\"121000902\","
				+ "\"showItemId\":\"12100090200\","
				+ "\"ticketItemId\":\"931\","
				+ "\"receiveType\":\"3\","
				+ "\"electronicType\":\"30\","
				+ "\"invoiceFlag\":\"0\","
				+ "\"invoiceInfo\":{\"invoiceType\":\"\",\"invoiceTitle\":\"\","
				+ "\"taxpayerNum\":\"\",\"invoiceObtainMode\":\"\",\"invoiceEmail\":\"\","
				+ "\"invoiceExpressAddress\":\"\",\"invoiceConsignee\":\"\",\"invoicePhone\":\"\"},"
				+ "\"postInfo\":{\"province\":\"�Ĵ�ʡ\",\"city\":\"�ɶ���\",\"country\":\"������\","
				+ "\"detailAddr\":\"������123��\",\"charge\":\"100\",\"receiver\":\"�ֺ�\","
				+ "\"phone\":\"15828637397\",\"specialNote\":\"\"},"
				+ "\"ticketList\":[{\"ticketNo\":\"\"}],"
				+ "\"seatInfoId\":\"202101149a77b4a7-aaf8-42e9-b6d4-28681a60ec5a\","
				+ "\"channelId\":\"010004D\",\"source\":\"00\",\"vipFlag\":\"1\","
				+ "\"ticketHolders\":[{\"identityNum\":\"NTEwNjAzMTk4MzA1MTY1OTNY\",\"identityName\":\"5b2t5pyX\"}]}");
		
		this.setPartner("1000004");
		this.setKey("HWFI1KTJ2C8VNV9240VWOE923JS092JC");
		this.setData(data);
		this.setUrl("http://10.25.193.16:18800/ticketRest/ticket/order");
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("partner",this.getPartner());
		newReq.put("signType","MD5");
		return newReq.toString();
	}
	
	@Test
	public void test_Order() throws Exception {
		Order order=new Order();
		order.getData().put("orderId", DataUtils.getOrderId(order.getPartner()));
		assertThat(DataUtils.sendRequest(order.getUrl(), order.getRequest()), 
				containsString("\"retCode\":\"000000\",\"retMsg\":\"�µ��ɹ�\""));
	}
	
	@Ignore
	@Test
	public void test02() throws IOException, EncoderException {
		//1.��ѯ���
		TicketStock t1=new TicketStock();
		DataUtils.sendRequest(t1.getUrl(), t1.getRequest());
		//2.ƱƷ�µ�
		Order order=new Order();
		order.getData().put("orderId", DataUtils.getOrderId(order.getPartner()));
		DataUtils.sendRequest(order.getUrl(), order.getRequest());
		//3.ȷ�Ͽ��
		DataUtils.sendRequest(t1.getUrl(), t1.getRequest());
	}
}
