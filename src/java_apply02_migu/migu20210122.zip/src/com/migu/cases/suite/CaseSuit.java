package com.migu.cases.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import cases.orderPayRest.order.third.CancelTicketOrder;
import cases.orderPayRest.order.third.TicketOrder;
import cases.orderPayRest.order.third.TicketRefund;
import cases.payment2.migu.senior.Charge;
import cases.payment2.migu.senior.SdkChargePre;
import cases.payment_account.account.GetAccountList;
import cases.ticketRest.ticket.GetTicketProject;
import cases.ticketRest.ticket.NotifySeatInfo;
import cases.ticketRest.ticket.Order;
import cases.ticketRest.ticket.TicketProjectList;
import cases.ticketRest.ticket.TicketStock;

@RunWith(Suite.class)
@SuiteClasses({
	CancelTicketOrder.class,
	Charge.class,
	GetAccountList.class,
	GetTicketProject.class,
	NotifySeatInfo.class,
	Order.class,
	SdkChargePre.class,
	TicketOrder.class,
	TicketProjectList.class,
	TicketRefund.class,
	TicketStock.class
})
public class CaseSuit {
	
}
