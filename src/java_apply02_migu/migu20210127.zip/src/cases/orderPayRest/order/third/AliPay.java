package cases.orderPayRest.order.third;
/**
 * ֧����֧������
 */
import java.io.IOException;

import org.apache.commons.codec.EncoderException;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;
import com.migu.api.utils.DataUtils;

public class AliPay extends ApiAdapter {
	
	public AliPay() {
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/orderPayRest/order/third/aliPay");
		
		String string = "{\"ticketPayBo\":"
				+ "{\"orderId\":"+"100001420210126093938230"+","
				+ "\"payType\":\"aliApp\","
				+ "\"subject\":\"֧����֧���Ķ���\","
				+ "\"goodsDesc\":\"Iphone616G\"}}";
		JSONObject data=JSON.parseObject(string);
		this.setData(data);
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("time", DataUtils.getTime());
		newReq.put("partner",this.getPartner());
		return newReq.toString();
	}
	
	@Test
	public void test() throws IOException, EncoderException {
		AliPay aliPay=new AliPay();
		DataUtils.sendRequest(aliPay.getUrl(), aliPay.getRequest());
	}

}
