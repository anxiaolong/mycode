package cases.orderPayRest.order.third;
/**
 * ������Ʊ�˿�
 */

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.migu.api.adapter.ApiAdapter;
import com.migu.api.utils.DataUtils;

import cases.orderPayRest.order.third.TicketRefund;

import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.apache.commons.codec.EncoderException;

import static org.hamcrest.CoreMatchers.containsString; 

public class TicketRefund extends ApiAdapter {
	public TicketRefund() {
		this.setPartner("1000014");
		this.setKey("B8W9H18LJE9MIWQFC5ZZ6QZK2KHGQZEN");
		this.setUrl("http://10.25.193.30:8170/orderPayRest/order/third/ticketRefund");
		
		JSONObject data=JSON.parseObject("{\"tOrderPayment\":{"
				+ "\"orderRefundId\":\"0000000289\","
				+ "\"orderId\":\"100001420210109163251364\","
				+ "\"refundNotifyURL\":\"\","
				+ "\"thirdRefundAmount\":\"1000\","
				+ "\"thirdRefundType\":\"32\","
				+ "\"cardRefundAmount\":\"0\","
				+ "\"refundInfo\":\"��Ʊ�˿�\","
				+ "\"phoneNumber\":\"15828637397\","
				+ "\"source\":\"00\"}}");
		
		this.setData(data);
	}
	
	@Override
	public String getRequest() throws EncoderException {
		JSONObject newReq=JSON.parseObject(super.getRequest());
		newReq.put("partner", this.getPartner());
		newReq.put("time", DataUtils.getTime());
		return newReq.toString();
	}

	@Test
	public void test_TicketRefund() throws IOException, EncoderException {
		TicketRefund ticketRefund=new TicketRefund();
		assertThat(DataUtils.sendRequest(ticketRefund.getUrl(), ticketRefund.getRequest()), 
				containsString("\"busiResp\":null,\"retCode\":\"0001\",\"retMsg\":\"��Ч�Ķ����ţ�\""));
	}

}
